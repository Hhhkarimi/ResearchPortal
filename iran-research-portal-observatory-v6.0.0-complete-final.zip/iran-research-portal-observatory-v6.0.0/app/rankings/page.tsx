import Link from "next/link";
import { rankedUniversities, universityCatalog, isDemoMode, finalRanking, finalAuditCatalog } from "@/lib/data";
import { ScoreOrbit } from "@/components/score-orbit";
import { ViralScatter } from "@/components/viral-scatter";
import { CoverageHeatmap } from "@/components/coverage-heatmap";
import { DataModeBanner } from "@/components/data-mode-banner";

export const metadata = { title: "رتبه‌بندی نهایی RTPMI 4.0", description:"رتبه‌بندی Evidence-qualified بلوغ پرتال معاونت پژوهش و فناوری؛ این رتبه‌بندی عملکرد پژوهشی دانشگاه‌ها نیست." };

export default function RankingsPage() {
  const leader=rankedUniversities[0];
  const nonRanked=finalAuditCatalog.filter(a=>a.publicationDecision!=="publish-ranking");
  return <div className="shell page">
    <div className="pageHero"><span className="kicker">RTPMI / FINAL 4.0</span><h1>رتبه‌بندی نهایی بلوغ پرتال معاونت‌ها</h1><p>رتبه فقط برای پرتال‌های رسمیِ دارای Evidence مستقیم و Confidence حداقل ۶۵ صادر شده است. RTPMI کیفیت و شفافیت پرتال عمومی را می‌سنجد؛ نه کیفیت پژوهش، اعضای هیئت علمی یا خروجی علمی دانشگاه.</p></div>
    <DataModeBanner demo={isDemoMode}/>
    {!isDemoMode && <div className="portalQuickFacts"><span className="ok"><small>ممیزی ملی</small><b>۸۵ / ۸۵</b></span><span className="ok"><small>رتبه‌پذیر</small><b>{finalRanking.length}</b></span><span className="pending"><small>بدون رتبه قطعی</small><b>{nonRanked.length}</b></span><span className="ok"><small>نسخه شاخص</small><b>RTPMI 4.0</b></span></div>}
    {leader && <>
      <div className="rankHero glass"><div><span className="kicker">#01 / EVIDENCE QUALIFIED</span><h2>{leader.nameFa}</h2><p>{isDemoMode?"داده نمایشی":`RTPMI ${leader.score} · Confidence ${leader.confidence}%`}</p></div><ScoreOrbit score={leader.score || 0}/></div>
      <section className="section"><div className="sectionHead"><div><span className="kicker">PORTAL CONSTELLATION</span><h2>موقعیت پرتال‌های رتبه‌پذیر</h2></div><p>مقایسه فقط میان رکوردهای scoreable؛ دانشگاه‌های فاقد Evidence کافی از نمودار عددی حذف نشده‌اند، بلکه در بخش Unranked گزارش می‌شوند.</p></div><div className="glass chartCard"><ViralScatter universities={rankedUniversities}/></div></section>
      <section className="twoCol"><div className="glass panel"><div className="panelHead"><h2>Final leaderboard</h2></div><div className="leaderboard">{rankedUniversities.map((u,i)=><a href={`/universities/${u.slug}`} key={u.slug}><b>{String(i+1).padStart(2,"0")}</b><span>{u.nameFa}<small>Confidence {u.confidence}% · رتبه {finalRanking.find(r=>r.universitySlug===u.slug)?.rankWithinKind} از {finalRanking.find(r=>r.universitySlug===u.slug)?.kindFieldSize} در گروه {u.kind}</small></span><i style={{width:`${u.score}%`}}/><strong>{u.score}</strong></a>)}</div></div><div className="glass panel"><div className="panelHead"><h2>Document evidence coverage</h2></div><CoverageHeatmap universities={rankedUniversities}/></div></section>

      <section className="section"><div className="sectionHead"><div><span className="kicker">PEER GROUP LEAGUES</span><h2>رتبه در گروه هم‌نوع</h2></div><p>رتبه کل حفظ می‌شود، اما جایگاه در گروه جامع/صنعتی/تخصصی نیز برای تفسیر منصفانه‌تر نمایش داده می‌شود.</p></div><div className="compareGrid">{(["جامع","صنعتی","تخصصی"] as const).map(kind=><article className="glass compareCard" key={kind}><div className="panelHead"><h2>{kind}</h2><span className="scorePill">{finalRanking.filter(r=>r.kind===kind).length}</span></div><div className="leaderboard">{finalRanking.filter(r=>r.kind===kind).slice(0,6).map(r=><Link href={`/universities/${r.universitySlug}`} key={r.universitySlug}><b>{String(r.rankWithinKind).padStart(2,"0")}</b><span>{r.nameFa}<small>رتبه کل {r.rank}</small></span><i style={{width:`${r.score}%`}}/><strong>{r.score}</strong></Link>)}</div></article>)}</div></section>
      <section className="section"><div className="sectionHead"><div><span className="kicker">NATIONAL AUDIT REGISTER</span><h2>دانشگاه‌های بدون رتبه قطعی</h2></div><p>Unranked به معنی ضعیف بودن نیست؛ یعنی شواهد عمومی برای امتیاز قابل دفاع کافی نیست.</p></div><div className="docTable glass"><div className="docRow docHead"><span>دانشگاه</span><span>وضعیت نهایی</span><span>Evidence</span><span>Confidence</span><span>پروفایل</span></div>{nonRanked.map(a=><div className="docRow" key={a.universitySlug}><strong>{a.nameFa}</strong><span>{a.finalAuditStatus}</span><span>{a.evidenceTier}</span><span>{a.confidence?`${a.confidence}%`:"—"}</span><Link href={`/universities/${a.universitySlug}`}>مشاهده ←</Link></div>)}</div></section>
    </>}
  </div>
}
