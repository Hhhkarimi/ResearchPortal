import { datasetSummary, isDemoMode, systematicAuditCatalog } from "@/lib/data";
import { DataModeBanner } from "@/components/data-mode-banner";
export const metadata={title:"وضعیت داده",description:"وضعیت ممیزی پرتال‌های معاونت پژوهش و فناوری و قواعد انتشار داده"};
export default function DataStatusPage(){const s=datasetSummary();return <div className="shell page articlePage"><div className="pageHero"><span className="kicker">DATA GOVERNANCE / LIVE STATUS</span><h1>وضعیت داده</h1><p>شفافیت درباره دامنه دانشگاه‌ها، First-pass Audit، پرتال‌های رسمی، واحدهای سازمانی، سامانه‌ها، اسناد و شرط انتشار RTPMI.</p></div><DataModeBanner demo={isDemoMode}/><article className="glass prose">
<h2>دامنه فعلی</h2><p><b>{s.universities}</b> دانشگاه/دانشگاه تخصصی غیرپزشکی در Catalog Production قرار دارند و First-pass Audit برای <b>{s.universities}/{s.universities}</b> تکمیل شده است. این عدد به معنی verified بودن همه پرتال‌ها یا تکمیل RTPMI نیست.</p>
<h2>ممیزی سیستماتیک</h2><p><b>{systematicAuditCatalog.length}</b> دانشگاهی که در Release قبلی در صف بودند اکنون پرونده مستقل Systematic Audit دارند. First-pass Queue برای Inventory فعلی صفر است؛ Follow-up برای حل هویت مستقیم پرتال یا ممیزی عمیق ساختار/اسناد جدا نگه داشته می‌شود.</p>
<h2>پرتال و داده عمیق</h2><p><b>{s.portalProfiles}</b> پروفایل پرتال Production، <b>{s.units}</b> رکورد واحد سازمانی/تابع، <b>{s.systems}</b> سامانه یا خدمت دیجیتال و <b>{s.documents}</b> سند verified وجود دارد. indirect evidence بدون ارتقای رسمی در Hold می‌ماند.</p>
<h2>دو حالت داده</h2><p><code>NEXT_PUBLIC_DATA_MODE=production</code> نمره synthetic منتشر نمی‌کند. <code>demo</code> فقط برای نمایش UI و نمودارهاست، Banner هشدار دارد و robots آن را noindex می‌کند.</p>
<h2>شرط انتشار رتبه واقعی</h2><p>پرتال، ساختار واحدها، اسناد و شواهد باید بازبینی شوند؛ سپس <code>auditStatus=verified</code> اجازه انتشار RTPMI می‌دهد. Validator و Data Layer هر دو این Gate را enforce می‌کنند.</p>
<h2>قاعده رابطه سازمانی</h2><p>کتابخانه، آزمایشگاه یا IT فقط زمانی به‌عنوان جزء ساختار معاونت ثبت می‌شود که منبع رسمی رابطه را پشتیبانی کند. «لینک شدن از پرتال» و «زیرمجموعه بودن» دو relation متفاوت‌اند. شاعا نیز به‌عنوان شبکه/سامانه مرتبط ثبت می‌شود، نه آزمایشگاه متعلق به دانشگاه.</p>
<h2>قاعده مهم</h2><p>«در بررسی پیدا نشد» معادل «وجود ندارد» نیست. نبود شواهد در Evidence Tier، Hold و Confidence منعکس می‌شود.</p>
</article></div>}
