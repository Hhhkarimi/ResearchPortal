import Link from "next/link";
import { datasetSummary } from "@/lib/data";
export const metadata={title:"داده باز | رصد پرتال پژوهش و فناوری",description:"دانلود داده‌های عمومی و ممیزی‌پذیر پروژه در قالب JSON برای پژوهش، بازتولید تحلیل و استفاده ماشینی."};
const files=[
  ["universities.json","فهرست دانشگاه‌ها و وضعیت ممیزی"],
  ["portals.json","پرتال‌های رسمی تأییدشده"],
  ["units.json","گراف واحدهای سازمانی"],
  ["systems.json","سامانه‌ها و خدمات مرتبط"],
  ["documents.json","اسناد، فرم‌ها و آیین‌نامه‌های verified"],
  ["evidence-ledger.json","دفتر عمومی شواهد"],
  ["audit-summary.json","خلاصه آماری ممیزی"],
  ["systematic-audit-summary.json","خلاصه ممیزی سیستماتیک ۸۵ دانشگاه"],
  ["systematic-audit.json","۶۹ پرونده ممیزی اولیه تکمیل‌شده"],
  ["follow-up-queue.json","صف Follow-up برای ممیزی عمیق/حل هویت"],
  ["discovery-hints.json","سرنخ‌های در انتظار ممیزی مستقیم"]
];
export default function DatasetsPage(){const s=datasetSummary();return <main className="shell page datasetsPage">
  <header className="pageHero"><span className="kicker">OPEN DATA / MACHINE READABLE</span><h1>داده‌ای که می‌شود <span>بازبینی و بازتولید</span> کرد</h1><p>نسخه عمومی Catalogها به‌صورت JSON منتشر می‌شود. ممیزی اولیه ۸۵/۸۵ از ممیزی عمیق و RTPMI جداست. Discovery Hint و رکوردهای Hold نباید به‌عنوان واقعیت نهایی یا ورودی Ranking تفسیر شوند.</p></header>
  <section className="datasetHero glass"><div><span className="kicker">CURRENT SNAPSHOT</span><h2>{s.universities} دانشگاه · {s.portalProfiles} پرتال · {s.units} واحد · {s.documents} سند</h2><p>هر Release همراه با manifest و Audit Trail ساخته می‌شود تا پژوهشگر بتواند نسخه مورد استفاده را ثبت کند.</p></div><a className="primaryBtn" href="/datasets/manifest.json">manifest.json ↙</a></section>
  <section className="section datasetGrid">{files.map(([name,desc])=><a className="glass datasetCard" href={`/datasets/${name}`} key={name} download>
    <span>JSON</span><strong>{name}</strong><p>{desc}</p><i>DOWNLOAD ↙</i>
  </a>)}</section>
  <section className="section glass dataLicense"><span className="kicker">RESPONSIBLE REUSE</span><h2>قواعد استفاده</h2><p>Metadata تولیدشده توسط پروژه برای تحلیل و بازتولید آزاد است؛ محتوای فایل‌ها و صفحات لینک‌شده متعلق به ناشر اصلی است. هنگام استفاده پژوهشی، نسخه Release و تاریخ Snapshot را ذکر کن.</p><div><Link className="ghostBtn" href="/evidence">دفتر شواهد</Link><Link className="ghostBtn" href="/methodology">روش‌شناسی</Link></div></section>
</main>}
