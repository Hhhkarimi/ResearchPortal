import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Vazirmatn } from "next/font/google";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { SITE_NAME, SITE_URL } from "@/lib/site";
import { isDemoMode } from "@/lib/data";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "رصد پرتال معاونت پژوهش و فناوری دانشگاه‌ها",
    template: `%s | ${SITE_NAME}`
  },
  description:
    "رصد داده‌محور پرتال معاونت پژوهش و فناوری دانشگاه‌های دولتی غیرپزشکی؛ ساختار سازمانی، آیین‌نامه‌ها، فرم‌ها، کتابخانه و مرکز اسناد، آزمایشگاه‌ها، شاعا، سامانه‌ها، IT و ارتباط با صنعت.",
  keywords: ["معاونت پژوهش و فناوری", "دانشگاه", "وزارت علوم", "آیین نامه پژوهشی", "فرم پژوهشی", "کتابخانه مرکزی", "مرکز اسناد", "آزمایشگاه مرکزی", "شاعا", "RTPMI"],
  applicationName: SITE_NAME,
  creator: SITE_NAME,
  category: "research portal observatory",
  openGraph: {
    type: "website",
    locale: "fa_IR",
    title: SITE_NAME,
    description: "رصد و ارزیابی پرتال معاونت‌های پژوهش و فناوری دانشگاه‌های دولتی غیرپزشکی",
    siteName: SITE_NAME,
    images: [{ url: "/og-default.svg", width: 1200, height: 630, alt: "داشبورد رصد پرتال معاونت پژوهش و فناوری" }]
  },
  twitter: {
    card: "summary_large_image",
    title: SITE_NAME,
    description: "ساختار، اسناد، آزمایشگاه‌ها، کتابخانه‌ها و سامانه‌های معاونت پژوهش و فناوری",
    images: ["/og-default.svg"]
  },
  robots: isDemoMode ? { index: false, follow: false, nocache: true } : { index: true, follow: true },
  icons: { icon: "/icon.svg" },
  manifest: "/manifest.webmanifest"
};

const vazirmatn = Vazirmatn({ subsets: ["arabic", "latin"], display: "swap", variable: "--font-vazirmatn" });

export const viewport: Viewport = { colorScheme: "dark", themeColor: "#070913" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl" className={vazirmatn.variable}>
      <body>
        <a className="skipLink" href="#main-content">پرش به محتوای اصلی</a>
        <div className="noise" aria-hidden="true" />
        <SiteHeader />
        <div id="main-content">{children}</div>
        <SiteFooter />
      </body>
    </html>
  );
}
