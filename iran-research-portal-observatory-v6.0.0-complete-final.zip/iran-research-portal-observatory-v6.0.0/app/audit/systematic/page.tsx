import Link from "next/link";
import { portalCatalog, systematicAuditCatalog, universityCatalog } from "@/lib/data";
import type { SystematicAuditOutcome } from "@/lib/types";

export const metadata={
  title:"ممیزی سیستماتیک ۸۵ دانشگاه | رصد پرتال پژوهش و فناوری",
  description:"نتیجه ممیزی اولیه هویت پرتال معاونت پژوهش و فناوری در کل Inventory پروژه، با تفکیک سطح شواهد و کارهای پیگیری."
};
const labels:Record<SystematicAuditOutcome,string>={
  "direct-official":"پرتال مستقیم رسمی","official-domain-reference":"ارجاع رسمی روی دامنه دانشگاه","official-channel-reference":"ارجاع کانال/رسانه رسمی","secondary-evidence":"شواهد ثانویه","unresolved":"حل‌نشده","rejected-false-positive":"False positive ردشده"
};
const tones:Record<SystematicAuditOutcome,string>={
  "direct-official":"auditA","official-domain-reference":"auditB","official-channel-reference":"auditB","secondary-evidence":"auditC","unresolved":"auditD","rejected-false-positive":"auditBlocked"
};
export default function SystematicAuditPage(){
  const baseline=universityCatalog.length-systematicAuditCatalog.length;
  const outcomeCounts=Object.keys(labels).map(k=>({key:k as SystematicAuditOutcome,count:systematicAuditCatalog.filter(x=>x.outcome===k).length}));
  return <main className="shell page systematicAuditPage">
    <header className="pageHero">
      <span className="kicker">SYSTEMATIC AUDIT / 85 OF 85</span>
      <h1>ممیزی اولیه <span>کل Inventory</span></h1>
      <p>این صفحه بین «بررسی‌شده»، «پرتال شناسایی‌شده» و «ممیزی عمیق/امتیازدهی‌شده» تفاوت می‌گذارد. ۸۵/۸۵ یعنی همه دانشگاه‌های Inventory حداقل یک دور جست‌وجو و طبقه‌بندی Evidence را گذرانده‌اند؛ نه اینکه همه RTPMI نهایی داشته باشند.</p>
    </header>
    <section className="systematicHero glass">
      <div><strong>85/85</strong><span>First-pass audit coverage</span></div>
      <div><strong>{portalCatalog.length}</strong><span>Portal identities in Production</span></div>
      <div><strong>{systematicAuditCatalog.length}</strong><span>New systematic audits</span></div>
      <div><strong>{baseline}</strong><span>Previously portal-audited baseline</span></div>
    </section>
    <section className="section auditOutcomeGrid">{outcomeCounts.map(x=><article className={`glass ${tones[x.key]}`} key={x.key}><span>{labels[x.key]}</span><strong>{x.count}</strong><small>{x.key}</small></article>)}</section>
    <section className="section glass systematicTablePanel">
      <div className="sectionHead"><div><span className="kicker">69 COMPLETED RECORDS</span><h2>پرونده ممیزی دانشگاه‌های باقی‌مانده</h2></div><p>Tier A/B/C/D کیفیت Evidence است؛ رکوردهای Hold وارد رتبه‌بندی و گراف سازمانی قطعی نمی‌شوند.</p></div>
      <div className="systematicTable">
        <div className="systematicRow systematicHead"><b>دانشگاه</b><span>نتیجه</span><span>Tier</span><span>Evidence</span><span>گام بعدی</span></div>
        {systematicAuditCatalog.map(a=>{const u=universityCatalog.find(x=>x.slug===a.universitySlug);return <article className="systematicRow" key={a.universitySlug}>
          <b><Link href={`/universities/${a.universitySlug}`}>{u?.nameFa||a.nameFa}</Link><small>{a.province} · {a.city}</small></b>
          <span className={`outcomeTag ${tones[a.outcome]}`}>{labels[a.outcome]}</span>
          <span><i className={`tierDot tier${a.evidenceTier}`}/>{a.evidenceTier}</span>
          <span>{a.evidenceUrls.length?a.evidenceUrls.slice(0,2).map((url,i)=><a key={url} href={url} target="_blank" rel="noreferrer">منبع {i+1} ↗</a>):<em>نیازمند منبع مستقیم</em>}</span>
          <span><code>{a.nextAction}</code>{a.observedSignals.length>0&&<small>{a.observedSignals.slice(0,2).join(" · ")}</small>}</span>
        </article>})}
      </div>
    </section>
    <section className="section auditMethod glass"><div><span className="kicker">WHAT 85/85 MEANS</span><h2>ممیزی اولیه کامل است؛ Deep Audit ادامه دارد</h2><p>برای هر دانشگاه Queryهای هویت معاونت، دامنه رسمی و نشانه‌های کتابخانه/آزمایشگاه/IT/صنعت بررسی شد. مواردی که Evidence مستقیم ندارند همچنان Hold هستند و هیچ امتیاز منفی بابت «پیدا نشدن» دریافت نمی‌کنند.</p></div><Link className="primaryBtn" href="/audit">بازگشت به Audit Command Center</Link></section>
  </main>
}
