import Link from "next/link";
import { auditPriority, datasetSummary, discoveryHintCatalog, evidenceLedger, followUpAuditCatalog, freshnessReport, portalCatalog, systematicAuditCatalog, systemCatalog, unitCatalog, universityCatalog } from "@/lib/data";
import type { PortalUnitType } from "@/lib/types";

const unitLabels: Record<PortalUnitType,string> = {
  "vice-presidency":"معاونت",
  "research-policy":"امور پژوهشی",
  "industry-society":"صنعت و جامعه",
  "technology-transfer":"فناوری / TTO",
  "library-documents":"کتابخانه و اسناد",
  "central-laboratory":"آزمایشگاه مرکزی",
  "research-laboratories":"آزمایشگاه پژوهشی",
  "information-technology":"IT",
  "publications":"انتشارات",
  "journals-scientometrics":"نشریات / علم‌سنجی",
  "research-centers":"مراکز پژوهشی",
  "ethics":"اخلاق پژوهش",
  "committees":"شورا / کمیته",
  "finance":"مالی پژوهش",
  "other":"سایر"
};

export const metadata = {
  title: "مرکز فرمان ممیزی پرتال‌ها | رصد پرتال پژوهش و فناوری",
  description: "وضعیت شفاف ممیزی پرتال معاونت پژوهش و فناوری دانشگاه‌های دولتی؛ پرتال‌های تأییدشده، واحدهای تابع، سامانه‌ها و صف بررسی."
};

export default function AuditPage(){
  const summary=datasetSummary();
  const pendingDeep=universityCatalog.filter(u=>u.auditStatus==="pending");
  const verifiedPortalSlugs=new Set(portalCatalog.map(p=>p.universitySlug));
  const coverage=Math.round((verifiedPortalSlugs.size/universityCatalog.length)*100);
  const unitCounts=Object.entries(unitLabels).map(([type,label])=>({
    type:type as PortalUnitType,label,count:unitCatalog.filter(u=>u.type===type).length,
    universities:new Set(unitCatalog.filter(u=>u.type===type).map(u=>u.universitySlug)).size
  })).filter(x=>x.count).sort((a,b)=>b.universities-a.universities);
  const max=Math.max(...unitCounts.map(x=>x.universities),1);
  const itUniversities=[...new Set(unitCatalog.filter(u=>u.type==="information-technology" && u.relationStatus==="verified").map(u=>u.universitySlug))];
  const libraryUniversities=[...new Set(unitCatalog.filter(u=>u.type==="library-documents" && u.relationStatus==="verified").map(u=>u.universitySlug))];
  const labUniversities=[...new Set(unitCatalog.filter(u=>["central-laboratory","research-laboratories"].includes(u.type) && u.relationStatus==="verified").map(u=>u.universitySlug))];
  const freshVerified=freshnessReport.filter((x:any)=>x.portalVerified && x.freshness==="fresh").length;
  const publishableEvidence=evidenceLedger.filter(x=>x.status==="publishable").length;
  return <main className="shell page auditPage">
    <header className="pageHero">
      <span className="kicker">AUDIT COMMAND CENTER / v6.0</span>
      <h1>شفافیتِ خودِ <span>فرآیند رصد</span></h1>
      <p>ممیزی اولیه Inventory اکنون ۸۵/۸۵ است. این صفحه عمداً بین «بررسی اولیه انجام‌شده»، «هویت پرتال قابل انتشار» و «ممیزی عمیق RTPMI» تفاوت می‌گذارد.</p>
    </header>

    <section className="auditHero glass">
      <div className="auditDial" style={{"--audit":`${coverage*3.6}deg`} as React.CSSProperties}>
        <div><strong>{coverage}%</strong><span>Portal identity coverage</span></div>
      </div>
      <div className="auditHeroCopy">
        <span className="kicker">PRODUCTION EVIDENCE</span>
        <h2>{verifiedPortalSlugs.size} پرتال رسمی از {universityCatalog.length} دانشگاه</h2>
        <p>پرتال تنها زمانی به این عدد اضافه می‌شود که هویت معاونت پژوهش و فناوری روی دامنه رسمی دانشگاه قابل اثبات باشد.</p>
        <div className="auditKpis auditKpisWide">
          <span><small>واحد سازمانی</small><b>{summary.units}</b></span>
          <span><small>سامانه / خدمت</small><b>{summary.systems}</b></span>
          <span><small>سند verified</small><b>{summary.documents}</b></span>
          <span><small>رتبه‌پذیر</small><b>{summary.scored}</b></span>
          <span><small>Evidence قابل انتشار</small><b>{publishableEvidence}</b></span>
          <span><small>پرتال تازه‌ممیزی‌شده</small><b>{freshVerified}</b></span>
          <span><small>ممیزی اولیه ملی</small><b>{universityCatalog.length}/{universityCatalog.length}</b></span>
          <span><small>پرونده سیستماتیک جدید</small><b>{systematicAuditCatalog.length}</b></span>
        </div>
      </div>
    </section>

    <section className="section auditSplit">
      <div className="glass panel">
        <div className="panelHead"><div><span className="kicker">ORGANIZATIONAL COVERAGE</span><h2>پوشش اجزای معاونت</h2></div><span className="scorePill">{unitCounts.length} TYPE</span></div>
        <div className="auditBars">{unitCounts.map((x,i)=><div className="auditBar" key={x.type}>
          <div><span>{x.label}</span><b>{x.universities} دانشگاه</b></div>
          <i><em style={{width:`${Math.max(5,(x.universities/max)*100)}%`,"--d":`${i*.035}s`} as React.CSSProperties}/></i>
          <small>{x.count} رکورد</small>
        </div>)}</div>
      </div>
      <div className="glass panel auditSignals">
        <div className="panelHead"><div><span className="kicker">HIGH-SIGNAL RELATIONSHIPS</span><h2>رابطه‌هایی که اثبات شده‌اند</h2></div></div>
        <article><span>IT زیر/در ساختار حوزه معاونت</span><strong>{itUniversities.length}</strong><p>فقط دانشگاه‌هایی که Evidence سازمانی دارند؛ لینک ساده به ICT کافی نیست.</p></article>
        <article><span>کتابخانه / مرکز اسناد</span><strong>{libraryUniversities.length}</strong><p>کتابخانه زمانی اینجا شمرده می‌شود که رابطه آن با پرتال یا ساختار حوزه قابل اثبات باشد.</p></article>
        <article><span>آزمایشگاه مرکزی / پژوهشی</span><strong>{labUniversities.length}</strong><p>شاعا جدا از خود آزمایشگاه و با رابطه national-related-system مدل می‌شود.</p></article>
        <article><span>سامانه‌های شناسایی‌شده</span><strong>{systemCatalog.length}</strong><p>هر سامانه یکی از روابط managed / unit-service / linked / national-related را دارد.</p></article>
      </div>
    </section>

    <section className="section">
      <div className="sectionHead"><div><span className="kicker">VERIFIED PORTAL IDENTITIES</span><h2>پرتال‌های واردشده به Production</h2></div><p>این فهرست به معنی «RTPMI کامل» نیست؛ یعنی هویت پرتال و بخشی از اکوسیستم آن با منبع رسمی ثبت شده است.</p></div>
      <div className="auditUniversityGrid">{universityCatalog.filter(u=>verifiedPortalSlugs.has(u.slug)).map(u=><Link className="glass auditUni" key={u.slug} href={`/universities/${u.slug}`}>
        <span>{u.city}</span><strong>{u.nameFa}</strong><small>{u.documentCount} سند · {unitCatalog.filter(x=>x.universitySlug===u.slug).length} واحد · {systemCatalog.filter(x=>x.universitySlug===u.slug).length} سامانه</small><i>VERIFIED PORTAL ↗</i>
      </Link>)}</div>
    </section>

    <section className="section glass signalMatrixPanel">
      <div className="sectionHead"><div><span className="kicker">PORTAL SIGNAL MATRIX</span><h2>DNA ساختاری پرتال‌های تأییدشده</h2></div><p>هر نقطه یعنی برای آن رابطه، Evidence رسمی در Catalog ثبت شده است؛ خانه خالی به معنی «عدم مشاهده در ممیزی فعلی» است، نه اثبات نبود.</p></div>
      <div className="signalMatrixWrap">
        <div className="signalMatrix">
          <div className="signalRow signalHead"><b>دانشگاه</b><span>پژوهش</span><span>صنعت</span><span>فناوری</span><span>کتابخانه</span><span>آزمایشگاه</span><span>IT</span></div>
          {universityCatalog.filter(u=>verifiedPortalSlugs.has(u.slug)).map(u=>{
            const types=new Set(unitCatalog.filter(x=>x.universitySlug===u.slug && x.relationStatus==="verified").map(x=>x.type));
            const signals=[types.has("research-policy"),types.has("industry-society"),types.has("technology-transfer"),types.has("library-documents"),types.has("central-laboratory")||types.has("research-laboratories"),types.has("information-technology")];
            return <Link href={`/universities/${u.slug}`} className="signalRow" key={u.slug}><b>{u.nameFa}</b>{signals.map((on,i)=><span key={i} className={on?"signalOn":"signalOff"}><i/>{on?"ثبت‌شده":"باز"}</span>)}</Link>
          })}
        </div>
      </div>
    </section>


    {discoveryHintCatalog.length>0&&<section className="section glass auditDiscoveryPanel">
      <div className="sectionHead"><div><span className="kicker">DISCOVERY HINTS / NON-PUBLISHABLE</span><h2>سرنخ‌هایی که هنوز وارد Production نشده‌اند</h2></div><p>این‌ها URLهای رسمی یا مسیرهای محتمل‌اند که هنوز نیاز به ممیزی مستقیم هویت پرتال و گراف سازمانی دارند.</p></div>
      <div className="auditDiscoveryGrid">{discoveryHintCatalog.map(h=>{const u=universityCatalog.find(x=>x.slug===h.universitySlug);return <article key={h.universitySlug}><div><span>{h.confidence}</span><i>HOLD</i></div><strong>{u?.nameFa||h.universitySlug}</strong><a href={h.candidateUrl} target="_blank" rel="noreferrer">{h.candidateUrl}</a><small>{h.nextAction.replaceAll("-"," ")}</small></article>})}</div>
      <Link href="/evidence" className="ghostBtn">مشاهده دفتر شواهد و Discovery Radar</Link>
    </section>}


    <section className="section glass priorityPanel">
      <div className="sectionHead"><div><span className="kicker">NEXT-BEST AUDITS</span><h2>صف ممیزی اولویت‌بندی‌شده</h2></div><p>اولویت از وجود homepage رسمی، Discovery Hint، نوع دانشگاه و حافظه false-positive محاسبه می‌شود؛ این امتیاز، RTPMI نیست.</p></div>
      <div className="priorityGrid">{(auditPriority as any[]).slice(0,12).map((q:any)=>{const u=universityCatalog.find(x=>x.slug===q.universitySlug);return <article key={q.universitySlug}><div><span>{q.priorityBand}</span><b>{q.priorityScore}</b></div><strong>{u?.nameFa||q.universitySlug}</strong><small>{(q.priorityReasons||[]).join(" · ")||"manual review"}</small>{q.candidateUrl&&<a href={q.candidateUrl} target="_blank" rel="noreferrer">candidate ↗</a>}</article>})}</div>
    </section>

    <section className="section glass pendingBoard">
      <div><span className="kicker">FIRST PASS COMPLETE / FOLLOW-UP OPEN</span><h2>۸۵/۸۵ دانشگاه ممیزی اولیه شدند</h2><p>صف First-pass اکنون صفر است. {followUpAuditCatalog.length} پرونده Follow-up برای حل هویت پرتال یا ممیزی عمیق ساختار/اسناد باز مانده؛ این مرحله با «ممیزی اولیه انجام نشده» متفاوت است.</p><Link href="/audit/systematic" className="ghostBtn">مشاهده نتیجه تک‌تک ۶۹ ممیزی جدید ←</Link></div>
      <div className="pendingCloud">{pendingDeep.slice(0,28).map(u=><Link key={u.slug} href={`/universities/${u.slug}`}>{u.nameFa}</Link>)}{pendingDeep.length>28&&<span>+{pendingDeep.length-28}</span>}</div>
    </section>
  </main>
}
