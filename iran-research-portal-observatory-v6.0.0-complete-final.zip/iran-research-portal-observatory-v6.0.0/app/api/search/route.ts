import { NextRequest, NextResponse } from "next/server";
import { universityCatalog, documentCatalog } from "@/lib/data";
export function GET(req: NextRequest) {
  const q=(req.nextUrl.searchParams.get("q")||"").normalize("NFKC").trim().toLowerCase().slice(0,100);
  if (!q) return NextResponse.json({results:[]},{headers:{"X-Robots-Tag":"noindex"}});
  const universities=universityCatalog.filter(u=>`${u.nameFa} ${u.nameEn} ${u.city} ${u.province||""}`.toLowerCase().includes(q)).slice(0,8)
    .map(u=>({kind:"university",title:u.nameFa,href:`/universities/${u.slug}`}));
  const documents=documentCatalog.filter(d=>`${d.title} ${d.type} ${d.topic}`.toLowerCase().includes(q)).slice(0,12)
    .map(d=>({kind:"document",title:d.title,href:`/documents/${d.id}`}));
  return NextResponse.json({results:[...universities,...documents]},{headers:{"Cache-Control":"public, max-age=30, s-maxage=300, stale-while-revalidate=600","X-Robots-Tag":"noindex"}});
}
