import { universityCatalog, isDemoMode, datasetSummary } from "@/lib/data";
import { DataModeBanner } from "@/components/data-mode-banner";
import { UniversityExplorer } from "@/components/university-explorer";

export const metadata = { title: "پرتال معاونت‌های پژوهش و فناوری", description: "فهرست پرتال معاونت پژوهش و فناوری دانشگاه‌های دولتی غیرپزشکی و وضعیت کشف/ممیزی ساختار، اسناد و واحدهای تابع" };

export default function UniversitiesPage() {
  const s=datasetSummary();
  return <div className="shell page">
    <div className="pageHero"><span className="kicker">PORTAL INDEX / {universityCatalog.length}</span><h1>پرتال معاونت‌های پژوهش و فناوری</h1><p>هر پروفایل از سایت اصلی دانشگاه شروع می‌شود و سپس پرتال معاونت، ساختار سازمانی، کتابخانه/مرکز اسناد، آزمایشگاه‌ها، سامانه‌ها، IT در صورت وابستگی، اسناد و خدمات فناوری را رصد می‌کند.</p></div>
    <div className="recordGrid"><div><small>دانشگاه‌ها</small><strong>{s.universities}</strong></div><div><small>پرتال کشف‌شده</small><strong>{s.portals}</strong></div><div><small>پروفایل رسمی pilot</small><strong>{s.portalProfiles}</strong></div><div><small>واحد سازمانی</small><strong>{s.units}</strong></div></div>
    <DataModeBanner demo={isDemoMode}/>
    <UniversityExplorer universities={universityCatalog}/>
  </div>
}
