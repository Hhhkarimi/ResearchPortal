import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { getUniversity, getUniversityDocuments, getUniversityUnits, getUniversitySystems, getPortal, universityCatalog, isDemoMode, finalRanking } from "@/lib/data";
import { ScoreOrbit } from "@/components/score-orbit";
import { MetricRadar } from "@/components/metric-radar";
import { MicroBars } from "@/components/micro-bars";
import { DataModeBanner } from "@/components/data-mode-banner";
import { JsonLd } from "@/components/json-ld";
import { PortalEcosystem } from "@/components/portal-ecosystem";
import { PortalSystems } from "@/components/portal-systems";
import { siteUrl } from "@/lib/site";

export function generateStaticParams() { return universityCatalog.map((u)=>({slug:u.slug})); }

export async function generateMetadata({ params }: { params: Promise<{slug:string}> }):Promise<Metadata> {
  const { slug } = await params; const u = getUniversity(slug);
  if(!u) return {title:"دانشگاه"};
  return {
    title:`پرتال معاونت پژوهش و فناوری ${u.nameFa}`,
    description:`رصد پرتال معاونت پژوهش و فناوری ${u.nameFa}: ساختار سازمانی، اسناد، کتابخانه و مرکز اسناد، آزمایشگاه‌ها، سامانه‌ها، IT و فناوری در صورت وجود شواهد رسمی.`,
    alternates:{canonical:`/universities/${u.slug}`},
    openGraph:{title:`پرتال پژوهش و فناوری ${u.nameFa}`,description:`ساختار، اسناد و خدمات پرتال معاونت پژوهش و فناوری ${u.nameFa}`}
  };
}

export default async function UniversityPage({ params }: { params: Promise<{slug:string}> }) {
  const { slug } = await params; const u = getUniversity(slug); if(!u) notFound();
  const docs = getUniversityDocuments(slug);
  const units = getUniversityUnits(slug);
  const systems = getUniversitySystems(slug);
  const portal = getPortal(slug);
  const radar = [
    u.metrics.documents,u.metrics.organizationalTransparency,u.metrics.libraryKnowledge,u.metrics.laboratories,
    u.metrics.digitalSystemsIT,u.metrics.industryTechnology,u.metrics.freshnessDataQuality,u.metrics.findabilityAccessibility
  ].map(v=>v||0);
  const scored=u.score!==null;
  const rankRecord=finalRanking.find(r=>r.universitySlug===slug);
  const hasLibrary=units.some(x=>x.type==="library-documents");
  const hasLabs=units.some(x=>x.type==="central-laboratory"||x.type==="research-laboratories");
  const hasIT=units.some(x=>x.type==="information-technology");
  const hasShaa=systems.some(x=>x.category==="laboratory-network" && x.nameFa.includes("شاعا"));
  return <div className="shell page">
    <JsonLd data={{
      "@context":"https://schema.org","@type":"EducationalOrganization",name:u.nameFa,alternateName:u.nameEn,
      url:siteUrl(`/universities/${u.slug}`),address:{"@type":"PostalAddress",addressLocality:u.city,addressRegion:u.province||u.city,addressCountry:"IR"},
      sameAs:[u.websiteUrl,u.researchUrl].filter(Boolean)
    }}/>
    {isDemoMode && <DataModeBanner demo/>}
    <div className="uniHero glass">
      <div className="uniIdentity"><div className="uniGlyph big">{u.nameEn.charAt(0)}</div><div><span className="kicker">{u.kind} · {u.city} · {u.province||""}</span><h1>{u.nameFa}</h1><p>{portal?.titleFa || "پرتال معاونت پژوهش و فناوری در انتظار کشف/تأیید"}</p><div className="linkRow">{u.websiteUrl?<a href={u.websiteUrl} target="_blank" rel="noopener noreferrer">سایت دانشگاه ↗</a>:<span className="pendingSource">سایت اصلی در انتظار تأیید</span>}{u.researchUrl?<a href={u.researchUrl} target="_blank" rel="noopener noreferrer">پرتال معاونت ↗</a>:<span className="pendingSource">پرتال معاونت در انتظار کشف</span>}</div></div></div>
      {scored?<div className="uniScoreBlock"><ScoreOrbit score={u.score||0}/><div><small>Assessment confidence</small><strong>{u.confidence}%</strong><span>{rankRecord?`رتبه ${rankRecord.rank} از ${finalRanking.length} · Band ${rankRecord.band}`:"Unranked"}</span><span>آخرین بررسی: {u.lastVerified || "—"}</span></div></div>:<div className="pendingScoreCard"><span>RTPMI</span><strong>—</strong><p>{u.auditStatus==="partial"?"داده واقعی ثبت شده؛ ارزیابی کامل نشده است.":"تا پایان ممیزی شواهد، امتیاز منتشر نمی‌شود."}</p></div>}
    </div>

    <section className="portalQuickFacts">
      <span className={portal?"ok":"pending"}><small>{portal?.mode==="embedded-research-surface"?"سطح رسمی پژوهش":"پرتال رسمی"}</small><b>{portal?(portal.mode==="embedded-research-surface"?"توکار / تأیید شده":"تأیید شده"):"در انتظار"}</b></span>
      <span className={hasLibrary?"ok":"pending"}><small>کتابخانه/مرکز اسناد</small><b>{hasLibrary?"در ساختار ثبت شده":"نامشخص"}</b></span>
      <span className={hasLabs?"ok":"pending"}><small>آزمایشگاه‌ها</small><b>{hasLabs?"در ساختار ثبت شده":"نامشخص"}</b></span>
      <span className={hasShaa?"ok":"pending"}><small>شاعا</small><b>{hasShaa?"پیوند رسمی ثبت شده":"نامشخص"}</b></span>
      <span className={hasIT?"ok":"pending"}><small>IT زیر معاونت</small><b>{hasIT?"رابطه تأیید شده":"تأیید نشده"}</b></span>
    </section>

    <section className="section compactSection">
      <div className="sectionHead"><div><span className="kicker">ORGANIZATION GRAPH</span><h2>اکوسیستم سازمانی معاونت</h2></div><p>وجود واحد فقط با Evidence رسمی ثبت می‌شود؛ برای نمونه IT صرفاً زمانی وارد این نمودار می‌شود که وابستگی سازمانی آن به معاونت قابل اثبات باشد.</p></div>
      <div className="glass panel"><PortalEcosystem units={units}/></div>
    </section>

    <section className="section compactSection">
      <div className="sectionHead"><div><span className="kicker">PORTAL SYSTEMS</span><h2>سامانه‌ها و زیرساخت‌های متصل</h2></div><p>نوع رابطه سامانه تفکیک می‌شود: سامانه حوزه معاونت، خدمت یک واحد تابع، یا سامانه ملی مرتبط مثل شاعا.</p></div>
      <div className="glass panel"><PortalSystems systems={systems}/></div>
    </section>

    <div className="profileGrid">
      <section className="glass panel"><div className="panelHead"><div><span className="kicker">PORTAL DNA</span><h2>پروفایل بلوغ پرتال</h2></div></div>{scored?<MetricRadar values={radar}/>:<div className="profilePending"><i>◌</i><strong>ASSESSMENT LOCKED</strong><p>نمودار پس از تکمیل ممیزی ساختار، اسناد، کتابخانه، آزمایشگاه، سامانه‌ها، فناوری و UX فعال می‌شود.</p></div>}</section>
      <section className="glass panel"><div className="panelHead"><div><span className="kicker">EVIDENCE STATUS</span><h2>وضعیت شواهد</h2></div></div>{scored?<MicroBars items={[
        {label:"اسناد",value:u.metrics.documents||0},{label:"ساختار",value:u.metrics.organizationalTransparency||0},{label:"کتابخانه",value:u.metrics.libraryKnowledge||0},{label:"آزمایشگاه",value:u.metrics.laboratories||0},{label:"سامانه‌ها/IT",value:u.metrics.digitalSystemsIT||0},{label:"صنعت/فناوری",value:u.metrics.industryTechnology||0}
      ]}/>:<div className="evidenceChecklist"><span className={u.websiteUrl?"ok":"pending"}>سایت دانشگاه <b>{u.websiteUrl?"✓":"…"}</b></span><span className={portal?"ok":"pending"}>پرتال معاونت <b>{portal?"✓":"…"}</b></span><span className={units.length?"ok":"pending"}>ساختار سازمانی <b>{units.length||"…"}</b></span><span className={systems.length?"ok":"pending"}>سامانه‌ها <b>{systems.length||"…"}</b></span><span className={docs.some(d=>d.evidence==="verified")?"ok":"pending"}>اسناد verified <b>{docs.filter(d=>d.evidence==="verified").length||"…"}</b></span></div>}</section>
    </div>

    {portal && <section className="section compactSection"><div className="glass portalEvidenceCard"><div><span className="kicker">OFFICIAL PORTAL EVIDENCE</span><h2>{portal.titleFa}</h2><p>{portal.notes?.join(" ")}</p></div><div className="recordGrid"><div><small>آخرین بررسی</small><strong>{portal.lastVerified||"—"}</strong></div><div><small>تلفن</small><strong>{portal.contact?.phone||"—"}</strong></div><div><small>واحد ثبت‌شده</small><strong>{units.length}</strong></div><div><small>سامانه ثبت‌شده</small><strong>{systems.length}</strong></div></div><a className="primaryBtn inlineBtn" href={portal.url} target="_blank" rel="noopener noreferrer">{portal.mode==="embedded-research-surface"?"باز کردن صفحه رسمی پژوهش ↗":"باز کردن پرتال رسمی ↗"}</a></div></section>}

    <section className="section compactSection">
      <div className="sectionHead"><div><span className="kicker">DOCUMENT INTELLIGENCE</span><h2>اسناد و فرم‌های معاونت</h2></div><Link href={`/documents?university=${u.slug}`}>مشاهده همه ←</Link></div>
      <div className="docTable glass">
        <div className="docRow docHead"><span>عنوان</span><span>نوع</span><span>موضوع</span><span>وضعیت</span><span>لینک</span></div>
        {docs.length ? docs.map(d=><div className="docRow" key={d.id}><strong><Link href={`/documents/${d.id}`}>{d.title}</Link></strong><span>{d.type}</span><span>{d.topic}</span><span className={`status ${d.status}`}>{d.status}</span>{d.evidence === "verified" && d.url ? <a href={d.url} target="_blank" rel="noopener noreferrer">باز کردن ↗</a>:<span className="pendingSource">در انتظار منبع</span>}</div>) :
        <div className="emptyState">هنوز سند ممیزی‌شده‌ای برای این پرتال ثبت نشده است.</div>}
      </div>
    </section>
  </div>
}
