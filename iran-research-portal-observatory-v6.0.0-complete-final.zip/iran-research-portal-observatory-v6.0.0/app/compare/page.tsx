import { universityCatalog, isDemoMode } from "@/lib/data";
import { DataModeBanner } from "@/components/data-mode-banner";
import { CompareLab } from "@/components/compare-lab";

export const metadata = { title: "مقایسه پرتال معاونت‌ها", description:"مقایسه شواهد، RTPMI، پوشش واحدها و اسناد پرتال‌های معاونت پژوهش و فناوری." };
export default function ComparePage() {
  return <div className="shell page"><div className="pageHero"><span className="kicker">PORTAL COMPARE LAB</span><h1>مقایسه پرتال معاونت‌ها</h1><p>مقایسه هم‌زمان RTPMI، Confidence، وضعیت پرتال، پوشش اسناد و ابعاد کتابخانه، آزمایشگاه، سامانه‌ها/IT و صنعت/فناوری؛ بدون تبدیل داده ناموجود به صفر.</p></div><DataModeBanner demo={isDemoMode}/><CompareLab universities={universityCatalog}/></div>
}
