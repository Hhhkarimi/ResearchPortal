import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";
import { isDemoMode } from "@/lib/data";

export default function robots(): MetadataRoute.Robots {
  if (isDemoMode) return { rules: [{ userAgent: "*", disallow: "/" }] };
  return {
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/api/"] },
      { userAgent: ["GPTBot","ChatGPT-User","OAI-SearchBot","Google-Extended","ClaudeBot","PerplexityBot"], allow: "/", disallow: ["/api/"] }
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL
  };
}
