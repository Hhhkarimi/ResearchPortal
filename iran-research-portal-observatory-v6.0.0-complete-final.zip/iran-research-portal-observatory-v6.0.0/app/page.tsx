import Link from "next/link";
import taxonomy from "@/data/taxonomy/document-taxonomy.json";
import { universityCatalog, rankedUniversities, datasetSummary, documentCatalog, isDemoMode, unitCatalog, systemCatalog } from "@/lib/data";
import { ScoreOrbit } from "@/components/score-orbit";
import { ViralScatter } from "@/components/viral-scatter";
import { CoverageHeatmap } from "@/components/coverage-heatmap";
import { MicroBars } from "@/components/micro-bars";
import { DataModeBanner } from "@/components/data-mode-banner";
import { ScopePulse } from "@/components/scope-pulse";
import { TopicGalaxy } from "@/components/topic-galaxy";
import { JsonLd } from "@/components/json-ld";
import { siteUrl } from "@/lib/site";

export default function HomePage() {
  const summary = datasetSummary();
  const leader = rankedUniversities[0];
  const score = summary.averageScore ?? 0;
  const unitTypes = new Set(unitCatalog.map(u=>u.type)).size;
  return (
    <>
      <JsonLd data={{
        "@context":"https://schema.org",
        "@type":"Dataset",
        name:"Iran Research & Technology Portal Observatory — RTPMI",
        description:"داده‌های رصد پرتال معاونت پژوهش و فناوری دانشگاه‌های دولتی غیرپزشکی، شامل ساختار سازمانی، اسناد، کتابخانه و مرکز اسناد، آزمایشگاه‌ها، سامانه‌ها و فناوری.",
        url:siteUrl("/"), inLanguage:"fa", isAccessibleForFree:true,
        measurementTechnique:"RTPMI 4.0 evidence-derived portal methodology",
        creator:{"@type":"Organization",name:"رصد پرتال پژوهش و فناوری",url:siteUrl("/")}
      }}/>
      <section className="hero">
        <div className="heroGlow g1"/><div className="heroGlow g2"/>
        <div className="shell heroGrid">
          <div className="heroCopy">
            <span className="eyebrow"><i/> RESEARCH & TECHNOLOGY PORTAL OBSERVATORY</span>
            <h1>رصد زنده‌ی <span>پرتال معاونت پژوهش و فناوری</span> دانشگاه‌ها</h1>
            <p>ساختار معاونت، آیین‌نامه‌ها و فرم‌ها، کتابخانه و مرکز اسناد، آزمایشگاه‌های مرکزی و پژوهشی، شاعا، سامانه‌های پژوهشی، IT در صورت وابستگی سازمانی، انتقال فناوری و ارتباط با صنعت — همه با Evidence رسمی و قابل ردیابی.</p>
            <div className="heroActions">
              <Link className="primaryBtn" href="/universities">رصد پرتال دانشگاه‌ها <b>↗</b></Link>
              <Link className="ghostBtn" href="/documents">جستجوی اسناد <b>⌕</b></Link>
              <Link className="ghostBtn" href="/evidence">دفتر شواهد <b>◎</b></Link>
              <Link className="ghostBtn" href="/audit/systematic">ممیزی ۸۵ دانشگاه <b>✓</b></Link>
            </div>
            <div className="trustRow"><span>RTPMI 4.0</span><span>Portal-first</span><span>Evidence-first</span><span>Git-versioned</span><span>No medical universities</span></div>
          </div>
          <div className="heroVisual glass">
            <div className="visualTop"><span>{isDemoMode?"Portal demo pulse":"Portal audit pulse"}</span><span className="liveDot">{isDemoMode?"DEMO":"LIVE DATA"}</span></div>
            {isDemoMode ? <>
              <div className="heroScore"><ScoreOrbit score={score}/><div className="scoreContext"><small>میانگین RTPMI نمایشی</small><strong>{score}</strong><span>برای تست ویژوال‌ها</span></div></div>
              <div className="sparkline" aria-hidden="true">{[24,38,31,52,47,63,58,76,72,84,78,92].map((v,i)=><i key={i} style={{height:`${v}%`, "--i":i} as React.CSSProperties}/>)}</div>
            </> : <div className="heroScope"><ScopePulse universities={universityCatalog}/></div>}
            <div className="heroMetrics">
              <span><small>دانشگاه در دامنه</small><b>{summary.universities}</b></span>
              <span><small>ممیزی اولیه</small><b>{summary.universities}/{summary.universities}</b></span>
              <span><small>پرتال Production</small><b>{summary.portalProfiles}</b></span>
              <span><small>واحد سازمانی ثبت‌شده</small><b>{summary.units}</b></span>
            </div>
          </div>
        </div>
      </section>

      <div className="shell"><DataModeBanner demo={isDemoMode}/></div>

      <section className="shell statStrip">
        <article><small>پروفایل پرتال Production</small><strong>{summary.portalProfiles}</strong><em>85/85 first-pass audited</em></article>
        <article><small>واحدهای سازمانی ثبت‌شده</small><strong>{summary.units}</strong><em>{unitTypes} نوع واحد</em></article>
        <article><small>سامانه‌های مرتبط</small><strong>{summary.systems}</strong><em>رابطه هر سامانه ثبت می‌شود</em></article>
        <article><small>اسناد verified</small><strong>{summary.documents}</strong><em>لینک مستقیم + صفحه والد</em></article>
      </section>

      <section className="shell section">
        <div className="sectionHead"><div><span className="kicker">SIGNATURE VISUAL / 01</span><h2>Portal Constellation</h2></div><p>{rankedUniversities.length?"موقعیت نقاط از ابعاد بلوغ پرتال می‌آید.":"پیش از تکمیل ممیزی، نمودار فقط گستره پرتال‌های دانشگاهی را نشان می‌دهد و رتبه القا نمی‌کند."}</p></div>
        <div className="glass chartCard"><ViralScatter universities={universityCatalog}/></div>
      </section>

      <section className="shell section twoCol viralGrid">
        <div className="glass panel"><div className="panelHead"><div><span className="kicker">SIGNATURE VISUAL / 02</span><h3>Portal Audit Rings</h3></div><Link href="/data-status">وضعیت داده ←</Link></div><ScopePulse universities={universityCatalog}/></div>
        <div className="glass panel"><div className="panelHead"><div><span className="kicker">SIGNATURE VISUAL / 03</span><h3>Document Topic Galaxy</h3></div><Link href="/documents">موتور اسناد ←</Link></div><TopicGalaxy topics={taxonomy.topics} documents={documentCatalog}/></div>
      </section>

      <section className="shell section portalScopeSection">
        <div className="sectionHead"><div><span className="kicker">PORTAL ECOSYSTEM</span><h2>رصد فقط صفحه معاونت نیست</h2></div><p>هر واحد فقط وقتی وارد پروفایل می‌شود که رابطه‌اش با معاونت در منبع رسمی قابل اثبات باشد.</p></div>
        <div className="portalScopeGrid">
          {[
            ["کتابخانه و مرکز اسناد","OPAC، کتابخانه دیجیتال، مخزن، پایان‌نامه و خدمات اطلاع‌رسانی","LIBRARY"],
            ["آزمایشگاه‌ها","آزمایشگاه مرکزی، آزمایشگاه‌های پژوهشی، تجهیزات، رزرو خدمت و شاعا","LABS"],
            ["سامانه‌ها و IT","RTIS و سامانه‌های حوزه؛ IT فقط در صورت وابستگی سازمانی قابل اثبات","SYSTEMS"],
            ["صنعت و فناوری","قراردادها، انتقال فناوری، مالکیت فکری، TTO و ارتباط با جامعه","TECH"],
          ].map(([t,p,k])=><article className="scopeCard glass" key={k}><span>{k}</span><h3>{t}</h3><p>{p}</p></article>)}
        </div>
      </section>

      {leader ? <section className="shell section twoCol">
        <div className="glass panel"><div className="panelHead"><div><span className="kicker">DOCUMENT DNA</span><h3>ماتریس پوشش اسناد</h3></div><Link href="/documents">همه اسناد ←</Link></div><CoverageHeatmap universities={rankedUniversities}/></div>
        <div className="glass panel"><div className="panelHead"><div><span className="kicker">PORTAL LEADER PULSE</span><h3>{leader.nameFa}</h3></div><span className="scorePill">{leader.score}</span></div><MicroBars items={[
          {label:"اسناد",value:leader.metrics.documents || 0},{label:"ساختار",value:leader.metrics.organizationalTransparency || 0},{label:"کتابخانه",value:leader.metrics.libraryKnowledge || 0},{label:"آزمایشگاه",value:leader.metrics.laboratories || 0},{label:"سامانه‌ها/IT",value:leader.metrics.digitalSystemsIT || 0}
        ]}/></div>
      </section> : <section className="shell section"><div className="glass lockedRanking"><span className="kicker">RANKING SAFETY LOCK</span><h2>رتبه‌بندی Production هنوز قفل است.</h2><p>چند پرتال رسمی در پایلوت Production دارای داده واقعی هستند، اما تا تکمیل rubric تمام ابعاد، عدد RTPMI منتشر نمی‌شود. `partial` به معنی «داده واقعی اما ممیزی ناقص» است.</p><Link href="/methodology" className="ghostBtn">روش‌شناسی RTPMI</Link></div></section>}

      <section className="shell section manifesto"><span className="kicker">EVIDENCE MODEL</span><h2>هر ادعا باید <span>منبع، رابطه سازمانی و تاریخ بررسی</span> داشته باشد.</h2><div className="featureGrid">
        <article><b>01</b><h3>Portal Discovery</h3><p>کشف پرتال رسمی معاونت از دامنه دانشگاه و منابع رسمی.</p></article>
        <article><b>02</b><h3>Organization Graph</h3><p>ثبت واحدهای تابع با رابطه verified/candidate؛ نه حدس از نام URL.</p></article>
        <article><b>03</b><h3>Document Intelligence</h3><p>آیین‌نامه، فرم، شیوه‌نامه، دستورالعمل و فرآیند با لینک مستقیم و parent page.</p></article>
        <article><b>04</b><h3>Human Publication Gate</h3><p>crawler فقط candidate می‌سازد؛ رتبه عمومی پس از بازبینی انسانی آزاد می‌شود.</p></article>
        <article><b>05</b><h3>Evidence Ledger</h3><p>هر URL و ادعای قابل انتشار در دفتر شواهد با وضعیت publishable / hold / blocked قابل ممیزی است.</p></article>
        <article><b>06</b><h3>Open Data</h3><p>Snapshotهای نسخه‌بندی‌شده دانشگاه، پرتال، واحد، سامانه، سند و audit برای پژوهش و بازاستفاده عمومی.</p></article>
      </div></section>

      <section className="shell ctaPanel"><div><span className="kicker">START EXPLORING</span><h2>از ساختار معاونت تا آخرین فرم پژوهشی.</h2></div><div className="heroActions"><Link className="primaryBtn" href="/universities">ورود به پرتال‌ها</Link><Link className="ghostBtn" href="/methodology">روش‌شناسی</Link><Link className="ghostBtn" href="/datasets">داده باز</Link></div></section>
    </>
  );
}
