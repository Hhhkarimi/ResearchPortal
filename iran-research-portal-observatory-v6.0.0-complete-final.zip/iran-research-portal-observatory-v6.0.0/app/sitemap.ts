import type { MetadataRoute } from "next";
import { documentCatalog, universityCatalog, isDemoMode } from "@/lib/data";
import { SITE_URL } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  if (isDemoMode) return [];
  const paths=["","/universities","/documents","/rankings","/compare","/methodology","/audit","/audit/systematic","/audit/final","/evidence","/datasets","/data-status","/security"];
  const base=paths.map((p)=>({url:`${SITE_URL}${p}`,changeFrequency:"weekly" as const,priority:p===""?1:.8}));
  const universities=universityCatalog.map((u)=>({url:`${SITE_URL}/universities/${u.slug}`,changeFrequency:"weekly" as const,priority:.7,lastModified:u.lastVerified||undefined}));
  const documents=documentCatalog.filter((d)=>d.evidence==="verified").map((d)=>({url:`${SITE_URL}/documents/${d.id}`,changeFrequency:"monthly" as const,priority:.65,lastModified:d.lastVerified||undefined}));
  return [...base,...universities,...documents];
}
