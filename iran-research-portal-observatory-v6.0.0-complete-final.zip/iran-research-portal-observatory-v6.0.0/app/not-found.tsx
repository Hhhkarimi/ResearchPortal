import Link from "next/link";

export default function NotFound() {
  return (
    <main className="shell section notFoundPage">
      <span className="eyebrow">404 · DATA NODE NOT FOUND</span>
      <h1>این رکورد در رصد پژوهش پیدا نشد.</h1>
      <p>ممکن است URL تغییر کرده باشد یا رکورد هنوز وارد دامنه ممیزی نشده باشد.</p>
      <div className="heroActions">
        <Link className="button primary" href="/universities">دانشگاه‌ها</Link>
        <Link className="button ghost" href="/documents">اسناد پژوهشی</Link>
      </div>
    </main>
  );
}
