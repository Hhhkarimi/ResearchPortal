import { documentCatalog, universityCatalog, isDemoMode } from "@/lib/data";
import { DataModeBanner } from "@/components/data-mode-banner";
import { DocumentExplorer } from "@/components/document-explorer";
export const metadata = { title: "موتور اسناد پژوهشی", description:"جست‌وجوی آیین‌نامه، فرم، شیوه‌نامه، دستورالعمل و سایر اسناد پژوهش و فناوری." };

export default function DocumentsPage() {
  return <div className="shell page">
    <div className="pageHero"><span className="kicker">DOCUMENT INTELLIGENCE</span><h1>موتور اسناد پژوهشی</h1><p>جست‌وجوی آیین‌نامه‌ها، فرم‌ها، شیوه‌نامه‌ها و دستورالعمل‌ها به تفکیک دانشگاه و موضوع؛ رکورد verified به منبع رسمی متصل است.</p></div>
    <DataModeBanner demo={isDemoMode}/>
    <DocumentExplorer documents={documentCatalog} universities={universityCatalog}/>
  </div>
}
