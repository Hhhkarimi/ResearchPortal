import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { documentCatalog, getDocument, getUniversity } from "@/lib/data";
import { JsonLd } from "@/components/json-ld";
import { siteUrl } from "@/lib/site";

export function generateStaticParams(){return documentCatalog.map((d)=>({id:d.id}));}

export async function generateMetadata({params}:{params:Promise<{id:string}>}):Promise<Metadata>{
  const {id}=await params; const d=getDocument(id); if(!d) return {title:"سند پژوهشی"};
  const u=getUniversity(d.universitySlug);
  return {
    title:d.title,
    description:`${d.type} در موضوع ${d.topic}${u?` — ${u.nameFa}`:""}`,
    alternates:{canonical:`/documents/${d.id}`},
    robots:d.evidence==="verified"?{index:true,follow:true}:{index:false,follow:true}
  };
}

export default async function DocumentPage({params}:{params:Promise<{id:string}>}){
  const {id}=await params; const d=getDocument(id); if(!d) notFound(); const u=getUniversity(d.universitySlug);
  const verified=d.evidence==="verified";
  return <div className="shell page articlePage">
    {verified && <JsonLd data={{
      "@context":"https://schema.org","@type":"DigitalDocument",name:d.title,url:siteUrl(`/documents/${d.id}`),
      encodingFormat:d.format,about:d.topic,datePublished:d.publishedDate||undefined,dateModified:d.lastVerified||undefined,
      isPartOf:u?{"@type":"EducationalOrganization",name:u.nameFa,url:siteUrl(`/universities/${u.slug}`)}:undefined,
      sameAs:d.url||undefined,inLanguage:"fa"
    }}/>} 
    <div className="pageHero"><span className="kicker">DOCUMENT RECORD / {d.evidence.toUpperCase()}</span><h1>{d.title}</h1><p>{u?.nameFa} · {d.type} · {d.topic}</p></div>
    <article className="glass prose documentRecord">
      <div className="recordGrid">
        <div><small>وضعیت</small><strong className={`status ${d.status}`}>{d.status}</strong></div>
        <div><small>Evidence</small><strong>{d.evidence}</strong></div>
        <div><small>فرمت</small><strong>{d.format}</strong></div>
        <div><small>آخرین بررسی</small><strong>{d.lastVerified||"در انتظار ممیزی"}</strong></div>
      </div>
      <h2>منبع</h2>
      {verified && d.url?<a className="primaryBtn inlineBtn" href={d.url} target="_blank" rel="noopener noreferrer">باز کردن منبع رسمی ↗</a>:<p>این رکورد هنوز منبع تأییدشده عمومی ندارد و برای موتورهای جست‌وجو noindex شده است.</p>}
      {d.parentUrl && <p>صفحه والد: <a href={d.parentUrl} target="_blank" rel="noopener noreferrer">مشاهده ↗</a></p>}
      {u && <p><Link href={`/universities/${u.slug}`}>بازگشت به پروفایل {u.nameFa} ←</Link></p>}
    </article>
  </div>
}
