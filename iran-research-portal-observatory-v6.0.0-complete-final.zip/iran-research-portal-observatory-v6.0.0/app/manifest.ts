import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "رصد پرتال معاونت پژوهش و فناوری",
    short_name: "رصد پرتال پژوهش",
    description: "Research & Technology Vice-Presidency Portal Observatory",
    start_url: "/", display: "standalone", background_color: "#070913", theme_color: "#070913", lang: "fa", dir: "rtl",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }]
  };
}
