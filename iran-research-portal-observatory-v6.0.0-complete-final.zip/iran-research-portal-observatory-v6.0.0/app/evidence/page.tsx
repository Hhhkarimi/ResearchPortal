import Link from "next/link";
import { evidenceLedger, discoveryHintCatalog, universityCatalog } from "@/lib/data";

export const metadata={
  title:"دفتر شواهد | رصد پرتال معاونت پژوهش و فناوری",
  description:"دفتر عمومی شواهد پروژه؛ تفکیک داده قابل انتشار، رکورد نیازمند بازبینی، Discovery Hint و مبدأ ردشده."
};

const kindLabels:Record<string,string>={portal:"پرتال",unit:"واحد سازمانی",system:"سامانه / خدمت",document:"سند", "discovery-hint":"Discovery Hint", "systematic-audit":"ممیزی اولیه", "rejected-origin":"مبدأ ردشده"};
const statusLabels:Record<string,string>={publishable:"قابل انتشار",review:"نیازمند بازبینی",hold:"Hold",blocked:"مسدود"};

export default function EvidencePage(){
  const publishable=evidenceLedger.filter(x=>x.status==="publishable");
  const hold=evidenceLedger.filter(x=>x.status==="hold");
  const blocked=evidenceLedger.filter(x=>x.status==="blocked");
  const kinds=Object.entries(kindLabels).map(([kind,label])=>({kind,label,count:evidenceLedger.filter(x=>x.kind===kind).length})).filter(x=>x.count);
  const recent=[...evidenceLedger].sort((a,b)=>(b.lastVerified||"").localeCompare(a.lastVerified||"")).slice(0,24);
  return <main className="shell page evidencePage">
    <header className="pageHero evidenceHero">
      <span className="kicker">EVIDENCE LEDGER / PUBLIC AUDIT TRAIL</span>
      <h1>هر ادعا باید <span>ردّ منبع</span> داشته باشد</h1>
      <p>این دفتر، Evidence پشت پرتال‌ها، واحدها، سامانه‌ها و اسناد را از Discovery Hint جدا می‌کند. رکورد Hold یا Blocked هیچ‌وقت به‌عنوان واقعیت نهایی وارد RTPMI نمی‌شود.</p>
    </header>

    <section className="evidenceKpis">
      <article className="glass"><small>کل رکوردهای Evidence</small><strong>{evidenceLedger.length}</strong><span>LEDGER RECORDS</span></article>
      <article className="glass"><small>قابل انتشار</small><strong>{publishable.length}</strong><span>PUBLICATION-SAFE</span></article>
      <article className="glass"><small>Hold / نیازمند پیگیری</small><strong>{hold.length}</strong><span>NOT A VERIFIED FACT</span></article>
      <article className="glass"><small>Blocked / False positive</small><strong>{blocked.length}</strong><span>DISCOVERY MEMORY</span></article>
    </section>

    <section className="section evidenceSplit">
      <div className="glass panel">
        <div className="panelHead"><div><span className="kicker">EVIDENCE COMPOSITION</span><h2>ترکیب دفتر شواهد</h2></div></div>
        <div className="evidenceKindGrid">{kinds.map((x,i)=><article key={x.kind}>
          <span>{x.label}</span><strong>{x.count}</strong><i><em style={{width:`${Math.max(8,x.count/evidenceLedger.length*100)}%`,"--d":`${i*.04}s`} as React.CSSProperties}/></i>
        </article>)}</div>
      </div>
      <div className="glass panel evidenceRules">
        <span className="kicker">PUBLICATION FIREWALL</span><h2>چه چیزی حق ورود به Ranking دارد؟</h2>
        <p>فقط رابطه‌ای که با منبع رسمی مستقیم یا cross-link رسمی قابل اثبات باشد. URL کشف‌شده در ایندکس، کانال یا موتور جست‌وجو فقط یک سرنخ برای ممیزی بعدی است.</p>
        <div className="evidenceRule"><b>01</b><span><strong>Direct official</strong><small>قابل استفاده در ارزیابی پس از کنترل محتوای صفحه</small></span></div>
        <div className="evidenceRule"><b>02</b><span><strong>Official cross-link</strong><small>رابطه از پرتال رسمی به زیردامنه/سامانه رسمی اثبات می‌شود</small></span></div>
        <div className="evidenceRule muted"><b>03</b><span><strong>Indexed official URL</strong><small>فقط Discovery Hint؛ امتیاز و رابطه سازمانی تولید نمی‌کند</small></span></div>
        <Link className="ghostBtn evidenceMethodBtn" href="/methodology">مشاهده روش‌شناسی Evidence ←</Link>
      </div>
    </section>

    {discoveryHintCatalog.length>0&&<section className="section">
      <div className="sectionHead"><div><span className="kicker">DISCOVERY RADAR</span><h2>سرنخ‌های رسمی در انتظار ممیزی مستقیم</h2></div><p>این کارت‌ها عمداً وارد شمار «پرتال‌های تأییدشده» نمی‌شوند.</p></div>
      <div className="discoveryGrid">{discoveryHintCatalog.map(h=>{
        const u=universityCatalog.find(x=>x.slug===h.universitySlug);
        return <article className="glass discoveryCard" key={h.universitySlug}>
          <div className="discoveryTop"><span>{h.confidence.toUpperCase()}</span><i>HOLD</i></div>
          <h3>{u?.nameFa||h.universitySlug}</h3>
          <a href={h.candidateUrl} target="_blank" rel="noreferrer">{h.candidateUrl}</a>
          <ul>{h.signals.slice(0,3).map(s=><li key={s}>{s}</li>)}</ul>
          <footer><small>{h.sourceClass}</small><b>{h.nextAction.replaceAll("-"," ")}</b></footer>
        </article>
      })}</div>
    </section>}

    <section className="section glass ledgerPanel">
      <div className="sectionHead"><div><span className="kicker">RECENT EVIDENCE</span><h2>نمونه رکوردهای دفتر شواهد</h2></div><p>URL منبع و URL مقصد جدا نگه داشته می‌شوند تا منشأ رابطه قابل ممیزی باشد.</p></div>
      <div className="ledgerTable">
        <div className="ledgerRow ledgerHead"><b>دانشگاه / رکورد</b><span>نوع</span><span>وضعیت</span><span>آخرین بررسی</span><span>منبع</span></div>
        {recent.map((r,i)=><div className="ledgerRow" key={`${r.kind}-${r.universitySlug}-${i}`}>
          <b><small>{r.university}</small>{r.title}</b>
          <span>{kindLabels[r.kind]||r.kind}</span>
          <span className={`ledgerStatus ${r.status}`}>{statusLabels[r.status]||r.status}</span>
          <span dir="ltr">{r.lastVerified||"—"}</span>
          <span>{r.sourceUrl?<a href={r.sourceUrl} target="_blank" rel="noreferrer">SOURCE ↗</a>:"—"}</span>
        </div>)}
      </div>
    </section>
  </main>
}
