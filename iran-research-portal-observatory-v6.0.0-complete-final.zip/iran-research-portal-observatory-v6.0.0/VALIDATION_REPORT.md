# Validation Report — v6.0.0 Complete Final

Validation date: **2026-08-10**

## Release result

- Data pipeline / generated artifacts: **PASS**
- Data validation: **PASS**
- Release gate: **PASS**
- Final audit coverage: **85 / 85**
- Evidence-qualified numeric rankings: **18**
- Explicitly Unranked universities: **67**
- Synthetic Production scores: **0**

## Production snapshot

- Official portal / research-surface identities: **20**
- Organizational-unit records: **197**
- Systems / services: **99**
- Verified document records: **52**
- Evidence Ledger records: **440**
  - publishable: **372**
  - hold: **63**
  - blocked: **5**
- Final comparison matrix: **18** ranked records × 8 RTPMI dimensions
- National comparison register: **85 / 85** universities

## Static QA performed in the authoring environment

- TypeScript / TSX syntax-transpile check: **44 files, 0 errors**
- JSON parse: **127 files, 0 errors**
- SVG/XML parse: **5 files, 0 errors**
- GitHub Actions YAML parse: **8 files, 0 errors**
- Node `.mjs` syntax check: **16 files, 0 errors**
- RTPMI dimension weights: **1.0**
- Ranking eligibility gate: direct verified portal + **Confidence >= 65**
- Final-audit uniqueness/coverage: **PASS**
- Ranking/catalog score consistency: **PASS**
- Publication Firewall / false-positive memory: **PASS**

## Dependency install / full Next.js build

A full local `npm install` / `next build` is **not claimed** in this authoring environment. The environment is forced through an internal npm mirror that returned `404` for development packages such as `@types/node`; direct access to `registry.npmjs.org` timed out. This is an execution-environment limitation, not a passed build.

The repository CI explicitly configures the public npm registry and is the final gate for:

`install → release:check → typecheck → lint → next build → npm audit`

Vazirmatn no longer requires a separate font npm package; it is configured through `next/font/google` and is self-hosted by Next.js at build/deployment time.

## Interpretation safeguard

RTPMI ranks the **public portal maturity/transparency of the Research & Technology Vice-Presidency ecosystem**. It is not a ranking of research output, faculty quality, scientific impact, funding, patents, or overall university performance. `Unranked` means the available public evidence did not satisfy the numeric ranking gate; it does not mean low research performance.
