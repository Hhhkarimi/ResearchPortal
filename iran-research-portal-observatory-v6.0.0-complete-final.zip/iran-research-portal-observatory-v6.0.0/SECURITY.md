# Security Policy

## اصول
- هیچ secret یا credential نباید در repository ذخیره شود.
- Crawler وارد صفحات نیازمند authentication نمی‌شود و هیچ کنترل دسترسی را دور نمی‌زند.
- فقط دامنه‌های رسمی allowlist‌شده crawl می‌شوند.
- محتوای خارجی به‌صورت HTML خام داخل React render نمی‌شود.
- URLهای خارجی فقط به‌عنوان لینک با `rel=noreferrer` نمایش داده می‌شوند.
- GitHub CodeQL و Dependabot در repository فعال هستند.

## Security Headers
در `next.config.ts`: CSP، HSTS، X-Content-Type-Options، X-Frame-Options، Referrer-Policy، Permissions-Policy و COOP/CORP.

> CSP فعلی برای سازگاری کامل با runtime توسعه، `unsafe-inline` و `unsafe-eval` دارد. پیش از production hardening مرحله دوم، nonce-based CSP را فعال کنید.

## گزارش آسیب‌پذیری
در صورت public شدن پروژه، یک آدرس ایمیل امنیتی یا GitHub private vulnerability reporting اضافه کنید.
