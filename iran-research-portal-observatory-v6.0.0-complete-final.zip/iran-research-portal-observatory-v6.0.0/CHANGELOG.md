# Changelog

## 6.0.0 — 85/85 Systematic First-Pass Audit (2026-08-10)

- Completed durable first-pass audit records for all 69 universities that were pending in v4.1.
- Reached 85/85 first-pass inventory coverage without claiming 85 verified portals.
- Added `/audit/systematic` national audit outcome explorer.
- Added `systematic-audit.json`, `follow-up-queue.json`, summary stats and JSON Schema.
- Promoted Shahid Chamran Ahvaz, Bonab and Birjand portal identities with evidence-sensitive levels.
- Added Shahid Chamran Ahvaz organizational graph: industry, research management, IT/security, library/documents, laboratory, publishing, growth/technology and research-centre signals from the official portal.
- Separated empty First-pass Queue from evidence-driven Follow-up Queue.
- Expanded Open Data and Evidence Ledger with systematic-audit records.
- Preserved zero synthetic Production RTPMI scores.

## 4.1.0 — Evidence Operations & Open Data (2026-08-10)

- Added public `/evidence` Evidence Ledger with publishable/hold/blocked firewall.
- Added `/datasets` Open Data Hub and reproducible JSON export pipeline.
- Added evidence-source policy separating direct official evidence from indexed discovery signals.
- Added four non-publishable Discovery Hints without inflating verified portal coverage.
- Added Audit Priority Engine and generated Review Packets for all 69 pending universities.
- Added freshness report and audit-priority visualization to Audit Command Center.
- Expanded link-health audit to university, portal, organizational-unit, system, document and provenance URLs.
- Added evidence/open-data/audit-operations documentation and stricter release validation.
- Kept Production at 16 verified portal identities and zero synthetic RTPMI scores.

## 4.0.0 — Portal Audit Command Center (2026-08-10)

- Added `/audit` transparent national audit-progress dashboard.
- Added generated audit statistics and build script.
- Added Qom, Arak and Zanjan official research/technology portal profiles.
- Expanded portal organization graph to 175 records, systems/services to 92 and verified documents to 49.
- Encoded official IT relationships for Arak and Zanjan where supported by portal evidence.
- Added SHAA as a Zanjan `national-related-system` relation.
- Kept Production score-free until full RTPMI review.

## 3.1.0 — evidence expansion (2026-08-10)

- expanded verified portal pilot from 4 to 8 universities
- added KNTU, Allameh Tabataba'i, Alzahra, and University of Art portal ecosystems
- modeled libraries/document centers, laboratories, SHAA-related links, and evidence-sensitive IT relations
- added verified official document links from Allameh, Alzahra, and University of Art
- added a separate portal-candidate discovery queue for Semnan, Ferdowsi Mashhad, Sharif, and Guilan
- preserved the publication gate: no RTPMI score before full verified audit

## 3.0.0
- Corrected scope from broad research intelligence to Research & Technology Vice-Presidency portal observatory.
- Added RTPMI 4.0.
- Added portal/unit/system data models and schemas.
- Added library, documentation, laboratory, SHAA, technology/industry and conditional IT scope.
- Added Portal Ecosystem and Portal Systems UI.
- Added official-source pilot data and portal discovery pipeline.
- Removed legacy research-hub discovery script.

## 2.0.0
- Evidence-gated Production/Demo separation, security hardening and 85-entry audit inventory.
