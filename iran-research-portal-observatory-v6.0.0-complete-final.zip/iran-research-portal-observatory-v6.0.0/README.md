# رصد پرتال معاونت پژوهش و فناوری
## Iran Research & Technology Portal Observatory

**v6.0 · RTPMI 4.0 · 85/85 Final Audit · Evidence-first · Next.js 16 · RTL · Vazirmatn · GitHub-first · Vercel-ready**

سامانه متن‌باز برای **رصد، طبقه‌بندی و ارزیابی پرتال عمومی معاونت پژوهش و فناوری** دانشگاه‌های دولتی غیرپزشکی در دامنه پروژه. موضوع این محصول عملکرد کل پژوهشی دانشگاه نیست؛ موضوع آن **شفافیت، بلوغ دیجیتال، ساختار سازمانی، اسناد، خدمات و زیرساخت‌های قابل مشاهده در اکوسیستم پرتال معاونت پژوهش و فناوری** است.

> **RTPMI شاخص اختصاصی پروژه است و رتبه‌بندی رسمی وزارت علوم نیست.** Production فقط برای پرتال‌های دارای Evidence مستقیم و Confidence کافی امتیاز منتشر می‌کند؛ Unranked به معنی عملکرد ضعیف نیست.

## وضعیت v6 در یک نگاه

- **85/85 دانشگاه:** ممیزی اولیه هویت پرتال انجام شده است.
- **69/69 دانشگاه باقی‌مانده از Release قبلی:** پرونده Systematic Audit مستقل دارند.
- **20** هویت پرتال/سطح رسمی پژوهش در Production.
- **197** رکورد واحد سازمانی.
- **99** سامانه/خدمت.
- **52** سند رسمی verified.
- **440** رکورد Evidence Ledger: 372 publishable، 63 hold و 5 blocked.
- **18** پرتال Evidence-qualified دارای RTPMI نهایی؛ **67** دانشگاه Unranked؛ **0** امتیاز ساختگی.
- First-pass queue: **0**؛ Follow-up queue: **69** برای ممیزی عمیق/حل هویت باقی‌مانده.

### نتیجه 69 ممیزی جدید

| Outcome | تعداد | اثر در Production |
|---|---:|---|
| direct-official | 4 | هویت پرتال قابل انتشار؛ ساختار/اسناد طبق Evidence تکمیل می‌شود |
| official-domain-reference | 4 | Hold تا حل URL مستقیم پرتال |
| official-channel-reference | 14 | Hold تا ثبت منبع مستقیم روی دامنه دانشگاه |
| secondary-evidence | 24 | Hold؛ فقط سرنخ ممیزی |
| unresolved | 19 | Hold؛ نیازمند کشف دستی/فنی بیشتر |
| rejected-false-positive | 4 | Blocked؛ از Discovery خودکار حذف می‌شود |

چهار ارتقای مستقیم این دور شامل **دانشگاه شهید چمران اهواز، دانشگاه بناب، دانشگاه بیرجند و دانشگاه صنعتی قم** است. برای بناب و بیرجند سطح `verified-basic` نگه داشته شده؛ دانشگاه شهید چمران اهواز دارای ساختار رسمی قابل استخراج برای صنعت، IT، کتابخانه/اسناد، آزمایشگاه، انتشارات و مراکز تحقیقاتی است.

## Scope واقعی

برای هر دانشگاه ابتدا هویت پرتال یا بخش رسمی معاونت بررسی می‌شود؛ سپس فقط با Evidence رسمی واحدهای مرتبط/تابع به گراف اضافه می‌شوند:

- مدیریت/اداره امور پژوهشی و سیاست‌گذاری
- ارتباط با صنعت و جامعه
- فناوری، نوآوری، تجاری‌سازی، TTO و مالکیت فکری
- کتابخانه، مرکز اطلاع‌رسانی و مرکز اسناد
- آزمایشگاه مرکزی، مدیریت آزمایشگاه‌ها و آزمایشگاه‌های پژوهشی
- چاپ و انتشارات، نشریات و علم‌سنجی
- پژوهشکده‌ها و مراکز پژوهشی، در صورت رابطه قابل اثبات
- فناوری اطلاعات **فقط با Evidence سازمانی رسمی**
- سامانه‌ها و خدمات دیجیتال مرتبط
- شاعا به‌عنوان `national-related-system`، جدا از آزمایشگاه دانشگاه

## مفهوم 85/85 چیست؟

**85/85 = First-pass audit coverage، نه 85/85 verified portal و نه 85/85 RTPMI.**

در دور اول برای هر دانشگاه حداقل این پرسش‌ها بررسی شده‌اند:

1. آیا هویت معاونت پژوهش و فناوری در وب عمومی قابل مشاهده است؟
2. آیا URL مستقیم یا بخش رسمی روی دامنه دانشگاه قابل اثبات است؟
3. آیا شواهدی برای کتابخانه/مرکز اسناد، آزمایشگاه، صنعت/فناوری، IT یا سامانه‌ها وجود دارد؟
4. آیا نتیجه Search مربوط به همان دانشگاه دولتی است یا false-positive مثل دانشگاه آزاد/علوم پزشکی/واحد سازمانی نامرتبط؟
5. Evidence در چه Tier قرار می‌گیرد و آیا Publication Gate اجازه انتشار Fact می‌دهد؟

جزئیات تک‌تک 69 پرونده در `data/review/systematic-audit.json` و صفحه `/audit/systematic` وجود دارد.

## Evidence Tiers

- **Tier A — direct-official:** صفحه/پرتال مستقیم رسمی؛ مناسب ارتقای هویت پرتال پس از کنترل محتوا.
- **Tier B — official reference:** ارجاع روی دامنه رسمی یا کانال/رسانه رسمی؛ هنوز برای ادعای ساختار کامل کافی نیست.
- **Tier C — secondary:** سرنخ معتبر برای Follow-up؛ Fact Production تولید نمی‌کند.
- **Tier D — unresolved/rejected:** یا منبع مستقیم پیدا نشده، یا نتیجه false-positive بوده است.

## Product surfaces

- `/` Landing + داشبورد ملی
- `/universities` فهرست دانشگاه‌ها
- `/universities/[slug]` پروفایل اکوسیستم پرتال دانشگاه
- `/documents` Document Explorer
- `/compare` مقایسه دانشگاه‌ها
- `/rankings` رتبه‌بندی نهایی RTPMI 4.0 برای 18 پرتال Evidence-qualified + ثبت 67 Unranked
- `/audit` Audit Command Center
- `/audit/systematic` **ممیزی سیستماتیک 85/85 و نتیجه تک‌تک 69 پرونده جدید**
- `/evidence` Evidence Ledger
- `/datasets` Open Data Hub
- `/methodology` روش‌شناسی و RTPMI

## داده Production و Demo

Production:

```env
NEXT_PUBLIC_DATA_MODE=production
```

Demo فقط برای نمایش ویژوال‌های کامل:

```env
NEXT_PUBLIC_DATA_MODE=demo
```

Demo دارای Banner و noindex است. داده Demo هرگز به Production Ranking راه پیدا نمی‌کند.

## Pipeline داده

```text
85-University Inventory
        ↓
Final Audit Register (85/85)
        ↓
Evidence Classification A/B/C/D
        ↓
Direct Portal Identity / Hold / Block
        ↓
Deep Portal & Organizational Audit
        ↓
Units / Libraries / Labs / Industry / Technology / IT-if-proven
        ↓
Documents + Systems + Services
        ↓
Human Review + Evidence Validation
        ↓
Verified Production Catalog
        ↓
RTPMI 4.0 + Confidence + Final Rank
```

### قواعد غیرقابل مذاکره

1. Search ابزار Discovery است، نه Fact نهایی.
2. `not-found` اثبات عدم وجود نیست.
3. لینک شدن از پرتال ≠ زیرمجموعه سازمانی بودن.
4. IT فقط با Evidence رسمی ساختار سازمانی وارد گراف می‌شود.
5. شاعا آزمایشگاه دانشگاه نیست؛ شبکه/سامانه مرتبط ملی است.
6. Crawler یا Search Result نمی‌تواند خودکار رکورد را `verified` کند.
7. First-pass completion با Deep Audit و RTPMI completion یکی نیست.

## شروع سریع

```bash
npm install
cp .env.example .env.local
npm run prepare:data
npm run dev
```

## Quality Gate

```bash
npm run audit:data
npm run release:check
npm run typecheck
npm run lint
npm run build
```

## Crawl / Discovery

```bash
npm run discover:portals
npm run crawl
npm run audit:links
```

خروجی crawler در `data/generated/` **untrusted candidate** است و نیاز به review دارد.

## ساختار داده

```text
data/
  universities/              inventory و وضعیت audit دانشگاه
  portals/                   هویت پرتال‌های قابل انتشار
  units/                     گراف سازمانی Evidence-gated
  systems/                   سامانه‌ها و نوع رابطه
  documents/                 اسناد verified
  evidence/                  Evidence Ledger
  review/
    systematic-audit.json    69 پرونده First-pass تکمیل‌شده
    follow-up-queue.json      کارهای Deep/Identity follow-up
    audit-priority.json       اولویت پیگیری Evidence
    packets/                  Review Packet برای هر 69 دانشگاه
    discovery-hints.json      سرنخ غیرقابل انتشار
  statistics/
    audit-summary.json
    systematic-audit-summary.json
  taxonomy/                  RTPMI + document taxonomy
  schema/                    JSON Schema
  demo/                      داده synthetic فقط UI
```

## Open Data

`npm run prepare:data` این Snapshotها را در `public/datasets/` می‌سازد:

- universities.json
- portals.json
- units.json
- systems.json
- documents.json
- systematic-audit.json
- systematic-audit-summary.json
- follow-up-queue.json
- evidence-ledger.json
- audit-summary.json
- discovery-hints.json
- manifest.json

## Vercel

1. Repository را به GitHub push کنید.
2. Repository را در Vercel Import کنید.
3. `NEXT_PUBLIC_SITE_URL` را روی دامنه نهایی قرار دهید.
4. `NEXT_PUBLIC_DATA_MODE=production` را نگه دارید.
5. Deploy کنید.

راهنما: [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md)

## اسناد کلیدی

- [`docs/SYSTEMATIC_AUDIT_85.md`](docs/SYSTEMATIC_AUDIT_85.md)
- [`docs/RESEARCH_AUDIT_PROTOCOL.md`](docs/RESEARCH_AUDIT_PROTOCOL.md)
- [`docs/DATA_FILLING_PIPELINE.md`](docs/DATA_FILLING_PIPELINE.md)
- [`docs/EVIDENCE_POLICY.md`](docs/EVIDENCE_POLICY.md)
- [`docs/AUDIT_OPERATIONS.md`](docs/AUDIT_OPERATIONS.md)
- [`docs/OPEN_DATA.md`](docs/OPEN_DATA.md)
- [`docs/DATA_GOVERNANCE.md`](docs/DATA_GOVERNANCE.md)
- [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md)
- [`design/FIGMA_HANDOFF.md`](design/FIGMA_HANDOFF.md)

## License

کد MIT است. Metadata تولیدشده توسط پروژه با حفظ provenance قابل استفاده است؛ محتوای صفحات/فایل‌های لینک‌شده تابع حقوق و شرایط ناشر اصلی است.


## Final ranking

نسخه v6 رتبه‌بندی عددی را فقط برای 18 پرتال رسمی با Confidence حداقل 65 منتشر می‌کند. رتبه‌بندی مربوط به **بلوغ و شفافیت پرتال معاونت پژوهش و فناوری** است و نباید به‌عنوان رتبه عملکرد پژوهشی دانشگاه تفسیر شود. فایل بازتولیدپذیر رتبه‌ها: `data/statistics/final-ranking.json`.
