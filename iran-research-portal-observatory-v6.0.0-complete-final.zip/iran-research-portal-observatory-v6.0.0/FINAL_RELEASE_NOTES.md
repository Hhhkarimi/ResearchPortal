# v6.0.0 — Final Audit + Final Comparison + RTPMI Ranking

Release date: 2026-08-10

## Final state
- 85/85 universities have a final audit record.
- 20 official research portal/research-surface identities are published.
- 18 portals pass the ranking gate (direct verified portal + Confidence >= 65).
- 67 universities remain explicitly Unranked; missing evidence is never converted into a synthetic score.
- 197 organizational units, 99 systems/services, 52 verified documents, 440 evidence rows.

## Ranking
RTPMI 4.0 is an evidence-derived **public portal maturity** ranking, not a ranking of research performance. It is reproducible with `npm run finalize:ranking`.

Top three in the 2026-08-10 snapshot:
1. University of Tehran — 84.4 / Confidence 87%
2. University of Zanjan — 76.5 / Confidence 80%
3. Isfahan University of Technology — 70.4 / Confidence 79%

## Product changes
- `/rankings` now contains the final Evidence-qualified leaderboard and National Unranked Register.
- `/compare` compares all eight RTPMI dimensions and clearly labels Unranked universities.
- `/methodology` documents eligibility, operationalization, Confidence and Missing != Zero rules.
- Open Data now exports final ranking, final ranking summary and final audit.
- Publication/release checks validate rank ordering, confidence threshold and 85/85 final-audit coverage.
