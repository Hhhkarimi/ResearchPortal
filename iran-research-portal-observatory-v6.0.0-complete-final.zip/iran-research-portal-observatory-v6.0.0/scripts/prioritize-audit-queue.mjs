import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [queue,universities,hints,rejected,systematic]=await Promise.all([
  read("data/review/follow-up-queue.json"),read("data/universities/catalog.json"),read("data/review/discovery-hints.json"),read("data/review/rejected-portal-candidates.json"),read("data/review/systematic-audit.json")
]);
const uMap=new Map(universities.map(u=>[u.slug,u])); const hMap=new Map(hints.map(h=>[h.universitySlug,h])); const sMap=new Map(systematic.map(s=>[s.universitySlug,s]));
const rejectedSet=new Set(rejected.map(r=>r.universitySlug));
const tierPoints={A:55,B:35,C:18,D:0};
const scored=queue.map(q=>{
  const u=uMap.get(q.universitySlug); const h=hMap.get(q.universitySlug); const a=sMap.get(q.universitySlug);
  let score=tierPoints[a?.evidenceTier]??0; const reasons=[`audit-tier:${a?.evidenceTier||"D"}`,`outcome:${a?.outcome||"unresolved"}`];
  if(h){score+=h.confidence==="high"?25:h.confidence==="medium"?16:8;reasons.push(`discovery:${h.confidence}`)}
  if(u?.websiteUrl){score+=8;reasons.push("official-homepage-known")}
  if(q.phase==="deep-structure-documents"){score+=15;reasons.push("portal-identity-resolved")}
  if(u?.kind==="جامع"){score+=5;reasons.push("broad-portal-ecosystem")}
  if(u?.kind==="صنعتی"){score+=4;reasons.push("high-lab-tech-signal")}
  if(rejectedSet.has(q.universitySlug)){score-=8;reasons.push("rejected-origin-memory")}
  return {...q,priorityScore:score,priorityBand:score>=70?"P0":score>=45?"P1":score>=25?"P2":"P3",priorityReasons:reasons,candidateUrl:a?.portalCandidateUrl||h?.candidateUrl||null};
}).sort((a,b)=>b.priorityScore-a.priorityScore||a.universitySlug.localeCompare(b.universitySlug));
await fs.writeFile("data/review/audit-priority.json",JSON.stringify(scored,null,2)+"\n");
console.log(`follow-up priority: ${scored.length}; P0=${scored.filter(x=>x.priorityBand==="P0").length}; P1=${scored.filter(x=>x.priorityBand==="P1").length}`);
