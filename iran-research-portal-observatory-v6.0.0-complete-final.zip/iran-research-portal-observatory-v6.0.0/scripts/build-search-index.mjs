import fs from "node:fs/promises";
const mode=process.env.NEXT_PUBLIC_DATA_MODE==="demo"?"demo":"production";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const universities=await read(mode==="demo"?"data/demo/universities.json":"data/universities/catalog.json");
const documents=await read(mode==="demo"?"data/demo/documents.json":"data/documents/catalog.json");
const portals=mode==="demo"?[]:await read("data/portals/catalog.json");
const units=mode==="demo"?[]:await read("data/units/catalog.json");
const systems=mode==="demo"?[]:await read("data/systems/catalog.json");
const systematic=mode==="demo"?[]:await read("data/review/systematic-audit.json");
const portalCandidates=mode==="demo"?[]:await read("data/review/portal-candidates.json");
const index=[
 ...universities.map(u=>({kind:"university",id:u.slug,title:u.nameFa,text:[u.nameEn,u.city,u.province,u.kind,...(u.tags||[])].filter(Boolean).join(" "),href:`/universities/${u.slug}`})),
 ...documents.map(d=>({kind:"document",id:d.id,title:d.title,text:`${d.type} ${d.topic} ${d.publisherUnit||""} ${d.universitySlug}`,href:`/documents/${d.id}`})),
 ...units.map(u=>({kind:"portal-unit",id:u.id,title:u.nameFa,text:`${u.type} ${u.relationStatus} ${u.universitySlug}`,href:`/universities/${u.universitySlug}`})),
 ...systems.map(s=>({kind:"portal-system",id:s.id,title:s.nameFa,text:`${s.category} ${s.relation} ${s.universitySlug}`,href:`/universities/${s.universitySlug}`})),
 ...systematic.map(a=>({kind:"systematic-audit",id:`audit-${a.universitySlug}`,title:`ممیزی ${a.nameFa}`,text:`${a.outcome} tier ${a.evidenceTier} ${(a.observedSignals||[]).join(" ")}`,href:"/audit/systematic"}))
];
const summary={schemaVersion:"6.0.0",mode,generatedAt:new Date().toISOString(),universities:universities.length,portalProfiles:portals.length,units:units.length,systems:systems.length,documents:documents.length,systematicAudits:systematic.length,firstPassCoverage:mode==="demo"?null:universities.length,verifiedUniversities:universities.filter(u=>u.auditStatus==="verified").length,partialUniversities:universities.filter(u=>u.auditStatus==="partial").length,scoredUniversities:universities.filter(u=>u.auditStatus==="verified"&&u.score!==null).length,researchPortalsKnown:universities.filter(u=>Boolean(u.researchUrl)).length,discoveredPortalCandidates:portalCandidates.length,noticeFa:mode==="demo"?"داده‌های امتیازی این خروجی نمایشی‌اند.":"ممیزی اولیه ۸۵/۸۵ است؛ فقط رکوردهای verified مجاز به انتشار RTPMI هستند."};
const openDataset={schemaVersion:"6.0.0",mode,generatedAt:summary.generatedAt,methodology:"/methodology",systematicAudit:"/datasets/systematic-audit.json",universities,portals,units,systems,documents:documents.filter(d=>mode==="demo"||d.evidence==="verified")};
await fs.mkdir("public/generated",{recursive:true});await fs.writeFile("public/generated/search-index.json",JSON.stringify(index));await fs.writeFile("public/generated/scope-summary.json",JSON.stringify(summary,null,2));await fs.writeFile("public/generated/open-dataset.json",JSON.stringify(openDataset,null,2));await fs.mkdir("data/statistics",{recursive:true});await fs.writeFile("data/statistics/national-summary.json",JSON.stringify(summary,null,2));console.log(`generated (${mode}): ${index.length} records; ${portals.length} portals; ${units.length} units; ${systems.length} systems; ${systematic.length} systematic audits`);
