import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const files={
  "universities.json":"data/universities/catalog.json","portals.json":"data/portals/catalog.json","units.json":"data/units/catalog.json","systems.json":"data/systems/catalog.json","documents.json":"data/documents/catalog.json",
  "audit-summary.json":"data/statistics/audit-summary.json","systematic-audit-summary.json":"data/statistics/systematic-audit-summary.json","systematic-audit.json":"data/review/systematic-audit.json","follow-up-queue.json":"data/review/follow-up-queue.json",
  "evidence-ledger.json":"data/evidence/ledger.json","discovery-hints.json":"data/review/discovery-hints.json","final-ranking.json":"data/statistics/final-ranking.json","final-comparison-matrix.json":"data/statistics/final-comparison-matrix.json","final-ranking-summary.json":"data/statistics/final-ranking-summary.json","national-comparison-register.json":"data/statistics/national-comparison-register.json","final-audit.json":"data/review/final-audit.json"
};
await fs.mkdir("public/datasets",{recursive:true});
for(const [out,src] of Object.entries(files)){const data=await read(src);await fs.writeFile(`public/datasets/${out}`,JSON.stringify(data,null,2)+"\n");}
const csvEscape=v=>{if(v===null||v===undefined)return "";const s=String(v);return /[",\n]/.test(s)?`"${s.replaceAll('"','""')}"`:s;};
const toCsv=(rows,headers)=>[headers.join(","),...rows.map(r=>headers.map(h=>csvEscape(r[h])).join(","))].join("\n")+"\n";
const ranking=await read("data/statistics/final-ranking.json");
const rankingRows=ranking.map(r=>({rank:r.rank,rankWithinKind:r.rankWithinKind,kind:r.kind,universitySlug:r.universitySlug,nameFa:r.nameFa,province:r.province,city:r.city,score:r.score,confidence:r.confidence,documents:r.documents,units:r.units,systems:r.systems,organizationalTransparency:r.metrics.organizationalTransparency,documentCoverage:r.metrics.documents,libraryKnowledge:r.metrics.libraryKnowledge,laboratories:r.metrics.laboratories,digitalSystemsIT:r.metrics.digitalSystemsIT,industryTechnology:r.metrics.industryTechnology,freshnessDataQuality:r.metrics.freshnessDataQuality,findabilityAccessibility:r.metrics.findabilityAccessibility}));
const rankingHeaders=["rank","rankWithinKind","kind","universitySlug","nameFa","province","city","score","confidence","documents","units","systems","organizationalTransparency","documentCoverage","libraryKnowledge","laboratories","digitalSystemsIT","industryTechnology","freshnessDataQuality","findabilityAccessibility"];
const audit=await read("data/review/final-audit.json");
const auditHeaders=["universitySlug","nameFa","province","city","finalAuditStatus","publicationDecision","portalUrl","score","confidence","auditDate","evidenceTier","outcome"];
await fs.writeFile("data/statistics/final-ranking.csv",toCsv(rankingRows,rankingHeaders));
await fs.writeFile("data/review/final-audit.csv",toCsv(audit,auditHeaders));
await fs.writeFile("public/datasets/final-ranking.csv",toCsv(rankingRows,rankingHeaders));
await fs.writeFile("public/datasets/final-audit.csv",toCsv(audit,auditHeaders));
const manifest={generatedAt:new Date().toISOString(),release:"6.0.0",license:"CC BY 4.0 for project-authored metadata; linked source content retains original rights",files:[...Object.keys(files).map(name=>({name,url:`/datasets/${name}`})),{name:"final-ranking.csv",url:"/datasets/final-ranking.csv"},{name:"final-audit.csv",url:"/datasets/final-audit.csv"}]};
await fs.writeFile("public/datasets/manifest.json",JSON.stringify(manifest,null,2)+"\n");
console.log(`public datasets: ${Object.keys(files).length+1} files`);
