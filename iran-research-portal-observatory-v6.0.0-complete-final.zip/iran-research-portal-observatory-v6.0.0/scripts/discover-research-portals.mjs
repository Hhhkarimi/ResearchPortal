/**
 * Discover candidate public portals for Research & Technology vice-presidencies.
 * This script NEVER promotes a candidate to production evidence automatically.
 */
import fs from "node:fs/promises";
import path from "node:path";
import { safeFetch, sleep } from "./lib/net.mjs";
import { extractLinks } from "./lib/html.mjs";

const root=process.cwd();
const universities=JSON.parse(await fs.readFile("data/universities/catalog.json","utf8"));
let rejected=[];
try{rejected=JSON.parse(await fs.readFile("data/review/rejected-portal-candidates.json","utf8"));}catch{}
const rejectedOrigins=new Set(rejected.filter(x=>x.scope==="origin" && x.candidateUrl).map(x=>{try{return new URL(x.candidateUrl).origin}catch{return null}}).filter(Boolean));
const userAgent=process.env.CRAWLER_USER_AGENT || "ResearchTechnologyPortalObservatoryBot/3.1";
const delay=Number(process.env.CRAWLER_DELAY_MS || 3000);
const words=["معاونت پژوهش","معاونت پژوهشی","پژوهش و فناوری","پژوهشی و فناوری","پژوهشی و تعاملات صنعتی","research vice","research and technology","research & technology","research office","research"];
const output=[];
for(const u of universities){
  if(!u.websiteUrl || u.researchUrl) continue;
  try{
    const origin=new URL(u.websiteUrl).origin;
    const res=await safeFetch(u.websiteUrl,{expectedOrigin:origin,userAgent});
    const type=res.headers.get("content-type")||"";
    if(!res.ok || !type.includes("text/html")) continue;
    const html=await res.text();
    const candidates=extractLinks(html,u.websiteUrl).filter((item)=>{
      let itemOrigin; try{itemOrigin=new URL(item.url).origin}catch{return false}
      if(rejectedOrigins.has(itemOrigin)) return false;
      const h=`${item.title} ${decodeURIComponent(item.url)}`.toLowerCase();
      return words.some(w=>h.includes(w.toLowerCase()));
    }).slice(0,25);
    output.push({universitySlug:u.slug,homepage:u.websiteUrl,checkedAt:new Date().toISOString(),trust:"untrusted-candidate-output",candidates});
  }catch(error){output.push({universitySlug:u.slug,homepage:u.websiteUrl,error:String(error),trust:"untrusted-candidate-output",candidates:[]});}
  await sleep(delay);
}
await fs.mkdir(path.join(root,"data/generated"),{recursive:true});
await fs.writeFile(path.join(root,"data/generated","research-portal-candidates.json"),JSON.stringify(output,null,2));
console.log(`portal discovery: ${output.length} homepages checked/attempted`);
