import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [universities,portals,units,systems,documents,hints,systematic,rejected]=await Promise.all([
  read("data/universities/catalog.json"),read("data/portals/catalog.json"),read("data/units/catalog.json"),read("data/systems/catalog.json"),read("data/documents/catalog.json"),read("data/review/discovery-hints.json"),read("data/review/systematic-audit.json"),read("data/review/rejected-portal-candidates.json")
]);
const uMap=new Map(universities.map(u=>[u.slug,u])); const rows=[];
for(const p of portals) rows.push({kind:"portal",universitySlug:p.universitySlug,university:uMap.get(p.universitySlug)?.nameFa,title:p.titleFa,url:p.url,sourceUrl:p.sourceUrl,evidence:p.evidence,status:"publishable",lastVerified:p.lastVerified});
for(const u of units) rows.push({kind:"unit",universitySlug:u.universitySlug,university:uMap.get(u.universitySlug)?.nameFa,title:u.nameFa,url:u.url,sourceUrl:u.sourceUrl,evidence:u.evidence,status:u.relationStatus==="verified"?"publishable":"review",lastVerified:u.lastVerified});
for(const s of systems) rows.push({kind:"system",universitySlug:s.universitySlug,university:uMap.get(s.universitySlug)?.nameFa,title:s.nameFa,url:s.url,sourceUrl:s.sourceUrl,evidence:s.evidence,status:"publishable",lastVerified:s.lastVerified,relation:s.relation});
for(const d of documents) rows.push({kind:"document",universitySlug:d.universitySlug,university:uMap.get(d.universitySlug)?.nameFa,title:d.title,url:d.url,sourceUrl:d.parentUrl||d.url,evidence:d.evidence,status:d.evidence==="verified"?"publishable":"review",lastVerified:d.lastVerified});
for(const a of systematic) rows.push({kind:"systematic-audit",universitySlug:a.universitySlug,university:uMap.get(a.universitySlug)?.nameFa,title:`ممیزی اولیه: ${a.outcome}`,url:a.portalCandidateUrl||null,sourceUrl:a.evidenceUrls?.[0]||a.portalCandidateUrl||null,evidence:`tier-${a.evidenceTier}`,status:a.publicationDecision==="publish-identity"?"publishable":a.publicationDecision==="blocked"?"blocked":"hold",lastVerified:a.auditDate,relation:a.outcome});
for(const h of hints) rows.push({kind:"discovery-hint",universitySlug:h.universitySlug,university:uMap.get(h.universitySlug)?.nameFa,title:"کاندیدای پرتال / مسیر پژوهشی",url:h.candidateUrl,sourceUrl:h.evidenceUrls?.[0]||h.candidateUrl,evidence:h.sourceClass,status:"hold",lastVerified:h.lastChecked,confidence:h.confidence});
for(const r of rejected) rows.push({kind:"rejected-origin",universitySlug:r.universitySlug,university:uMap.get(r.universitySlug)?.nameFa,title:"مبدأ ردشده",url:r.candidateUrl,sourceUrl:r.discoverySource||r.candidateUrl,evidence:"rejected",status:"blocked",lastVerified:r.lastChecked});
rows.sort((a,b)=>(a.university||"").localeCompare(b.university||"","fa")||a.kind.localeCompare(b.kind));
await fs.mkdir("data/evidence",{recursive:true}); await fs.writeFile("data/evidence/ledger.json",JSON.stringify(rows,null,2)+"\n");
console.log(`evidence ledger: ${rows.length} records`);
