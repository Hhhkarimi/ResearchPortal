import fs from "node:fs/promises";
import { safeFetch, sleep } from "./lib/net.mjs";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [universities,portals,units,systems,documents]=await Promise.all([
  read("data/universities/catalog.json"),read("data/portals/catalog.json"),read("data/units/catalog.json"),read("data/systems/catalog.json"),read("data/documents/catalog.json")
]);
const userAgent=process.env.CRAWLER_USER_AGENT || "ResearchTechnologyPortalObservatoryBot/4.1";
const delay=Number(process.env.CRAWLER_DELAY_MS || 2500);
const jobs=[]; const add=(universitySlug,kind,url,role)=>{if(url) jobs.push({universitySlug,kind,url,role})};
for(const u of universities){add(u.slug,"university",u.websiteUrl,"homepage");add(u.slug,"university",u.researchUrl,"research-portal");for(const x of u.sourceUrls||[]) add(u.slug,"university-source",x,"source")}
for(const p of portals){add(p.universitySlug,"portal",p.url,"target");add(p.universitySlug,"portal",p.sourceUrl,"source")}
for(const u of units){add(u.universitySlug,"unit",u.url,"target");add(u.universitySlug,"unit",u.sourceUrl,"source")}
for(const s of systems){add(s.universitySlug,"system",s.url,"target");add(s.universitySlug,"system",s.sourceUrl,"source")}
for(const d of documents){add(d.universitySlug,"document",d.url,"target");add(d.universitySlug,"document",d.parentUrl,"parent")}
const byUrl=new Map();
for(const j of jobs){const k=j.url;const existing=byUrl.get(k)||{url:k,refs:[]};existing.refs.push({universitySlug:j.universitySlug,kind:j.kind,role:j.role});byUrl.set(k,existing)}
const checks=[];
for(const item of byUrl.values()){
  const started=Date.now();
  try{
    const origin=new URL(item.url).origin;
    let res=await safeFetch(item.url,{expectedOrigin:origin,userAgent,method:"HEAD",accept:"text/html,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,*/*"});
    if([405,501].includes(res.status)) res=await safeFetch(item.url,{expectedOrigin:origin,userAgent,method:"GET",accept:"text/html,application/pdf,*/*"});
    checks.push({...item,status:res.status,ok:res.ok,contentType:res.headers.get("content-type"),latencyMs:Date.now()-started,checkedAt:new Date().toISOString()});
  }catch(error){checks.push({...item,status:null,ok:false,error:String(error),latencyMs:Date.now()-started,checkedAt:new Date().toISOString()});}
  await sleep(delay);
}
const summary={generatedAt:new Date().toISOString(),uniqueUrls:checks.length,healthy:checks.filter(x=>x.ok).length,unhealthy:checks.filter(x=>!x.ok).length,byKind:{}};
for(const c of checks) for(const r of c.refs){summary.byKind[r.kind]??={urls:new Set(),healthy:new Set()};summary.byKind[r.kind].urls.add(c.url);if(c.ok)summary.byKind[r.kind].healthy.add(c.url)}
summary.byKind=Object.fromEntries(Object.entries(summary.byKind).map(([k,v])=>[k,{urls:v.urls.size,healthy:v.healthy.size}]));
await fs.mkdir("data/generated",{recursive:true});
await fs.writeFile("data/generated/link-audit.json",JSON.stringify(checks,null,2)+"\n");
await fs.writeFile("data/generated/link-health-summary.json",JSON.stringify(summary,null,2)+"\n");
console.log(`link audit: ${checks.length} unique URLs; ${summary.healthy} healthy; ${summary.unhealthy} unhealthy`);
