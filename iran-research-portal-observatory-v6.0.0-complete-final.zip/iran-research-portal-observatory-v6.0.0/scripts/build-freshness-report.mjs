import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [universities,portals,units,systems,documents]=await Promise.all([
 read("data/universities/catalog.json"),read("data/portals/catalog.json"),read("data/units/catalog.json"),read("data/systems/catalog.json"),read("data/documents/catalog.json")
]);
const now=new Date();
const ageDays=(v)=>v?Math.floor((now-new Date(v+"T00:00:00Z"))/86400000):null;
const classify=(d)=>d===null?"unknown":d<=30?"fresh":d<=90?"watch":d<=180?"stale":"expired";
const rows=universities.map(u=>{
 const dates=[u.lastVerified,...portals.filter(x=>x.universitySlug===u.slug).map(x=>x.lastVerified),...units.filter(x=>x.universitySlug===u.slug).map(x=>x.lastVerified),...systems.filter(x=>x.universitySlug===u.slug).map(x=>x.lastVerified),...documents.filter(x=>x.universitySlug===u.slug).map(x=>x.lastVerified)].filter(Boolean).sort();
 const last=dates.at(-1)||null; const days=ageDays(last);
 return {universitySlug:u.slug,nameFa:u.nameFa,lastVerified:last,ageDays:days,freshness:classify(days),portalVerified:portals.some(x=>x.universitySlug===u.slug)};
});
await fs.writeFile("data/statistics/freshness-report.json",JSON.stringify(rows,null,2)+"\n");
console.log(`freshness report: ${rows.length} universities`);
