import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [priority,universities,hints,systematic]=await Promise.all([
 read("data/review/audit-priority.json"),read("data/universities/catalog.json"),read("data/review/discovery-hints.json"),read("data/review/systematic-audit.json")
]);
const uMap=new Map(universities.map(u=>[u.slug,u])); const hMap=new Map(hints.map(h=>[h.universitySlug,h])); const aMap=new Map(systematic.map(a=>[a.universitySlug,a]));
await fs.rm("data/review/packets",{recursive:true,force:true}); await fs.mkdir("data/review/packets",{recursive:true});
for(const q of priority){
 const u=uMap.get(q.universitySlug); const h=hMap.get(q.universitySlug); const a=aMap.get(q.universitySlug);
 const direct=a?.outcome==="direct-official"; const scu=q.universitySlug==="shahid-chamran-ahvaz";
 const packet={
   version:"2.0.0",universitySlug:q.universitySlug,nameFa:u?.nameFa,homepageUrl:u?.websiteUrl||null,candidatePortalUrl:a?.portalCandidateUrl||h?.candidateUrl||null,
   systematicAudit:{firstPassComplete:true,outcome:a?.outcome,evidenceTier:a?.evidenceTier,auditDate:a?.auditDate,evidenceUrls:a?.evidenceUrls||[],observedSignals:a?.observedSignals||[]},
   priorityBand:q.priorityBand,priorityScore:q.priorityScore,evidenceHints:[...(a?.evidenceUrls||[]),...(h?.evidenceUrls||[])],signals:[...(a?.observedSignals||[]),...(h?.signals||[])],publicationDecision:"hold",
   checklist:[
    {id:"portal-identity",labelFa:"هویت پرتال/بخش رسمی معاونت",status:direct?"done":"follow-up",required:true},
    {id:"org-chart",labelFa:"ساختار سازمانی و واحدهای تابع",status:scu?"done":"open",required:true},
    {id:"research-policy",labelFa:"مدیریت/اداره امور پژوهشی",status:scu?"done":"open",required:false},
    {id:"industry",labelFa:"ارتباط با صنعت و جامعه",status:scu?"done":"open",required:false},
    {id:"technology",labelFa:"فناوری، نوآوری، TTO یا مالکیت فکری",status:scu?"done":"open",required:false},
    {id:"library",labelFa:"کتابخانه، مرکز اسناد، انتشارات یا علم‌سنجی",status:scu?"done":"open",required:false},
    {id:"laboratories",labelFa:"آزمایشگاه مرکزی/پژوهشی و خدمات تجهیزات",status:scu?"done":"open",required:false},
    {id:"it",labelFa:"IT فقط با Evidence وابستگی سازمانی",status:scu?"done":"open",required:false},
    {id:"systems",labelFa:"سامانه‌ها و خدمات آنلاین",status:scu?"partial":"open",required:false},
    {id:"documents",labelFa:"آیین‌نامه، شیوه‌نامه، دستورالعمل، فرم و فرآیند",status:"open",required:false},
    {id:"human-review",labelFa:"بازبینی انسانی و تصمیم انتشار",status:"open",required:true}
   ],reviewerNotes:[],reviewedAt:null,reviewer:null
 };
 await fs.writeFile(`data/review/packets/${q.universitySlug}.json`,JSON.stringify(packet,null,2)+"\n");
}
console.log(`follow-up review packets: ${priority.length}`);
