/**
 * Conservative portal ecosystem crawler.
 * Seeds:
 *  1) the known Research & Technology Vice-Presidency portal
 *  2) URLs of organizational units whose relationStatus/evidence are already verified
 *
 * Every seed is crawled same-origin. Discovered cross-origin links are classified but are NOT
 * automatically followed/promoted. Output remains untrusted candidate data.
 */
import fs from "node:fs/promises";
import path from "node:path";
import { safeFetch, sleep } from "./lib/net.mjs";
import { extractLinks, stripHtml } from "./lib/html.mjs";

const root = process.cwd();
const catalog = JSON.parse(await fs.readFile(path.join(root, "data/universities/catalog.json"), "utf8"));
const unitCatalog = JSON.parse(await fs.readFile(path.join(root, "data/units/catalog.json"), "utf8"));
const delayMs = Number(process.env.CRAWLER_DELAY_MS || 3000);
const userAgent = process.env.CRAWLER_USER_AGENT || "ResearchTechnologyPortalObservatoryBot/3.1";
const MAX_PAGES_PER_ORIGIN = Number(process.env.CRAWLER_MAX_PAGES || 18);
const MAX_BYTES = Number(process.env.CRAWLER_MAX_BYTES || 1_500_000);

const documentWords=["آیین نامه","آیین‌نامه","فرم","شیوه نامه","شیوه‌نامه","دستورالعمل","بخشنامه","راهنما","فرآیند","فرایند","ضوابط"];
const unitPatterns=[
  ["library-documents",["کتابخانه","مرکز اسناد","اسناد و مدارک"]],
  ["central-laboratory",["آزمایشگاه مرکزی","مدیریت امور آزمایشگاه","امور آزمایشگاه"]],
  ["research-laboratories",["آزمایشگاه پژوهشی","آزمایشگاه‌های پژوهشی","آزمایشگاه هاي پژوهشي"]],
  ["information-technology",["فناوری اطلاعات","فن آوری اطلاعات","مرکز IT","مرکز فناوری اطلاعات"]],
  ["industry-society",["ارتباط با صنعت","تعاملات صنعتی","صنعت و جامعه","ارتباط با جامعه"]],
  ["technology-transfer",["انتقال فناوری","TTO","مالکیت فکری","فناوری و نوآوری","رشد فناوری","کارآفرینی"]],
  ["journals-scientometrics",["علم سنجی","علم‌سنجی","مجلات","نشریات علمی"]],
  ["publications",["انتشارات","چاپ و نشر"]],
  ["research-centers",["مراکز پژوهشی","پژوهشکده","موسسات پژوهشی","واحدهای پژوهشی"]],
  ["ethics",["اخلاق در پژوهش","اخلاق پژوهش"]]
];
const systemPatterns=[
  ["laboratory-network",["شاعا","emshaa"]],
  ["research-information",["RTIS","سامانه پژوهش","مدیریت اطلاعات پژوهش","علم‌سنجی","رزومه اساتید","گرنت"]],
  ["library",["سامانه کتابخانه","کتابخانه دیجیتال","OPAC","جستجو منابع"]],
  ["journals",["سامانه نشریات","سامانه مجلات"]],
  ["postdoc",["پسادکتری","پسا دکتری"]],
  ["industry",["ساتع","ساجد","مپفا"]],
  ["innovation",["مالکیت فکری","ثبت اختراع","نان"]]
];

function safeDecode(value) { try { return decodeURIComponent(value); } catch { return value; } }
function hay(item){return `${item.title} ${safeDecode(item.url)}`.replace(/\s+/g," ").trim();}
function matchesAny(text,words){const low=text.toLowerCase();return words.some(w=>low.includes(w.toLowerCase()));}
function classify(patterns,item){const text=hay(item);for(const [type,words] of patterns) if(matchesAny(text,words)) return type; return null;}
function isDocument(item){return matchesAny(hay(item),documentWords) || /\.(pdf|docx?|xlsx?)($|\?)/i.test(item.url);}
function isLikelyPortalPath(item){return matchesAny(hay(item),["پژوهش","فناوری","صنعت","کتابخانه","آزمایشگاه","آیین","فرم","research","technology","industry","library","laboratory","regulation","form"]);}

async function allowedByRobots(origin, pathname) {
  try {
    const res = await safeFetch(new URL("/robots.txt", origin).href, { expectedOrigin: origin, userAgent, accept: "text/plain,*/*" });
    if (!res.ok) return true;
    const text = await res.text(); let applies=false; const disallow=[];
    for (const raw of text.split(/\r?\n/)) {
      const line=raw.replace(/#.*$/," ").trim(); if(!line) continue;
      const [key,...rest]=line.split(":"); const value=rest.join(":").trim();
      if(/^user-agent$/i.test(key.trim())) applies=value==="*"||userAgent.toLowerCase().includes(value.toLowerCase());
      else if(applies&&/^disallow$/i.test(key.trim())&&value) disallow.push(value);
    }
    return !disallow.some(rule=>pathname.startsWith(rule));
  } catch { return true; }
}

async function fetchHtml(url, origin) {
  const parsed=new URL(url); if(!(await allowedByRobots(origin,parsed.pathname))) return null;
  const res=await safeFetch(url,{expectedOrigin:origin,userAgent});
  const type=res.headers.get("content-type")||""; const length=Number(res.headers.get("content-length")||0);
  if(!res.ok||!type.toLowerCase().includes("text/html")||length>MAX_BYTES) return null;
  const text=await res.text(); if(Buffer.byteLength(text)>MAX_BYTES) return null; return text;
}

async function crawlSeed(seed, university, aggregate) {
  const origin=new URL(seed.url).origin; const queue=[seed.url]; const seen=new Set();
  while(queue.length&&seen.size<MAX_PAGES_PER_ORIGIN){
    const url=queue.shift(); if(!url||seen.has(url)) continue;
    try{if(new URL(url).origin!==origin) continue;}catch{continue;}
    seen.add(url); console.log(`[${university.slug}/${seed.kind}] ${url}`);
    try{
      const html=await fetchHtml(url,origin); if(!html) continue;
      aggregate.pages.push({url,origin,seedKind:seed.kind,seedUnitId:seed.unitId||null,title:stripHtml((html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1]||"").slice(0,240)});
      for(const item of extractLinks(html,url)){
        if(isDocument(item)) aggregate.documents.set(item.url,{...item,parentUrl:url,sourceSeed:seed,candidateType:"document"});
        const unitType=classify(unitPatterns,item); if(unitType) aggregate.units.set(`${unitType}:${item.url}`,{...item,parentUrl:url,sourceSeed:seed,unitType,candidateType:"organizational-unit",publicationNote:"relationship requires human verification"});
        const systemCategory=classify(systemPatterns,item); if(systemCategory) aggregate.systems.set(`${systemCategory}:${item.url}`,{...item,parentUrl:url,sourceSeed:seed,systemCategory,candidateType:"system"});
        const target=new URL(item.url);
        if(target.origin===origin&&!seen.has(item.url)&&!/\.(pdf|docx?|xlsx?|zip|rar|7z)$/i.test(target.pathname)&&isLikelyPortalPath(item)) queue.push(item.url);
      }
    }catch(error){aggregate.errors.push({url,error:String(error)});}
    await sleep(delayMs);
  }
  return {seed,origin,pagesVisited:seen.size};
}

await fs.mkdir(path.join(root,"data/generated"),{recursive:true});
for(const university of catalog){
  if(!university.researchUrl || !["verified","verified-basic"].includes(university.researchEvidence)){console.log(`skip ${university.slug}: portal not verified for crawling`);continue;}
  const verifiedUnits=unitCatalog.filter(u=>u.universitySlug===university.slug&&u.relationStatus==="verified"&&u.evidence==="verified"&&u.url);
  const seeds=[{kind:"vice-presidency",url:university.researchUrl,unitId:null},...verifiedUnits.map(u=>({kind:u.type,url:u.url,unitId:u.id}))];
  const uniqueSeeds=[...new Map(seeds.map(s=>[s.url,s])).values()];
  const aggregate={documents:new Map(),units:new Map(),systems:new Map(),pages:[],errors:[]}; const seedReports=[];
  for(const seed of uniqueSeeds){try{seedReports.push(await crawlSeed(seed,university,aggregate));}catch(error){aggregate.errors.push({url:seed.url,error:String(error)});}}
  const payload={
    universitySlug:university.slug,portalUrl:university.researchUrl,crawledAt:new Date().toISOString(),
    trust:"untrusted-candidate-output",publicationRule:"human-review-required",
    scopeRule:"vice-presidency portal + verified organizational-unit seeds; no automatic cross-origin expansion",
    seeds:seedReports,pages:aggregate.pages,errors:aggregate.errors,
    candidates:{documents:[...aggregate.documents.values()],units:[...aggregate.units.values()],systems:[...aggregate.systems.values()]}
  };
  await fs.writeFile(path.join(root,"data/generated",`${university.slug}-portal-candidates.json`),JSON.stringify(payload,null,2));
}
