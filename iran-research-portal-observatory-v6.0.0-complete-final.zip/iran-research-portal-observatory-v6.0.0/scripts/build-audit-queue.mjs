import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [universities,portals,systematic,rejected]=await Promise.all([
  read("data/universities/catalog.json"),read("data/portals/catalog.json"),read("data/review/systematic-audit.json"),read("data/review/rejected-portal-candidates.json")
]);
const portalSlugs=new Set(portals.map(p=>p.universitySlug));
const completedSlugs=new Set(systematic.filter(r=>r.firstPassComplete).map(r=>r.universitySlug));
const rejectedBySlug=new Map(rejected.map(r=>[r.universitySlug,r]));
const queue=universities.filter(u=>!portalSlugs.has(u.slug)&&!completedSlugs.has(u.slug)).map((u,index)=>({
  order:index+1,universitySlug:u.slug,nameFa:u.nameFa,province:u.province??null,city:u.city??null,homepage:u.websiteUrl??null,
  auditStatus:u.auditStatus,discoveryStatus:rejectedBySlug.has(u.slug)?"rejected-origin-needs-new-discovery":"pending-discovery",
  rejectedOrigin:rejectedBySlug.get(u.slug)?.candidateUrl??null,publicationDecision:"hold"
}));
const followUp=systematic.map(r=>({
  order:r.order,universitySlug:r.universitySlug,nameFa:r.nameFa,
  phase:r.outcome==="direct-official"?"deep-structure-documents":"portal-identity-resolution",
  outcome:r.outcome,evidenceTier:r.evidenceTier,portalCandidateUrl:r.portalCandidateUrl??null,
  publicationDecision:"hold",nextAction:r.nextAction
}));
await fs.writeFile("data/review/audit-queue.json",JSON.stringify(queue,null,2)+"\n");
await fs.writeFile("data/review/follow-up-queue.json",JSON.stringify(followUp,null,2)+"\n");
console.log(`first-pass audit queue: ${queue.length}; follow-up queue: ${followUp.length}`);
