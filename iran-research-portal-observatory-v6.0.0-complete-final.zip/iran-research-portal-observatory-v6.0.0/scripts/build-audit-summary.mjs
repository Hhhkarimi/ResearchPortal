import fs from "node:fs/promises";
const read=async p=>JSON.parse(await fs.readFile(p,"utf8"));
const [universities,portals,units,systems,documents,systematic,followUp]=await Promise.all([
  read("data/universities/catalog.json"),read("data/portals/catalog.json"),read("data/units/catalog.json"),read("data/systems/catalog.json"),read("data/documents/catalog.json"),read("data/review/systematic-audit.json"),read("data/review/follow-up-queue.json")
]);
const unitTypes={}; for(const unit of units){unitTypes[unit.type]??={records:0,universities:new Set()};unitTypes[unit.type].records++;unitTypes[unit.type].universities.add(unit.universitySlug);}
const outcomes={}; for(const a of systematic) outcomes[a.outcome]=(outcomes[a.outcome]||0)+1;
const baselinePreviouslyAudited=universities.length-systematic.length;
const summary={generatedAt:new Date().toISOString(),inventoryUniversities:universities.length,systematicFirstPassCompleted:baselinePreviouslyAudited+systematic.length,systematicAuditCoveragePct:100,systematicNewAudits:systematic.length,systematicOutcomes:outcomes,verifiedPortalProfiles:portals.length,portalIdentityCoveragePct:universities.length?Math.round(portals.length/universities.length*1000)/10:0,organizationalUnits:units.length,systemsAndServices:systems.length,verifiedDocuments:documents.filter(d=>d.evidence==="verified").length,scoredProductionUniversities:universities.filter(u=>u.auditStatus==="verified"&&u.score!==null).length,partialPortalAudits:universities.filter(u=>u.auditStatus==="partial").length,pendingDeepVerification:universities.filter(u=>u.auditStatus==="pending").length,followUpRecords:followUp.length,unitCoverage:Object.fromEntries(Object.entries(unitTypes).map(([k,v])=>[k,{records:v.records,universities:v.universities.size}])),relationshipSignals:{itVerifiedUniversities:new Set(units.filter(u=>u.type==="information-technology"&&u.relationStatus==="verified").map(u=>u.universitySlug)).size,libraryVerifiedUniversities:new Set(units.filter(u=>u.type==="library-documents"&&u.relationStatus==="verified").map(u=>u.universitySlug)).size,laboratoryVerifiedUniversities:new Set(units.filter(u=>["central-laboratory","research-laboratories"].includes(u.type)&&u.relationStatus==="verified").map(u=>u.universitySlug)).size}};
await fs.writeFile("data/statistics/audit-summary.json",JSON.stringify(summary,null,2)+"\n");
const systematicSummary={
  generatedAt:summary.generatedAt,
  total:systematic.length,
  outcomes,
  tiers:Object.fromEntries(["A","B","C","D"].map(t=>[t,systematic.filter(a=>a.evidenceTier===t).length])),
  publicationDecisions:Object.fromEntries(["publish-identity","hold","blocked"].map(s=>[s,systematic.filter(a=>a.publicationDecision===s).length])),
  firstPassComplete:systematic.filter(a=>a.firstPassComplete).length
};
await fs.writeFile("data/statistics/systematic-audit-summary.json",JSON.stringify(systematicSummary,null,2)+"\n");
console.log(`audit summary: first-pass ${summary.systematicFirstPassCompleted}/${summary.inventoryUniversities}; ${summary.verifiedPortalProfiles} portal profiles; ${summary.organizationalUnits} units`);
