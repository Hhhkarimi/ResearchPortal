# Contributing

- هر Fact باید Evidence URL و تاریخ بررسی داشته باشد.
- Crawler candidate به‌تنهایی Fact verified نیست.
- IT فقط با منبع رسمیِ رابطه سازمانی به واحدهای معاونت اضافه شود.
- لینک شاعا/سامانه ملی با مالکیت یا عضویت سازمانی یکسان تلقی نشود.
- RTPMI بدون `auditStatus=verified` قابل merge به Ranking نیست.
- اصلاح داده با PR کوچک، توضیح و منبع رسمی انجام شود.
