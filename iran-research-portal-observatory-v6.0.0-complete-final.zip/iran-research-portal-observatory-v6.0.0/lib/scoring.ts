import type { MetricKey, University } from "./types";

export const RTPMI_VERSION = "4.0.0";

/**
 * Research & Technology Portal Maturity Index (RTPMI)
 * Project-defined, non-official, evidence-derived index focused on the public portal of each vice-presidency. It does not rank research performance.
 */
export const RTPMI_WEIGHTS: Record<MetricKey, number> = {
  documents: 0.20,
  organizationalTransparency: 0.12,
  libraryKnowledge: 0.10,
  laboratories: 0.12,
  digitalSystemsIT: 0.12,
  industryTechnology: 0.12,
  freshnessDataQuality: 0.12,
  findabilityAccessibility: 0.10
};

export function calculateRTPMI(metrics: Record<MetricKey, number | null>) {
  let weighted = 0;
  let appliedWeight = 0;
  for (const [key, weight] of Object.entries(RTPMI_WEIGHTS) as [MetricKey, number][]) {
    const value = metrics[key];
    if (value !== null) {
      weighted += value * weight;
      appliedWeight += weight;
    }
  }
  if (!appliedWeight) return null;
  return Math.round((weighted / appliedWeight) * 10) / 10;
}

export function confidenceFromCoverage(observed: number, expected: number, sourceHealth: number) {
  if (!expected) return 0;
  const coverage = Math.min(1, observed / expected);
  return Math.round((coverage * 0.8 + Math.max(0, Math.min(1, sourceHealth)) * 0.2) * 100);
}

export function isPublishableRankingRecord(university: University) {
  return university.auditStatus === "verified"
    && university.score !== null
    && university.lastVerified !== null
    && university.confidence > 0;
}
