export type MetricKey =
  | "organizationalTransparency"
  | "documents"
  | "libraryKnowledge"
  | "laboratories"
  | "digitalSystemsIT"
  | "industryTechnology"
  | "freshnessDataQuality"
  | "findabilityAccessibility";

export type AuditStatus = "verified" | "partial" | "demo-seed" | "pending";
export type ScopeStatus = "verified-basic" | "candidate" | "excluded";
export type EvidenceLevel = "verified" | "verified-basic" | "candidate" | "discovered" | "demo" | "missing";
export type RelationStatus = "verified" | "candidate" | "unclear";

export interface University {
  slug: string;
  nameFa: string;
  nameEn: string;
  city: string;
  province?: string;
  kind: "جامع" | "صنعتی" | "تخصصی";
  websiteUrl: string | null;
  researchUrl: string | null;
  auditStatus: AuditStatus;
  scopeStatus?: ScopeStatus;
  homepageEvidence?: EvidenceLevel;
  researchEvidence?: EvidenceLevel;
  sourceUrls?: string[];
  score: number | null;
  confidence: number;
  trend: number | null;
  documentCount: number;
  brokenLinks: number;
  lastVerified: string | null;
  metrics: Record<MetricKey, number | null>;
  coverage: {
    regulations: number;
    forms: number;
    guidelines: number;
    procedures: number;
  };
  tags: string[];
}

export type PortalUnitType =
  | "vice-presidency"
  | "research-policy"
  | "industry-society"
  | "technology-transfer"
  | "library-documents"
  | "central-laboratory"
  | "research-laboratories"
  | "information-technology"
  | "publications"
  | "journals-scientometrics"
  | "research-centers"
  | "ethics"
  | "committees"
  | "finance"
  | "other";

export interface PortalProfile {
  universitySlug: string;
  mode?: "dedicated" | "embedded-research-surface";
  titleFa: string;
  url: string;
  evidence: EvidenceLevel;
  sourceUrl: string;
  lastVerified: string | null;
  contact?: { phone?: string; email?: string; address?: string };
  notes?: string[];
}

export interface PortalUnit {
  id: string;
  universitySlug: string;
  nameFa: string;
  type: PortalUnitType;
  parentUnitId: string | null;
  relationStatus: RelationStatus;
  url: string | null;
  sourceUrl: string;
  evidence: EvidenceLevel;
  lastVerified: string | null;
  notes?: string[];
}

export type PortalSystemRelation = "managed-by-portal" | "linked-from-portal" | "unit-service" | "national-related-system";
export interface PortalSystem {
  id: string;
  universitySlug: string;
  nameFa: string;
  category: "research-information" | "library" | "laboratory-network" | "journals" | "postdoc" | "industry" | "innovation" | "it" | "other";
  url: string;
  relation: PortalSystemRelation;
  sourceUrl: string;
  evidence: EvidenceLevel;
  lastVerified: string | null;
}

export interface ResearchDocument {
  id: string;
  universitySlug: string;
  title: string;
  type: "آیین‌نامه" | "فرم" | "شیوه‌نامه" | "دستورالعمل" | "بخشنامه" | "راهنما" | "فرآیند";
  topic: string;
  url: string;
  parentUrl: string | null;
  format: "PDF" | "DOC" | "DOCX" | "HTML" | "XLSX";
  status: "active" | "broken" | "restricted" | "not-found" | "unverified";
  evidence: "verified" | "discovered" | "demo";
  publishedDate: string | null;
  lastVerified: string | null;
  publisherUnit?: string | null;
  approvalAuthority?: string | null;
}

export type EvidenceSourceClass = "direct-official" | "official-crosslink" | "indexed-official-url" | "indexed-official-navigation" | "indexed-official-content" | "candidate-pattern" | "rejected";
export interface DiscoveryHint {
  universitySlug: string;
  candidateUrl: string;
  confidence: "high" | "medium" | "low";
  sourceClass: EvidenceSourceClass;
  evidenceUrls: string[];
  signals: string[];
  publicationDecision: "hold";
  nextAction: string;
  lastChecked: string;
}
export interface EvidenceLedgerRow {
  kind: "portal" | "unit" | "system" | "document" | "discovery-hint" | "systematic-audit" | "rejected-origin";
  universitySlug: string;
  university?: string;
  title: string;
  url: string | null;
  sourceUrl: string | null;
  evidence: string;
  status: "publishable" | "review" | "hold" | "blocked";
  lastVerified: string | null;
  relation?: string;
  confidence?: string;
}

export type SystematicAuditOutcome =
  | "direct-official"
  | "official-domain-reference"
  | "official-channel-reference"
  | "secondary-evidence"
  | "unresolved"
  | "rejected-false-positive";

export interface SystematicAuditRecord {
  order: number;
  universitySlug: string;
  nameFa: string;
  province?: string | null;
  city?: string | null;
  auditDate: string;
  firstPassComplete: true;
  outcome: SystematicAuditOutcome;
  evidenceTier: "A" | "B" | "C" | "D";
  portalCandidateUrl?: string | null;
  evidenceUrls: string[];
  observedSignals: string[];
  searchQueries: string[];
  notes: string[];
  publicationDecision: "publish-identity" | "hold" | "blocked";
  nextAction: string;
}

export interface FollowUpAuditRecord {
  order: number;
  universitySlug: string;
  nameFa: string;
  phase: "deep-structure-documents" | "portal-identity-resolution";
  outcome: SystematicAuditOutcome;
  evidenceTier: "A" | "B" | "C" | "D";
  portalCandidateUrl?: string | null;
  publicationDecision: "hold";
  nextAction: string;
}

export interface FinalAuditRecord {
  universitySlug: string; nameFa: string; province?: string | null; city?: string | null;
  finalAuditStatus: "ranked-scoreable" | "identity-verified-insufficient-depth" | "identity-verified-insufficient-confidence" | "closed-false-positive" | "closed-unresolved" | "closed-evidence-insufficient" | "baseline-verified-profile";
  publicationDecision: "publish-ranking" | "publish-profile-no-rank" | "publish-audit-no-rank" | "blocked";
  portalUrl?: string | null; score?: number | null; confidence: number; auditDate: string; evidenceTier: "A" | "B" | "C" | "D"; outcome: string;
}
export interface RankingRecord {
  universitySlug: string; nameFa: string; kind: "جامع" | "صنعتی" | "تخصصی"; province?: string | null; city: string; score: number; confidence: number; rank: number; rankWithinKind: number; kindFieldSize: number; percentile: number; band: string; documents: number; units: number; systems: number; metrics: Record<MetricKey, number>;
}
