const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
export const SITE_URL = configured && /^https?:\/\//.test(configured) ? configured.replace(/\/$/,"") : "http://localhost:3000";
export const siteUrl = (pathname = "/") => `${SITE_URL}${pathname.startsWith("/")?pathname:`/${pathname}`}`;
export const SITE_NAME = "رصد پرتال معاونت پژوهش و فناوری";
export const SITE_NAME_EN = "Iran Research & Technology Portal Observatory";
