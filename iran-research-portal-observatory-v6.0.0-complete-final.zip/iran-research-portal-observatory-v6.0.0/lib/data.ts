import productionUniversities from "@/data/universities/catalog.json";
import productionDocuments from "@/data/documents/catalog.json";
import productionPortals from "@/data/portals/catalog.json";
import productionUnits from "@/data/units/catalog.json";
import productionSystems from "@/data/systems/catalog.json";
import productionPortalCandidates from "@/data/review/portal-candidates.json";
import productionDiscoveryHints from "@/data/review/discovery-hints.json";
import evidenceLedgerData from "@/data/evidence/ledger.json";
import freshnessReportData from "@/data/statistics/freshness-report.json";
import auditPriorityData from "@/data/review/audit-priority.json";
import systematicAuditData from "@/data/review/systematic-audit.json";
import followUpAuditData from "@/data/review/follow-up-queue.json";
import systematicAuditSummaryData from "@/data/statistics/systematic-audit-summary.json";
import finalRankingData from "@/data/statistics/final-ranking.json";
import finalRankingSummaryData from "@/data/statistics/final-ranking-summary.json";
import finalAuditData from "@/data/review/final-audit.json";
import demoUniversities from "@/data/demo/universities.json";
import demoDocuments from "@/data/demo/documents.json";
import type { DiscoveryHint, EvidenceLedgerRow, FollowUpAuditRecord, PortalProfile, PortalSystem, PortalUnit, ResearchDocument, SystematicAuditRecord, University, FinalAuditRecord, RankingRecord } from "./types";

export const dataMode = process.env.NEXT_PUBLIC_DATA_MODE === "demo" ? "demo" : "production";
export const isDemoMode = dataMode === "demo";

export const universityCatalog = (isDemoMode ? demoUniversities : productionUniversities) as University[];
export const documentCatalog = (isDemoMode ? demoDocuments : productionDocuments) as ResearchDocument[];
export const portalCatalog = (isDemoMode ? [] : productionPortals) as PortalProfile[];
export const unitCatalog = (isDemoMode ? [] : productionUnits) as PortalUnit[];
export const systemCatalog = (isDemoMode ? [] : productionSystems) as PortalSystem[];
export const portalCandidateCatalog = isDemoMode ? [] : productionPortalCandidates;
export const discoveryHintCatalog = (isDemoMode ? [] : productionDiscoveryHints) as DiscoveryHint[];
export const evidenceLedger = (isDemoMode ? [] : evidenceLedgerData) as EvidenceLedgerRow[];
export const freshnessReport = isDemoMode ? [] : freshnessReportData;
export const auditPriority = isDemoMode ? [] : auditPriorityData;
export const systematicAuditCatalog = (isDemoMode ? [] : systematicAuditData) as SystematicAuditRecord[];
export const followUpAuditCatalog = (isDemoMode ? [] : followUpAuditData) as FollowUpAuditRecord[];
export const systematicAuditSummary = isDemoMode ? null : systematicAuditSummaryData;
export const finalRanking = (isDemoMode ? [] : finalRankingData) as RankingRecord[];
export const finalRankingSummary = isDemoMode ? null : finalRankingSummaryData;
export const finalAuditCatalog = (isDemoMode ? [] : finalAuditData) as FinalAuditRecord[];

export const getUniversity = (slug: string) => universityCatalog.find((university) => university.slug === slug);
export const getUniversityDocuments = (slug: string) => documentCatalog.filter((document) => document.universitySlug === slug);
export const getDocument = (id: string) => documentCatalog.find((document) => document.id === id);
export const getPortal = (slug: string) => portalCatalog.find((portal) => portal.universitySlug === slug);
export const getUniversityUnits = (slug: string) => unitCatalog.filter((unit) => unit.universitySlug === slug);
export const getUniversitySystems = (slug: string) => systemCatalog.filter((system) => system.universitySlug === slug);

export const verifiedUniversities = universityCatalog.filter((u) => u.auditStatus === "verified" && u.score !== null);
export const rankedUniversities = [...universityCatalog]
  .filter((university) => university.score !== null && (isDemoMode || university.auditStatus === "verified"))
  .sort((a, b) => (b.score || 0) - (a.score || 0));

export function datasetSummary() {
  const scored = universityCatalog.filter((u) => u.score !== null);
  const verified = universityCatalog.filter((u) => u.auditStatus === "verified");
  const partial = universityCatalog.filter((u) => u.auditStatus === "partial");
  const withResearchUrl = universityCatalog.filter((u) => Boolean(u.researchUrl));
  return {
    universities: universityCatalog.length,
    portals: withResearchUrl.length,
    portalProfiles: portalCatalog.length,
    units: unitCatalog.length,
    systems: systemCatalog.length,
    documents: documentCatalog.length,
    scored: scored.length,
    verified: verified.length,
    partial: partial.length,
    researchUrls: withResearchUrl.length,
    portalCandidates: portalCandidateCatalog.length,
    verificationRate: universityCatalog.length ? Math.round((verified.length / universityCatalog.length) * 100) : 0,
    averageScore: scored.length ? Math.round((scored.reduce((sum, u) => sum + (u.score || 0), 0) / scored.length) * 10) / 10 : null,
    brokenLinks: documentCatalog.filter((d) => d.status === "broken").length,
    systematicFirstPass: isDemoMode ? 0 : systematicAuditCatalog.length,
    nationalFirstPassCoverage: isDemoMode ? null : universityCatalog.length,
    followUpAudits: isDemoMode ? 0 : followUpAuditCatalog.length
  };
}
