# Figma Handoff — v3.0

## Import-ready assets
- `landing-preview.svg`
- `dashboard-preview.svg`
- `university-profile-preview.svg`
- `tokens.json`

SVGها را می‌توان مستقیماً داخل Figma drag/drop کرد و سپس با Auto Layout بازسازی کرد. اعداد داخل previewهای طراحی صرفاً **Design Concept** هستند و نباید به‌عنوان داده پژوهشی استفاده شوند.

## Figma pages
1. 00 / Cover
2. 01 / Foundations
3. 02 / Components
4. 03 / Landing Desktop
5. 04 / Portal Observatory Dashboard
6. 05 / University Profile
7. 06 / Documents
8. 07 / Compare
9. 08 / Mobile
10. 09 / Share Cards

## Variables
### Color collection
`Background / Ink`, `Surface / 1`, `Surface / 2`, `Accent / Violet`, `Accent / Cyan`, `Accent / Acid`, `Accent / Pink`, `State / Danger`, `State / Warning`.

### Radius
8 / 12 / 20 / 30 / 32 / Pill.

### Spacing
4, 8, 12, 16, 20, 24, 32, 48, 64, 96.

## Core components
- Header / desktop, mobile
- Button / primary, ghost, icon
- Chip / filter, active
- Stat / bento card
- University / card
- Document / card
- Portal unit / verified, candidate, unclear
- Portal system / relation type
- Organization graph / branch + unit node
- Status / verified, pending, broken, restricted
- Search / command palette
- Table / responsive row

## Signature visualization frames
- Portal Constellation
- Audit Rings
- Policy Topic Galaxy
- RTPMI Orbit
- Document Heatmap
- Portal DNA Radar

## Prototype motion
- Hero gradient drift: 8–12s ambient
- Card hover: 160ms, Y=-2
- Command Palette: fade + scale 0.98→1, 160ms
- Chart reveal: 620–700ms staggered
- Respect reduced-motion in code

## Responsive frames
- 1440 desktop
- 1024 small desktop/tablet landscape
- 768 tablet
- 390 mobile
