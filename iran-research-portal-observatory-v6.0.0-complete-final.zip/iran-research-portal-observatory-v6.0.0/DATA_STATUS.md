# Data Status — v6.0.0

Snapshot date: **2026-08-10**

Production is **portal-first, evidence-first, non-medical and score-safe**.

## National first-pass coverage

- **85/85** inventory universities have a completed first-pass audit outcome.
- **69/69** universities that were still pending in v4.1 now have durable records in `data/review/systematic-audit.json`.
- First-pass Audit Queue: **0**.
- Follow-up Queue: **69** for deep organizational/document review or portal-identity resolution.

## Production evidence layer

- **20** publishable official research-portal / research-surface identities.
- **197** organizational-unit records.
- **99** portal system/service records.
- **52** verified document records.
- **440** Evidence Ledger records: **372 publishable**, **63 hold**, **5 blocked**.
- **18** Evidence-qualified portal records have reproducible RTPMI 4.0 scores.
- **67** universities are explicitly Unranked due to insufficient direct/deep evidence.
- Synthetic Production scores: **0**.

## 69 newly completed first-pass outcomes

- `direct-official`: **4**
- `official-domain-reference`: **4**
- `official-channel-reference`: **14**
- `secondary-evidence`: **24**
- `unresolved`: **19**
- `rejected-false-positive`: **4**

Direct-official promotions from the 69-record systematic audit include:

- University of Bonab — `https://research.ubonab.ac.ir/` (`verified-basic`)
- University of Birjand — `https://birjand.ac.ir/research/fa` (`verified-basic`)
- Shahid Chamran University of Ahvaz — `https://research.scu.ac.ir/` (`verified`)
- Qom University of Technology — `https://qut.ac.ir/fa/researches/index` (`verified` embedded research surface under the combined Education & Research Vice-Presidency)

## Embedded versus dedicated portals

A research function does not always have a standalone subdomain. v6 can distinguish a dedicated Research & Technology portal from an **official embedded research surface**. This prevents loss of evidence in universities with combined vice-presidencies while avoiding the false claim that an independent portal exists.

For Qom University of Technology, the official university site exposes Research & Technology Management, research forms/regulations, industry liaison, library, central laboratory and research services. IT is displayed under the presidency domain and is therefore **not** attributed to the research vice-presidency.

## Final ranking status

- Final audit records: **85/85** in `data/review/final-audit.json`.
- Ranked: **18**.
- Unranked: **67**.
- Ranking eligibility: direct official verified portal + Confidence ≥ 65.
- Top three in this snapshot: University of Tehran (84.4), University of Zanjan (76.5), Isfahan University of Technology (70.4).

## Interpretation

**First-pass complete does not mean deep audit complete.** A university can be:

- first-pass audited but `unresolved`;
- first-pass audited with official-channel/domain evidence but no direct portal URL;
- portal-identified but still waiting for organizational/document deep audit;
- fully rubric-reviewed later and then eligible for RTPMI publication.

## Evidence semantics

- `publishable`: evidence sufficient for the specific current Fact.
- `hold`: useful audit evidence, but not enough to publish the requested organizational/scoring claim.
- `blocked`: false-positive/rejected discovery retained as discovery memory.
- `linked-from-portal`: link exists; organizational subordination is not claimed.
- `national-related-system`: related national infrastructure such as SHAA.

## Safety rules

- `not-found` ≠ proven absent.
- Search snippets are not equivalent to direct official pages.
- Generic ICT links do not prove IT is subordinate to the Research & Technology VP.
- SHAA is not modeled as a university laboratory.
- A score is published only when the reproducible evidence-derived rubric passes the ranking eligibility gate.
