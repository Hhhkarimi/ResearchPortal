# Setup Checklist v4

- [ ] Repository را در GitHub ایجاد و push کنید.
- [ ] Vercel را به repository متصل کنید.
- [ ] `NEXT_PUBLIC_SITE_URL` را تنظیم کنید.
- [ ] Production را روی `NEXT_PUBLIC_DATA_MODE=production` نگه دارید.
- [ ] GitHub branch protection, secret scanning و CodeQL را فعال کنید.
- [ ] `npm run validate:data && npm run release:check` را اجرا کنید.
- [ ] فهرست ۸۵ مورد را با مرجع رسمی دامنه دانشگاه‌های وزارت علوم reconcile کنید.
- [ ] برای هر دانشگاه `discover:portals` و review دستی انجام دهید.
- [ ] گراف واحدهای معاونت، کتابخانه/اسناد، آزمایشگاه‌ها، صنعت/فناوری و IT-if-proven را تکمیل کنید.
- [ ] candidate documents/systems را review و promote کنید.
- [ ] RTPMI فقط پس از `auditStatus=verified` محاسبه شود.

## v4.1 evidence operations
- [ ] Verify `/evidence` renders and only `publishable` entries are presented as facts.
- [ ] Verify `/datasets` downloads work after `npm run prepare:data`.
- [ ] Review the top P0 packets in `data/review/packets/`.
- [ ] Run `npm run audit:links` and inspect `link-health-summary.json`.
