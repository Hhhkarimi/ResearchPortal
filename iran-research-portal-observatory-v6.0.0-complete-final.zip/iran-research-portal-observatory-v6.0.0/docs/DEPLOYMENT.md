# GitHub + Vercel Deployment — v6.0

## Local

```bash
npm install
cp .env.example .env.local
npm run release:check
npm run dev
```

## GitHub

```bash
git init
git add .
git commit -m "Release Research Portal Observatory v6.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/iran-research-portal-observatory.git
git push -u origin main
```

Recommended repository settings:

- Protect `main` and require CI.
- Enable Dependabot alerts/updates.
- Enable CodeQL/code scanning.
- Enable secret scanning where available.
- Promote data through PRs so Evidence changes remain auditable.

## Vercel

Import the GitHub repository and configure:

```env
NEXT_PUBLIC_SITE_URL=https://YOUR-DOMAIN
NEXT_PUBLIC_DATA_MODE=production
```

Framework: Next.js. Build command: `npm run build`.

## Demo Preview

```env
NEXT_PUBLIC_DATA_MODE=demo
```

Demo is noindex and must never be used as Production evidence.

## v6 post-deploy checks

- `/api/health` returns release `6.0.0`, `85/85` first-pass coverage and the expected portal/unit/system counts.
- `/audit/systematic` shows all 69 newly completed systematic audit records.
- `/audit` distinguishes first-pass completion from Follow-up/Deep Audit.
- `/evidence` keeps indirect evidence as Hold/Blocked.
- `/datasets/manifest.json`, `/datasets/systematic-audit.json` and `/datasets/follow-up-queue.json` are reachable.
- `NEXT_PUBLIC_DATA_MODE=production` is set on Production.
- CI runs install → release check → typecheck → lint → build → dependency audit.

## Note about package installation in the authoring environment

The release authoring container is restricted to an internal npm mirror that does not mirror all development packages (for example `@types/node`), and direct access to `registry.npmjs.org` times out. Therefore a full dependency install / `next build` is not claimed locally. GitHub Actions explicitly configures the public npm registry and remains the final install → typecheck → lint → build → dependency-audit gate. Vazirmatn is loaded through `next/font/google`, so there is no separate font package dependency.
