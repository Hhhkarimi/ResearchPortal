# Audit Operations — v6.0

## هدف

تبدیل فهرست ملی دانشگاه‌ها به ممیزی قابل تکرار، قابل تحویل به چند ممیز و قابل بازبینی در Git.

## چرخه عملیاتی

1. `npm run prepare:data` صف و آمار را بازسازی می‌کند.
2. `audit-priority.json` دانشگاه‌ها را به P0/P1/P2/P3 تقسیم می‌کند.
3. برای هر دانشگاه pending یک Review Packet در `data/review/packets/` تولید می‌شود.
4. ممیز Portal Identity را با Evidence رسمی تأیید/رد می‌کند.
5. سپس گراف سازمانی، کتابخانه، آزمایشگاه، صنعت/فناوری، IT-if-proven، سامانه و اسناد بررسی می‌شوند.
6. هر ادعا provenance و `lastVerified` می‌گیرد.
7. Human Review تصمیم انتشار را تغییر می‌دهد.
8. Ranking فقط بعد از completion کل rubric آزاد می‌شود.

## Audit Priority Engine

امتیاز اولویت فقط «ترتیب کار» است و هرگز RTPMI نیست. عوامل فعلی شامل Discovery Hint، وجود homepage رسمی، نوع دانشگاه و rejection memory است.

## Review Packet checklist

هر packet حداقل شامل این مراحل است:

- portal identity
- organization graph
- research policy/admin
- industry & society
- technology/TTO/IP
- library/document center
- central/research laboratories
- IT relation
- systems/services
- documents
- human review

## Link health

`npm run audit:links` همه URLهای catalog را deduplicate و بررسی می‌کند: دانشگاه، پرتال، واحد، سامانه، سند و source URL. خروجی در `data/generated/link-audit.json` و `link-health-summary.json` است.

## اصل توقف امن

اگر Evidence کافی نیست، رکورد باید `hold`/`pending`/`unresolved` بماند. تکمیل عددی Coverage هرگز دلیل مجاز برای حدس Fact نیست.

## v6 final-audit versus follow-up queues

As of v6.0, `data/review/audit-queue.json` means **universities never audited at all**. It is expected to be empty for the current 85-university inventory.

`data/review/systematic-audit.json` is the immutable first-pass outcome layer for the 69 universities completed in this release.

`data/review/follow-up-queue.json` contains the remaining evidence work. A record can therefore be first-pass complete and still require deep structure/document review.

Never report Follow-up count as “universities not audited.”
