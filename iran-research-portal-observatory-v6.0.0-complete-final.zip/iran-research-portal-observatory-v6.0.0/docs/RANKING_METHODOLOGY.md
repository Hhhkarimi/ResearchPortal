# RTPMI 4.0 — Final ranking methodology

RTPMI ranks the **public Research & Technology Vice-Presidency portal**, not the university's research excellence.

## Eligibility
A university is numerically ranked only when:
1. a direct official portal is recorded with `evidence=verified`;
2. the evidence-derived confidence is at least 65/100;
3. the portal, units, systems and documents pass the publication gate.

All other universities remain visible as **Unranked** with their final audit outcome.

## Dimensions and weights
- Documents & regulations: 20%
- Organizational transparency: 12%
- Library & knowledge services: 10%
- Laboratories: 12%
- Digital systems / IT: 12%
- Industry & technology: 12%
- Freshness & data quality: 12%
- Findability / accessibility evidence: 10%

Weights sum to 100%. They are project-defined.

## Reproducibility
Run `npm run finalize:ranking`. The script derives all numeric scores from the versioned JSON evidence layer and writes:
- `data/statistics/final-ranking.json`
- `data/statistics/final-ranking-summary.json`
- `data/review/final-audit.json`
- updated score/metric fields in `data/universities/catalog.json`

## Interpretation
A low score can reflect weak public discoverability rather than weak research. An Unranked record means insufficient public evidence, not poor performance.
