# Final National Audit Register — 85/85

Audit date: **2026-08-10**

Every university in the project inventory has a final audit record. Finalized audit does **not** imply that every portal has enough direct evidence for a numeric rank.

## Closure summary

- `ranked-scoreable`: **18**
- `closed-unresolved`: **19**
- `closed-evidence-insufficient`: **42**
- `identity-verified-insufficient-depth`: **2**
- `closed-false-positive`: **4**

## Publication decisions

- `publish-ranking`: **18**
- `publish-audit-no-rank`: **61**
- `publish-profile-no-rank`: **2**
- `blocked`: **4**

Machine-readable sources:

- `data/review/final-audit.json`
- `data/review/final-audit.csv`
- `data/statistics/national-comparison-register.json`
