# Systematic Audit — 85/85 First-pass Coverage

## Purpose

This release closes the **national first-pass discovery/audit layer** for the full 85-university inventory while keeping identity verification, organizational verification and RTPMI scoring as separate evidence gates.

## What was completed

The prior Production baseline contained 16 portal identities. The 69 remaining universities were individually searched, classified and persisted as durable audit records on **2026-08-10**. Direct-resolution work during v5 promoted four records from that 69-university cohort to publishable official research-portal/research-surface identities. Production now contains **20** portal identities in total.

The 69 records live in:

`data/review/systematic-audit.json`

## Audit pattern

Each record stores the query pattern and evidence used. The audit checks:

- direct Research & Technology portal/section identity;
- organizational chart or subordinate units;
- library / documentation centre;
- central or research laboratories;
- industry / society relationship office;
- technology / innovation / TTO;
- IT relationship, only where organizational evidence supports it;
- systems and digital services;
- regulations, forms, guidelines and procedures;
- false-positive risk from medical, Azad or unrelated institutions.

## Outcome classes

### `direct-official`
A direct official portal or official research-management surface is resolved on the university domain and is safe to publish as an identity. Organizational relations still require their own evidence.

### `official-domain-reference`
Official university-domain content confirms the Research & Technology function, but a publishable direct portal identity has not yet been resolved.

### `official-channel-reference`
An official university communications channel confirms the function, but direct portal identity remains unresolved.

### `secondary-evidence`
Plausible evidence useful for follow-up. It does not produce a Production Fact.

### `unresolved`
The first pass did not capture sufficiently specific evidence for the correct institution/function. This does **not** mean the function is absent.

### `rejected-false-positive`
The observed result belongs to another institution/unit or otherwise cannot represent the target Research & Technology function. It is retained as blocked discovery memory.

## Current 69-record distribution

| Outcome | Count |
|---|---:|
| direct-official | 4 |
| official-domain-reference | 4 |
| official-channel-reference | 14 |
| secondary-evidence | 24 |
| unresolved | 19 |
| rejected-false-positive | 4 |

Evidence tiers are stored independently of outcome because a direct official university page can provide Tier A evidence even if it only confirms an embedded research structure rather than a standalone portal.

## Direct-resolution highlights

- **Qom University of Technology:** official research-management surface resolved at `https://qut.ac.ir/fa/researches/index`; the official Education & Research Vice-Presidency page links research management, industry, library, central laboratory and innovation. IT remains outside the research graph because the university places it under the presidency domain.
- **Shahid Beheshti University:** official university-domain/news evidence and official university channel confirm the Research & Technology Vice-Presidency; dedicated portal identity remains on hold until resolved.
- **Payame Noor University:** official university news channel confirms the Research & Technology Vice-President; dedicated portal identity remains on hold.
- **Arak University of Technology:** official university channel confirms the Education, Research & Technology Vice-Presidency and Research & Technology management; direct portal remains on hold.

## Why 85/85 does not mean 85 verified RTPMI profiles

The project tracks three separate completion states:

1. **First-pass audit complete** — every inventory university was searched and classified.
2. **Portal identity publishable** — a direct official research portal/surface is safe to expose as a Fact.
3. **Deep RTPMI audit complete** — organizational graph, documents, systems, freshness, UX/accessibility and scoring evidence have passed review.

Only stage 3 can unlock a public RTPMI score.

## Follow-up

`data/review/follow-up-queue.json` preserves all 69 new audit records with the next phase:

- `deep-structure-documents` for direct official portal identities;
- `portal-identity-resolution` for other outcomes.

This is intentional: the 69 universities are **audited**, not silently dropped, and unresolved evidence remains visible as work to be completed rather than being converted into invented data.
