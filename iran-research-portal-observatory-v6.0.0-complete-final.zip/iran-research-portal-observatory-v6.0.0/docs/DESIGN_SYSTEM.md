# Design System — Portal Observatory Neon

## Direction
Dark editorial intelligence interface: ترکیب observatory علمی، AI product و dashboard تحلیلی. هدف جذابیت اجتماعی بدون قربانی کردن اعتبار پژوهشی.

## Typography
- Primary: Vazirmatn Variable
- UI weights: 400/500/700/850-900 where supported
- English micro labels: همان Vazirmatn با `direction:ltr`

## Palette
- Ink `#070913`
- Surface `#111629`
- Violet `#7C3AED`
- Cyan `#22D3EE`
- Acid `#A3FF12`
- Pink `#FF4ECD`
- Danger `#FB7185`
- Amber `#FBBF24`

رنگ‌های Accent فقط برای focal point و visualization استفاده می‌شوند؛ متن طولانی روی سطح dark باقی می‌ماند.

## Shape
- Card radius: 20–32px
- Button radius: 14–15px
- Pill: 999px
- Borders: 1px translucent
- Glass فقط برای لایه‌های اصلی، نه همه اجزا

## Motion
- fast 160ms
- normal 280ms
- visual entrance 620–700ms
- `prefers-reduced-motion` respected

## Accessibility
- focus-visible واضح
- Skip link
- semantic heading order
- SVG aria-label
- هیچ اطلاعات مهمی فقط با hover ارائه نمی‌شود
- chart missing state با `—` و pattern نیز مشخص می‌شود
