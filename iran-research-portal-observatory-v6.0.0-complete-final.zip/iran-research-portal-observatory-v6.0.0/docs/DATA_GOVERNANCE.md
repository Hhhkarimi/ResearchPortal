# Data Governance — Portal Observatory

## Source of truth

Catalogهای JSON در Git منبع اصلی داده‌اند. هر تغییر از طریق diff/PR قابل بازبینی است.

## Promotion pipeline

`discovered → candidate → human reviewed → verified`.

Crawler حق نوشتن مستقیم Fact verified یا RTPMI عمومی را ندارد.

## Organizational relation gate

برای واحدهایی مثل کتابخانه، آزمایشگاه و IT باید رابطه با معاونت در `sourceUrl` قابل مشاهده باشد. «لینک» و «وابستگی سازمانی» دو مفهوم جدا هستند.

## Document provenance

هر سند verified باید URL، parent page (در صورت وجود)، تاریخ بررسی و publisher/approval metadata در حد قابل مشاهده داشته باشد.

## RTPMI publication gate

Production score فقط برای `auditStatus=verified` مجاز است. Validator و Data Layer هر دو این قاعده را enforce می‌کنند.

## Corrections

اصلاح داده باید با Issue/PR، Evidence URL و توضیح دلیل انجام شود. تاریخچه قبلی حذف بی‌ردپا نمی‌شود.

## Versioning

تغییر taxonomy، weights یا operational definition باید version شاخص را افزایش دهد.
