# Strict CSP mode

پیکربندی پیش‌فرض پروژه برای حفظ Static/ISR-friendly performance از CSP رسمی پیشنهادی Next.js بدون nonce استفاده می‌کند و در `script-src` به `unsafe-inline` نیاز دارد. این وب‌اپ در حالت فعلی ورودی HTML کاربر، حساب کاربری یا عملیات حساس ندارد و داده crawl‌شده نیز هرگز به‌عنوان HTML خام render نمی‌شود.

برای استقرارهایی که compliance سخت‌گیرانه به CSP nonce-based نیاز دارند، راهنمای رسمی Next.js پیشنهاد می‌کند nonce در `proxy.ts` برای هر request ساخته شود و صفحه‌ها dynamic render شوند. این انتخاب Static optimization و CDN caching عادی را از بین می‌برد و هزینه/latency را بالا می‌برد.

قبل از فعال‌سازی strict nonce mode:

1. راهنمای رسمی CSP نسخه Next.js پروژه را مرور کنید.
2. `proxy.ts` مطابق مستندات رسمی nonce تولید کند.
3. `script-src 'self' 'nonce-…' 'strict-dynamic'` استفاده شود.
4. تمام routeهای HTML dynamic شوند.
5. CSP را در Preview Deployment با DevTools و گزارش violation تست کنید.

منبع: https://nextjs.org/docs/app/guides/content-security-policy
