# Threat Model — v6.0

## Assets
- اعتبار و صحت دیتاست دانشگاه‌ها و اسناد
- integrity تاریخچه Git
- availability وب‌اپ
- GitHub/Vercel secrets و deployment pipeline

## Trust boundaries
1. وب‌سایت‌های دانشگاهی: **untrusted external input**
2. `data/generated/*`: **untrusted candidate data**
3. Pull request review: مرز ارتقای داده
4. `data/universities` و `data/documents`: source of truth versioned in Git
5. Browser: فقط داده ساختاریافته و text render می‌شود؛ HTML crawl‌شده وارد UI نمی‌شود

## Threats / Controls
- XSS از محتوای crawl: HTML خام هرگز render نمی‌شود؛ JSON-LD escape می‌شود.
- SSRF در crawler: HTTPS-only، DNS public-IP validation، same-origin redirects، no credentials.
- Malicious/huge response: timeout، content-type check، byte/page caps.
- Crawl overload: delay، محدودیت صفحات و robots.txt.
- Supply-chain: Dependabot، Dependency Review، CodeQL، npm audit، کمینه‌سازی dependencies.
- Secret leakage: هیچ secret در `.env.example` نیست؛ GitHub secret scanning باید فعال شود.
- Data poisoning: crawler output مستقیماً وارد catalog Production نمی‌شود؛ human review + evidence required.
- Ranking misrepresentation: `pending` نمی‌تواند score داشته باشد؛ Demo noindex و banner دارد.
- Clickjacking/MIME sniffing/referrer leakage: security headers.

## Residual risks
- robots.txt parser عمداً minimal است و جایگزین crawler enterprise-grade نیست.
- CSP static-mode برای سازگاری Next.js به `unsafe-inline` در script/style نیاز دارد؛ strict nonce mode جداگانه مستند شده است.
- URL و scope دانشگاه‌ها تا تأیید منبع رسمی باید candidate تلقی شوند.
