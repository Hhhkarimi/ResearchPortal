# Data Filling Pipeline — عملیاتی

این فایل توضیح می‌دهد داده‌های سایت چگونه از صفر تا Publication پر می‌شوند.

## A. Inventory

`data/universities/catalog.json` صف دانشگاه‌هاست. در این مرحله فقط identity/domain و scope confidence نگهداری می‌شود.

## B. Portal discovery

`npm run discover:portals` homepageهای رسمی را بررسی و candidateهای محتمل معاونت پژوهش و فناوری را در `data/generated/research-portal-candidates.json` ذخیره می‌کند.

Reviewer باید candidate را باز کند و با منبع رسمی تأیید کند. سپس `researchUrl`, `researchEvidence`, `lastVerified` و PortalProfile وارد Production می‌شوند.

## C. Organizational graph

Crawler/Reviewer از منو، ساختار سازمانی، صفحه مدیران/واحدها و تماس‌ها سرنخ واحدها را استخراج می‌کند. هر واحد باید با `parentUnitId` و `relationStatus` ثبت شود.

نکته: IT با footer یا یک لینک معمولی verified نمی‌شود. برای IT منبع رسمی رابطه سازمانی لازم است.

## D. Expanded crawl

`npm run crawl` دو نوع seed دارد:
1. پرتال اصلی معاونت
2. URL واحدهای سازمانی که قبلاً `relationStatus=verified` و `evidence=verified` دارند

هر seed فقط همان origin را crawl می‌کند. این روش اجازه می‌دهد subdomain کتابخانه/آزمایشگاه بررسی شود، بدون اینکه crawler با هر لینک خارجی از Scope خارج شود.

## E. Candidate extraction

Crawler سه دسته خروجی می‌سازد:
- documents
- organizational units
- systems/services

خروجی هیچ‌وقت خودکار به Production منتقل نمی‌شود.

## F. Human review

برای هر candidate reviewer بررسی می‌کند:
- URL رسمی است؟
- عنوان/context درست است؟
- رابطه با معاونت چیست؟
- واحد تابع است یا فقط linked service؟
- تاریخ/نسخه/مرجع سند قابل استخراج است؟

## G. Promotion

رکوردهای تأییدشده به این catalogها منتقل می‌شوند:
- `data/portals/catalog.json`
- `data/units/catalog.json`
- `data/systems/catalog.json`
- `data/documents/catalog.json`

## H. Scoring

بعد از پوشش rubric، metrics وارد University record می‌شوند. `calculateRTPMI()` امتیاز را محاسبه می‌کند؛ ولی Public Ranking فقط با `auditStatus=verified` آزاد است.

## I. Refresh

- Link audit: هفتگی/دوره‌ای
- Portal crawl: هفتگی/ماهانه با rate limit
- Full human re-audit: دوره‌ای یا پس از تغییر ساختار
- هر تغییر مهم در Git diff/PR ثبت می‌شود.


## Rejected discovery memory

False-positive portal discoveries are versioned in `data/review/rejected-portal-candidates.json`. The discovery script suppresses rejected origins so the same public-relations/news host is not repeatedly proposed as a Research & Technology Vice-Presidency portal. Rejection is reversible by review if stronger official evidence later appears.

## v5 national first-pass closure

The first-pass discovery stage is now complete for 85/85 inventory universities. Future data filling starts from the stored systematic outcome rather than repeating the same generic search from scratch.

1. Read `systematic-audit.json` and the university Review Packet.
2. If Tier A, continue directly to structure/documents.
3. If Tier B, resolve a direct official portal/section URL.
4. If Tier C, replace secondary evidence with a primary official source.
5. If Tier D unresolved, use manual domain navigation, sitemap, official site search and organizational PDFs.
6. If Tier D rejected, avoid the stored false-positive origin/pattern.
7. Only then create/update `portals`, `units`, `systems` or `documents`.
