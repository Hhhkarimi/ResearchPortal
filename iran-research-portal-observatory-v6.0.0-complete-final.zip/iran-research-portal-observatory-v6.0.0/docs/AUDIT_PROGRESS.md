# Audit Progress — v6.0.0

Snapshot: **2026-08-10**

## First-pass coverage

**85 / 85 = 100%** of the current non-medical public-university project inventory has a first-pass audit outcome.

This is a discovery/evidence-classification coverage metric, **not** an RTPMI completion metric.

## Production portal / official research-surface identity

**20 / 85 = 23.5%** have a publishable Production portal/research-surface profile.

The v5 direct-resolution pass includes an official embedded research surface for Qom University of Technology in addition to dedicated Research & Technology portals.

## Deep data currently captured

- **197** organizational-unit records
- **99** systems/services
- **52** verified documents
- **7** universities with verified IT organizational relationships in the current unit catalog
- **16** universities with verified library/document-centre relationships
- **17** universities with verified central/research-laboratory relationships

## Evidence operations

- **440** Evidence Ledger records
- **363** publishable
- **63** hold
- **5** blocked
- Freshness: **21 fresh**, **64 unknown**
- Follow-up priority: **4 P0**, **16 P1**, **23 P2**, **26 P3**

## Remaining work

The 69 records are no longer in the first-pass queue; their first-pass audits are complete. They remain in the Follow-up layer because deep structure/documents or direct identity resolution is still required for some/all dimensions.

The key distinction is:

- **85/85 first-pass audited**
- **20/85 publishable portal/research-surface identities**
- **0/85 RTPMI scores published until full rubric verification**
