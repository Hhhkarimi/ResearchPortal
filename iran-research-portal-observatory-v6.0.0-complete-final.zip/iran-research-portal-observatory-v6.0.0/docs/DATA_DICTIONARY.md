# Data Dictionary v6.0

## University

| field | meaning |
|---|---|
| `slug` | شناسه پایدار |
| `websiteUrl` | دامنه رسمی دانشگاه |
| `researchUrl` | پرتال رسمی/تأییدشده معاونت، اگر موجود |
| `auditStatus` | pending / partial / verified / demo-seed |
| `scopeStatus` | candidate / verified-basic / excluded |
| `score` | RTPMI؛ در Production قبل از verified باید null باشد |
| `confidence` | پوشش Evidence؛ مستقل از score |
| `metrics` | هشت بعد RTPMI، 0..100 یا null |

## PortalProfile

پروفایل ریشه پرتال معاونت: عنوان، URL، contact، sourceUrl، evidence و lastVerified.

## PortalUnit

هر گره در ساختار معاونت:
- `type`: نوع واحد (library-documents, central-laboratory, information-technology, ...)
- `parentUnitId`: والد سازمانی
- `relationStatus`: verified / candidate / unclear
- `url`: صفحه واحد در صورت کشف
- `sourceUrl`: Evidence رابطه

## PortalSystem

سامانه یا خدمت دیجیتال با `category` و `relation`:
- managed-by-portal
- unit-service
- linked-from-portal
- national-related-system

شاعا معمولاً با relation آخر مدل می‌شود مگر Evidence دقیق‌تری وجود داشته باشد.

## ResearchDocument

عنوان، type، topic، URL مستقیم، parentUrl، format، status، evidence، publishedDate، publisherUnit، approvalAuthority و lastVerified.

## Evidence

`verified` یعنی reviewer منبع را بررسی کرده است. `discovered/candidate` نباید به‌صورت fact قطعی یا ورودی Ranking استفاده شود.
