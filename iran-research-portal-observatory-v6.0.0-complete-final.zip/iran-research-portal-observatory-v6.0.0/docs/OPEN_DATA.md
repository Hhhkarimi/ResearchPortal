# Open Data — v6.0

صفحه `/datasets` Snapshotهای تولیدشده را برای بازاستفاده پژوهشی منتشر می‌کند.

## Exportها

- `universities.json`
- `portals.json`
- `units.json`
- `systems.json`
- `documents.json`
- `audit-summary.json`
- `evidence-ledger.json`
- `discovery-hints.json` — **غیرقابل استناد به‌عنوان Fact؛ فقط Discovery**
- `manifest.json`

## License

متادیتای تألیفی پروژه با CC BY 4.0 قابل بازاستفاده است. فایل‌ها و محتوای لینک‌شده دانشگاه‌ها تحت حقوق/شرایط منبع اصلی باقی می‌مانند.

## Reproducibility

Exportها از Catalog Git-versioned ساخته می‌شوند؛ بنابراین commit hash ریپو در Release رسمی باید همراه Dataset گزارش شود.

## Citation safety

برای پژوهش یا گزارش رسمی، از `evidence-ledger.json` فقط رکوردهای `status=publishable` استفاده کنید. `hold` و `blocked` Fact عمومی نیستند.
