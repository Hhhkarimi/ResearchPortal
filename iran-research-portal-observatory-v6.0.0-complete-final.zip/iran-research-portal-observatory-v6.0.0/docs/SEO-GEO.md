# SEO / GEO v6.0

## Search intent
Pages target queries around معاونت پژوهش و فناوری, آیین‌نامه پژوهشی, فرم پژوهشی, کتابخانه مرکزی, مرکز اسناد, آزمایشگاه مرکزی, شاعا, ارتباط با صنعت, فناوری و سامانه‌های پژوهشی by university.

## Indexable entities
- university portal profile
- verified document record
- methodology
- data status/open dataset
- rankings only when verified scores exist

## GEO / citation safety
`llms.txt`, JSON dataset and methodology expose Evidence rules. AI/search engines should not summarize `candidate/pending` as verified facts. RTPMI is explicitly non-official and only publishable for `auditStatus=verified`.

## Structured data
University pages use EducationalOrganization context and verified document pages use DigitalDocument/Dataset-oriented structured metadata where appropriate. No synthetic score is emitted in Production.
