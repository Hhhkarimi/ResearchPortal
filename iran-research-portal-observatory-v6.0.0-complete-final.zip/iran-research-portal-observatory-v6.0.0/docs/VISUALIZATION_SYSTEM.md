# Visualization System — Portal Observatory

Visuals are designed to be screenshot-friendly while preserving evidence semantics.

## RTPMI Orbit
Overall verified portal maturity score with separate confidence context.

## Portal Constellation
Scatter/constellation comparing verified portals. In Production pending universities do not receive synthetic metric coordinates.

## Portal DNA Radar
Eight RTPMI dimensions: documents, organization, library/knowledge, laboratories, systems/IT, industry/technology, freshness/data quality, findability/accessibility.

## Organizational Ecosystem Tree
Shows verified/candidate units and parent-child relationships. This is essential for library/lab/IT scope.

## Audit Rings
Progress of portal verification, organizational-unit review, systems/documents review and publishability.

## Policy Topic Galaxy
Interactive-looking topic distribution for document families.

## Coverage Heatmap
Presence/coverage by document family with explicit pending/not-found semantics.
