# Architecture v6.0

```text
Official university inventory
        ↓
discover-research-portals.mjs
        ↓
Candidate portal URLs
        ↓
Human portal verification
        ↓
Safe crawler
  ├─ organizational units
  ├─ documents
  ├─ systems/services
  └─ outbound related links
        ↓
data/generated/ (untrusted)
        ↓
Human review / promotion
        ↓
data/{portals,units,systems,documents}
        ↓
RTPMI + Confidence publication gate
        ↓
Next.js static/read-heavy UI
        ↓
Vercel
```

## Trust boundaries

- public web content is untrusted input
- crawler output is untrusted candidate
- verified catalog requires human review
- UI never renders crawled HTML raw
- rankings consume only publishable verified records

## GitHub-first

JSON is intentionally preferred over SQLite for source-of-truth diffs, review and provenance. A DB can be added later behind `lib/data.ts` if live editing/login/crowdsourcing becomes necessary.


## Evidence operations layer

```text
verified catalogs ─┬─> evidence ledger ─> /evidence
                   ├─> open-data export ─> /datasets
                   └─> freshness report

pending inventory ─> audit priority ─> review packets ─> human review

all registered URLs ─> link-health audit ─> generated health summary
```

Discovery hints are explicitly non-publishable and can affect audit ordering only.
