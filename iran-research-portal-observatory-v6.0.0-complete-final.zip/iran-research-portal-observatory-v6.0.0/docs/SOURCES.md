# Sources — v6.0

The machine-readable source-of-truth is the `sourceUrl`/`evidenceUrls` stored with each portal, unit, system, document and systematic-audit record. This file lists a few high-signal additions from v5–v6.

## Shahid Chamran University of Ahvaz

- Research & Technology Vice-Presidency portal: `https://research.scu.ac.ir/`
- Organizational chart: `https://research.scu.ac.ir/چارت-سازمانی-معاونت`
- Official portal explicitly exposes industry/entrepreneurship, research management, IT & cyber security, library/information/documents, laboratories, publishing, growth/technology and research centres.

## University of Bonab

- Research & Technology subdomain: `https://research.ubonab.ac.ir/`
- Captured university-linked page: `https://research.ubonab.ac.ir/vlearning-help.html`
- Identity is `verified-basic`; organizational deep audit remains open.

## University of Birjand

- Research & Technology path: `https://birjand.ac.ir/research/fa`
- Official-path evidence includes:
  - `https://birjand.ac.ir/research/fa/news/16258`
  - `https://birjand.ac.ir/research/fa/news/23091`
  - `https://birjand.ac.ir/research/fa/news/23166`
- Identity is `verified-basic`; organizational deep audit remains open.

## Systematic first-pass evidence

All 69 first-pass records, including evidence URLs captured where available, are published in:

`data/review/systematic-audit.json`

Records with indirect/search-index-only evidence remain Hold and do not create Production organizational facts.

## Qom University of Technology

- Combined Education & Research Vice-Presidency surface: `https://qut.ac.ir/fa/education/index`
- Research & Technology Management: `https://qut.ac.ir/fa/researches/index`
- Industry liaison: `https://qut.ac.ir/fa/industry/index`
- Library: `https://qut.ac.ir/fa/library/index`
- Central laboratory: `https://qut.ac.ir/fa/centrallab/index`
- Journals: `https://qut.ac.ir/fa/researches/magazines`
- Scientometrics: `https://scimet.qut.ac.ir/`
- The official structure places ICT under the presidency area rather than the research structure; ICT is therefore not modeled as a subordinate Research & Technology unit.

## Official-reference upgrades retained on Hold

### Shahid Beheshti University

- Official university news: `https://news.sbu.ac.ir/fa/w/dr-mehri-hamidi?redirect=%2F`
- Official university channel: `https://t.me/s/SBU_Official`
- Confirms Research & Technology Vice-Presidency identity/programmes; dedicated portal URL still requires resolution.

### Payame Noor University

- Official university news service: `https://t.me/s/Upnanews?before=11886`
- Historical official university-news evidence: `https://t.me/s/Upnanews?before=237`
- Confirms the Research & Technology Vice-President/function; dedicated portal remains unresolved.

### Arak University of Technology

- Official university channel: `https://t.me/s/ArakutOfficial?before=15586`
- Confirms the Education, Research & Technology Vice-Presidency / Research & Technology management; dedicated portal remains unresolved.
