# Evidence Policy — v6.0

این سند تعیین می‌کند کدام شواهد اجازه ورود به Production و کدام شواهد فقط اجازه ورود به صف ممیزی را دارند.

## Evidence ladder

| کلاس | قابل انتشار؟ | کاربرد |
|---|---:|---|
| `direct-official` | بله | صفحه/فایل مستقیم روی دامنه رسمی دانشگاه یا پرتال معاونت |
| `official-crosslink` | بله | صفحه رسمی دانشگاه که پرتال/واحد مرتبط را صریحاً معرفی یا لینک می‌کند |
| `indexed-official-url` | خیر | URL رسمی که از ایندکس/نتیجه جست‌وجو کشف شده ولی مستقیم ممیزی نشده |
| `indexed-official-navigation` | خیر | نشانه ساختاری از ایندکس رسمی؛ فقط Discovery |
| `indexed-official-content` | خیر | محتوای رسمی ایندکس‌شده؛ برای اولویت ممیزی |
| `candidate-pattern` | خیر | حدس مبتنی بر الگوی URL؛ فقط candidate |
| `rejected` | خیر | false-positive تأییدشده؛ در حافظه rejection باقی می‌ماند |

## Publication firewall

1. RTPMI عمومی فقط برای `auditStatus=verified` آزاد می‌شود.
2. وجود URL رسمی به‌تنهایی رابطه سازمانی را اثبات نمی‌کند.
3. IT فقط با Evidence سازمانی صریح به گراف معاونت اضافه می‌شود.
4. شاعا به‌صورت `national-related-system` مدل می‌شود و آزمایشگاه دانشگاه محسوب نمی‌شود.
5. `not-found` به معنی «در ممیزی مشاهده نشد» است، نه «وجود ندارد».
6. crawler و Search Discovery مستقیماً هیچ رکوردی را به `verified` ارتقا نمی‌دهند.

## Ledger statuses

- `publishable`: Evidence فعلی برای نمایش Fact کافی است.
- `hold`: سرنخ مفید است ولی برای انتشار Fact کافی نیست.
- `blocked`: سرنخ/دامنه رد شده و نباید دوباره خودکار پیشنهاد شود.

دفتر تولیدشده در `data/evidence/ledger.json` و صفحه `/evidence` قابل مشاهده است.
