import Link from "next/link";
import { CommandPalette } from "./command-palette";

const nav = [
  ["دانشگاه‌ها", "/universities"],
  ["اسناد", "/documents"],
  ["پیشرفت ممیزی", "/audit"],
  ["ممیزی ملی", "/audit/systematic"],
  ["ممیزی نهایی", "/audit/final"],
  ["دفتر شواهد", "/evidence"],
  ["رتبه‌بندی پرتال", "/rankings"],
  ["مقایسه", "/compare"],
  ["روش‌شناسی", "/methodology"],
  ["داده باز", "/datasets"]
];

export function SiteHeader() {
  return (
    <header className="siteHeader">
      <div className="shell headerInner">
        <Link href="/" className="brand" aria-label="صفحه اصلی رصد پرتال معاونت پژوهش و فناوری">
          <span className="brandMark">P</span>
          <span><strong>رصد پرتال پژوهش و فناوری</strong><small>Research & Technology Portal Observatory</small></span>
        </Link>
        <nav className="nav" aria-label="ناوبری اصلی">{nav.map(([label, href]) => <Link key={href} href={href}>{label}</Link>)}</nav>
        <CommandPalette/>
        <details className="mobileMenu"><summary aria-label="باز کردن منو">☰</summary><div className="glass">{nav.map(([label,href])=><Link key={href} href={href}>{label}</Link>)}</div></details>
      </div>
    </header>
  );
}
