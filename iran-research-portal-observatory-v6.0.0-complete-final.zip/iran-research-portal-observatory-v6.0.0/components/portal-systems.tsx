import type { PortalSystem } from "@/lib/types";

const categoryLabel: Record<PortalSystem["category"], string> = {
  "research-information":"اطلاعات پژوهش",
  library:"کتابخانه",
  "laboratory-network":"شبکه آزمایشگاهی",
  journals:"نشریات",
  postdoc:"پسادکتری",
  industry:"صنعت",
  innovation:"نوآوری/مالکیت فکری",
  it:"فناوری اطلاعات",
  other:"سایر"
};
const relationLabel: Record<PortalSystem["relation"], string> = {
  "managed-by-portal":"سامانه حوزه معاونت",
  "linked-from-portal":"پیوند از پرتال",
  "unit-service":"خدمت واحد تابع",
  "national-related-system":"سامانه ملی مرتبط"
};

export function PortalSystems({ systems }: { systems: PortalSystem[] }) {
  if (!systems.length) return <div className="emptyState">هنوز سامانه‌ای با رابطه قابل اثبات از پرتال ثبت نشده است.</div>;
  return <div className="systemGrid">{systems.map(s => <a className="systemCard" href={s.url} target="_blank" rel="noopener noreferrer" key={s.id}>
    <span>{categoryLabel[s.category]}</span><strong>{s.nameFa}</strong><small>{relationLabel[s.relation]}</small><b>↗</b>
  </a>)}</div>;
}
