"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import type { ResearchDocument, University } from "@/lib/types";

const filters=["همه","آیین‌نامه","فرم","شیوه‌نامه","دستورالعمل","ارتباط با صنعت","مالکیت فکری","اخلاق پژوهش"];

export function DocumentExplorer({ documents, universities }: { documents: ResearchDocument[]; universities: University[] }) {
  const [query,setQuery]=useState("");
  const [filter,setFilter]=useState("همه");
  const uname=new Map(universities.map(u=>[u.slug,u.nameFa]));
  const filtered=useMemo(()=>documents.filter(d=>{
    const q=query.trim().toLowerCase();
    const text=`${d.title} ${d.type} ${d.topic} ${uname.get(d.universitySlug)||""}`.toLowerCase();
    const matchQ=!q || text.includes(q);
    const matchF=filter==="همه" || d.type===filter || d.topic.includes(filter);
    return matchQ && matchF;
  }),[documents,query,filter,uname]);

  return <>
    <div className="searchHero glass"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="مثلاً: مالکیت فکری، فرصت مطالعاتی، گرنت..." /><kbd>{filtered.length}</kbd></div>
    <div className="chipRow">{filters.map(x=><button className={filter===x?"active":""} onClick={()=>setFilter(x)} key={x}>{x}</button>)}</div>
    <div className="docCards">
      {filtered.map(d=><article className="docCard glass" key={d.id}>
        <div className="docIcon">{d.format}</div><div className="docBody"><div className="docTags"><span>{d.type}</span><span>{d.topic}</span></div><h2><Link href={`/documents/${d.id}`}>{d.title}</Link></h2><p>{uname.get(d.universitySlug)}</p><div className="docFoot"><span className={`status ${d.status}`}>{d.status}</span>{d.evidence === "demo" ? <span className="pendingSource">در انتظار ممیزی</span> : <a href={d.url} target="_blank" rel="noreferrer">منبع ↗</a>}</div></div>
      </article>)}
    </div>
    {!filtered.length && <div className="emptyState">سندی مطابق جست‌وجو پیدا نشد.</div>}
  </>;
}
