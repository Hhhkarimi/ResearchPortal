import type { ResearchDocument } from "@/lib/types";

function hash(value:string){let h=2166136261;for(const c of value){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return Math.abs(h>>>0)}

export function TopicGalaxy({ topics, documents }: { topics: string[]; documents: ResearchDocument[] }) {
  const selected=topics.slice(0,22);
  return <div className="topicGalaxy" role="img" aria-label="کهکشان موضوعات اسناد پژوهشی">
    <div className="galaxyCore"><strong>{topics.length}</strong><span>موضوع سیاستی</span></div>
    {selected.map((topic,index)=>{
      const h=hash(topic); const angle=(h%360)*Math.PI/180; const ring=30+((h>>5)%24); const x=50+Math.cos(angle)*ring; const y=50+Math.sin(angle)*ring*.75;
      const count=documents.filter(d=>d.topic.includes(topic) || topic.includes(d.topic)).length;
      const size=18+Math.min(26,count*5)+(index%3)*2;
      return <span key={topic} className={`galaxyNode ${count?"hasData":"taxonomyOnly"}`} style={{left:`${x}%`,top:`${y}%`,width:size,height:size,"--gdelay":`${index*45}ms`} as React.CSSProperties} title={`${topic} — ${count} سند`}><b>{count || "·"}</b><em>{topic}</em></span>
    })}
    <div className="galaxyOrbit o1"/><div className="galaxyOrbit o2"/><div className="galaxyOrbit o3"/>
  </div>
}
