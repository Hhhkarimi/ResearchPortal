export function MicroBars({ items }: { items: {label:string; value:number}[] }) {
  return <div className="microBars">{items.map((item,i)=>
    <div className="microRow" key={item.label}>
      <span>{item.label}</span>
      <div className="microTrack"><i style={{width:`${item.value}%`, "--d":`${i*90}ms`} as React.CSSProperties}/></div>
      <strong>{item.value}</strong>
    </div>
  )}</div>
}
