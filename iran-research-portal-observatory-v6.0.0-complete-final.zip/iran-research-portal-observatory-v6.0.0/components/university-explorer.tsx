"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import type { University } from "@/lib/types";

export function UniversityExplorer({ universities }: { universities: University[] }) {
  const [query,setQuery]=useState("");
  const [kind,setKind]=useState("همه");
  const [province,setProvince]=useState("همه");
  const provinces=useMemo(()=>["همه",...Array.from(new Set(universities.map(u=>u.province||u.city))).sort((a,b)=>a.localeCompare(b,"fa"))],[universities]);
  const filtered=useMemo(()=>universities.filter(u=>{
    const q=query.trim().toLowerCase();
    const matchQ=!q || `${u.nameFa} ${u.nameEn} ${u.city} ${u.province||""} ${u.tags.join(" ")}`.toLowerCase().includes(q);
    const matchK=kind==="همه" || u.kind===kind;
    const matchP=province==="همه" || (u.province||u.city)===province;
    return matchQ && matchK && matchP;
  }),[universities,query,kind,province]);

  return <>
    <div className="filterBar">
      {["همه","جامع","صنعتی","تخصصی"].map(x=><button className={kind===x?"active":""} key={x} onClick={()=>setKind(x)}>{x}</button>)}
      <label className="selectFilter"><span>استان</span><select value={province} onChange={e=>setProvince(e.target.value)}>{provinces.map(p=><option value={p} key={p}>{p}</option>)}</select></label>
      <label className="filterSearch">⌕ <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="نام دانشگاه، شهر یا استان..." /></label>
    </div>
    <div className="resultCount">{filtered.length} دانشگاه / مؤسسه دانشگاهی در دامنه فعلی</div>
    <div className="universityGrid">
      {filtered.map((u) => {
        const pending=u.auditStatus==="pending" || u.score===null;
        return <Link className="universityCard glass" href={`/universities/${u.slug}`} key={u.slug}>
          <div className="universityTop"><div className="uniGlyph">{u.nameEn.charAt(0)}</div><span className={`audit ${u.auditStatus}`}>{u.auditStatus}</span></div>
          <h2>{u.nameFa}</h2><p>{u.city} · {u.province||"—"} · {u.kind}</p>
          <div className={`cardScore ${pending?"pending":""}`}><strong>{u.score ?? "—"}</strong><span>{pending?"در انتظار ممیزی":"RTPMI"}</span><i style={{width:`${u.score || 0}%`}}/></div>
          <div className="cardMeta">
            {pending ? <>
              <span><b>{u.websiteUrl?"✓":"—"}</b> سایت اصلی</span><span><b>{u.researchUrl?"✓":"—"}</b> پرتال معاونت</span><span><b>{u.scopeStatus==="verified-basic"?"✓":"…"}</b> دامنه</span>
            </> : <>
              <span><b>{u.documentCount}</b> سند</span><span><b>{u.confidence}%</b> اطمینان</span><span><b>{u.brokenLinks}</b> لینک خراب</span>
            </>}
          </div>
        </Link>
      })}
    </div>
    {!filtered.length && <div className="emptyState">دانشگاهی با این فیلتر پیدا نشد.</div>}
  </>;
}
