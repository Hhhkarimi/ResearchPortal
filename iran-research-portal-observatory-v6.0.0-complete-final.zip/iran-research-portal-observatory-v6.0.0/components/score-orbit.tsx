export function ScoreOrbit({ score, label = "RTPMI", size = 188 }: { score: number; label?: string; size?: number }) {
  const r = 64;
  const c = 2 * Math.PI * r;
  const dash = (Math.max(0, Math.min(100, score)) / 100) * c;
  return (
    <div className="scoreOrbit" style={{ width: size, height: size }}>
      <svg viewBox="0 0 180 180" role="img" aria-label={`${label}: ${score} از 100`}>
        <defs>
          <linearGradient id="orbitGradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#7c3aed" />
            <stop offset="52%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#a3ff12" />
          </linearGradient>
          <filter id="glow"><feGaussianBlur stdDeviation="3.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        </defs>
        <circle cx="90" cy="90" r={r} className="orbitTrack" />
        <circle
          cx="90" cy="90" r={r} fill="none" stroke="url(#orbitGradient)" strokeWidth="10"
          strokeLinecap="round" strokeDasharray={`${dash} ${c-dash}`}
          transform="rotate(-90 90 90)" filter="url(#glow)"
        />
        <circle cx="90" cy="26" r="5" fill="#fff" className="orbitDot" />
      </svg>
      <div className="orbitValue"><strong>{score}</strong><span>{label}</span></div>
    </div>
  );
}
