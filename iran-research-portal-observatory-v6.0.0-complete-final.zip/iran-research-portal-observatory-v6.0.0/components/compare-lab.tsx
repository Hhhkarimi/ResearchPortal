"use client";
import { useMemo, useState } from "react";
import type { University } from "@/lib/types";
import { MetricRadar } from "./metric-radar";

const labels:[keyof University["metrics"],string][]=[
  ["documents","اسناد و مقررات"],["organizationalTransparency","شفافیت ساختار"],["libraryKnowledge","کتابخانه/دانش"],["laboratories","آزمایشگاه"],["digitalSystemsIT","سامانه‌ها/IT"],["industryTechnology","صنعت/فناوری"],["freshnessDataQuality","کیفیت/تازگی داده"],["findabilityAccessibility","یافت‌پذیری"]
];
const radar=(u:University)=>labels.map(([k])=>u.metrics[k]??0);

export function CompareLab({ universities }: { universities: University[] }) {
  const ranked=universities.filter(u=>u.score!==null).sort((a,b)=>(b.score||0)-(a.score||0));
  const seeded=(ranked.length>=3?ranked:universities).slice(0,3).map(u=>u.slug);
  const [selected,setSelected]=useState(seeded);
  const list=useMemo(()=>selected.map(s=>universities.find(u=>u.slug===s)).filter(Boolean) as University[],[selected,universities]);
  const setSlot=(i:number,slug:string)=>setSelected(prev=>prev.map((x,idx)=>idx===i?slug:x));
  if(!universities.length) return <div className="emptyState glass">هنوز دانشگاهی برای مقایسه در دسترس نیست.</div>;
  return <>
    <div className="compareSelectors glass">{selected.map((slug,i)=><label key={i}><span>دانشگاه {i+1}</span><select value={slug} onChange={e=>setSlot(i,e.target.value)}>{universities.map(u=><option value={u.slug} key={u.slug}>{u.nameFa}{u.score!==null?` · ${u.score}`:" · Unranked"}</option>)}</select></label>)}</div>
    <div className="compareGrid">{list.map(u=>{const pending=u.score===null;return <article className="glass compareCard" key={u.slug}><div className="compareTop"><div className="uniGlyph">{u.nameEn[0]}</div><div><h2>{u.nameFa}</h2><span>{u.city} · {u.kind}</span></div><strong>{u.score ?? "—"}</strong></div>{pending?<div className="comparePending">این دانشگاه ممیزی شده، اما Evidence کافی برای رتبه عددی ندارد؛ فیلدهای خالی به صفر تبدیل نمی‌شوند.</div>:<MetricRadar values={radar(u)}/>}</article>})}</div>
    <div className="compareTable glass">
      <div className="compareRow head"><span>معیار</span>{list.map((u,i)=><span key={`${u.slug}-${i}`}>{u.nameFa.replace("دانشگاه ","")}</span>)}</div>
      <div className="compareRow"><b>RTPMI 4.0</b>{list.map((u,i)=><strong key={`${u.slug}-${i}`}>{u.score ?? "Unranked"}</strong>)}</div>
      <div className="compareRow"><b>Confidence</b>{list.map((u,i)=><strong key={`${u.slug}-${i}`}>{u.score===null?"—":`${u.confidence}%`}</strong>)}</div>
      {labels.map(([k,label])=><div className="compareRow" key={k}><b>{label}</b>{list.map((u,i)=><strong key={`${u.slug}-${i}`}>{u.metrics[k]===null?"—":Math.round(u.metrics[k]!)}</strong>)}</div>)}
      <div className="compareRow"><b>اسناد verified</b>{list.map((u,i)=><strong key={`${u.slug}-${i}`}>{u.documentCount}</strong>)}</div>
      <div className="compareRow"><b>پرتال رسمی</b>{list.map((u,i)=><strong key={`${u.slug}-${i}`}>{u.researchUrl?"✓":"—"}</strong>)}</div>
    </div>
  </>;
}
