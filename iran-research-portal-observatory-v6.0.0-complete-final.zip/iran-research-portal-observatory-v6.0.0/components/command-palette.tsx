"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";

type Result={kind:string;title:string;href:string};

export function CommandPalette(){
  const [open,setOpen]=useState(false); const [q,setQ]=useState(""); const [results,setResults]=useState<Result[]>([]); const input=useRef<HTMLInputElement>(null);
  useEffect(()=>{const onKey=(e:KeyboardEvent)=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();setOpen(v=>!v)}if(e.key==="Escape")setOpen(false)};window.addEventListener("keydown",onKey);return()=>window.removeEventListener("keydown",onKey)},[]);
  useEffect(()=>{if(open)setTimeout(()=>input.current?.focus(),40)},[open]);
  useEffect(()=>{const text=q.trim();if(!text){setResults([]);return}const c=new AbortController();const timer=setTimeout(async()=>{try{const r=await fetch(`/api/search?q=${encodeURIComponent(text)}`,{signal:c.signal});const j=await r.json();setResults(j.results||[])}catch{}},130);return()=>{clearTimeout(timer);c.abort()}},[q]);
  return <>
    <button className="headerCta" onClick={()=>setOpen(true)} aria-haspopup="dialog">جستجوی سریع <span>⌘K</span></button>
    {open&&<div className="commandBackdrop" role="presentation" onMouseDown={()=>setOpen(false)}>
      <section className="commandPalette glass" role="dialog" aria-modal="true" aria-label="جستجوی سریع" onMouseDown={e=>e.stopPropagation()}>
        <div className="commandInput"><span>⌕</span><input ref={input} value={q} onChange={e=>setQ(e.target.value)} placeholder="دانشگاه، آیین‌نامه، فرم، موضوع..."/><kbd>Esc</kbd></div>
        <div className="commandResults">{results.map((r,i)=><Link href={r.href} key={`${r.kind}-${r.href}-${i}`} onClick={()=>setOpen(false)}><i>{r.kind==="university"?"U":"D"}</i><span>{r.title}</span><b>↗</b></Link>)}{q&&results.length===0&&<p>نتیجه‌ای پیدا نشد.</p>}{!q&&<p>برای جست‌وجوی ۸۵ دانشگاه و اسناد ایندکس‌شده تایپ کنید.</p>}</div>
      </section>
    </div>}
  </>
}
