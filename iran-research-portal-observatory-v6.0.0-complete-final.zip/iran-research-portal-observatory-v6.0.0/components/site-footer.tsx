import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="footer">
      <div className="shell footerGrid">
        <div><div className="brand footerBrand"><span className="brandMark">P</span><strong>رصد پرتال پژوهش و فناوری</strong></div><p>پلتفرم متن‌باز برای رصد ساختار، اسناد، کتابخانه و مرکز اسناد، آزمایشگاه‌ها، سامانه‌ها، IT و خدمات پرتال معاونت پژوهش و فناوری دانشگاه‌های دولتی غیرپزشکی. RTPMI رتبه‌بندی رسمی وزارت علوم نیست.</p></div>
        <div><strong>محصول</strong><Link href="/universities">پرتال دانشگاه‌ها</Link><Link href="/documents">موتور اسناد</Link><Link href="/rankings">RTPMI</Link><Link href="/compare">مقایسه</Link></div>
        <div><strong>شفافیت</strong><Link href="/methodology">روش‌شناسی</Link><Link href="/data-status">وضعیت داده</Link><Link href="/security">امنیت</Link><a href="/generated/scope-summary.json">خلاصه دیتاست ↗</a></div>
      </div>
    </footer>
  );
}
