import type { University } from "@/lib/types";

const cols: [keyof University["coverage"], string][] = [
  ["regulations","آیین‌نامه"],["forms","فرم"],["guidelines","شیوه‌نامه"],["procedures","دستورالعمل"]
];
const level = (v:number, assessed:boolean) => !assessed ? -1 : v >= 80 ? 4 : v >= 60 ? 3 : v >= 40 ? 2 : v > 0 ? 1 : 0;

export function CoverageHeatmap({ universities }: { universities: University[] }) {
  return (
    <div className="heatmap" role="table" aria-label="ماتریس پوشش اسناد">
      <div className="heatHead"><span>دانشگاه</span>{cols.map(([,l])=><span key={l}>{l}</span>)}</div>
      {universities.slice(0,8).map(u => {
        const assessed = u.auditStatus !== "pending" || u.score !== null;
        return <div className="heatRow" key={u.slug}>
          <a href={`/universities/${u.slug}`}>{u.nameFa.replace("دانشگاه ","")}</a>
          {cols.map(([key])=>{const l=level(u.coverage[key],assessed);return <span className={`heatCell ${l<0?"pending":`l${l}`}`} key={key} title={l<0?"در انتظار ممیزی":`${u.coverage[key]}%`}><b>{l<0?"—":u.coverage[key]}</b></span>})}
        </div>
      })}
      {!universities.length && <div className="emptyState">هنوز دانشگاه ممیزی‌شده‌ای برای این ماتریس وجود ندارد.</div>}
    </div>
  );
}
