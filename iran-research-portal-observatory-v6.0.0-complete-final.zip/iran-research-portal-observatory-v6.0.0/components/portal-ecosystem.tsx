import type { PortalUnit } from "@/lib/types";

const labels: Record<PortalUnit["type"], string> = {
  "vice-presidency": "هسته معاونت",
  "research-policy": "سیاستگذاری پژوهشی",
  "industry-society": "صنعت و جامعه",
  "technology-transfer": "انتقال فناوری",
  "library-documents": "کتابخانه و اسناد",
  "central-laboratory": "آزمایشگاه مرکزی",
  "research-laboratories": "آزمایشگاه پژوهشی",
  "information-technology": "فناوری اطلاعات",
  publications: "انتشارات",
  "journals-scientometrics": "نشریات و علم‌سنجی",
  "research-centers": "مراکز پژوهشی",
  ethics: "اخلاق پژوهش",
  committees: "شوراها و کمیسیون‌ها",
  finance: "مالی",
  other: "سایر"
};

export function PortalEcosystem({ units }: { units: PortalUnit[] }) {
  if (!units.length) return <div className="profilePending compact"><i>◌</i><strong>ORGANIZATION MAP PENDING</strong><p>ساختار سازمانی معاونت هنوز با منبع رسمی استخراج نشده است.</p></div>;
  const roots = units.filter((u) => !u.parentUnitId);
  const children = (id: string) => units.filter((u) => u.parentUnitId === id);
  const renderUnit = (unit: PortalUnit, depth = 0): React.ReactNode => (
    <div className="unitBranch" key={unit.id} style={{"--depth": depth} as React.CSSProperties}>
      <div className="unitNode">
        <span>{labels[unit.type]}</span>
        <strong>{unit.nameFa}</strong>
        <em className={unit.relationStatus}>{unit.relationStatus === "verified" ? "رابطه تأییدشده" : "نیازمند بررسی"}</em>
        {unit.url ? <a href={unit.url} target="_blank" rel="noopener noreferrer">صفحه رسمی ↗</a> : <a href={unit.sourceUrl} target="_blank" rel="noopener noreferrer">شاهد سازمانی ↗</a>}
      </div>
      {children(unit.id).length > 0 && <div className="unitChildren">{children(unit.id).map((c) => renderUnit(c, depth + 1))}</div>}
    </div>
  );
  return <div className="portalTree">{roots.map((u) => renderUnit(u))}</div>;
}
