import type { University } from "@/lib/types";

const rings = [
  ["homepage", "صفحه اصلی"],
  ["research", "پرتال معاونت"],
  ["verified", "ممیزی کامل"],
  ["scored", "RTPMI منتشرشده"]
] as const;

export function ScopePulse({ universities }: { universities: University[] }) {
  const total = Math.max(1, universities.length);
  const values: Record<(typeof rings)[number][0], number> = {
    homepage: Math.round(universities.filter((u) => Boolean(u.websiteUrl)).length / total * 100),
    research: Math.round(universities.filter((u) => Boolean(u.researchUrl)).length / total * 100),
    verified: Math.round(universities.filter((u) => u.auditStatus === "verified").length / total * 100),
    scored: Math.round(universities.filter((u) => u.auditStatus === "verified" && u.score !== null).length / total * 100)
  };
  const radii = [104, 82, 60, 38];
  return <div className="scopePulse">
    <svg viewBox="0 0 260 260" role="img" aria-label="وضعیت پیشرفت ممیزی دامنه دانشگاه‌ها">
      <defs>
        <linearGradient id="scopeGradient" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a3ff12"/><stop offset=".45" stopColor="#22d3ee"/><stop offset="1" stopColor="#8b5cf6"/>
        </linearGradient>
      </defs>
      {rings.map(([key], index) => {
        const r = radii[index]; const c = 2 * Math.PI * r; const dash = c * values[key] / 100;
        return <g key={key}>
          <circle cx="130" cy="130" r={r} className="scopeTrack"/>
          <circle cx="130" cy="130" r={r} className="scopeRing" stroke="url(#scopeGradient)" strokeDasharray={`${dash} ${Math.max(0,c-dash)}`} transform="rotate(-90 130 130)"/>
        </g>
      })}
      <text x="130" y="123" textAnchor="middle" className="scopePulseNumber">{universities.length}</text>
      <text x="130" y="145" textAnchor="middle" className="scopePulseLabel">UNIVERSITIES</text>
    </svg>
    <div className="scopeLegend">
      {rings.map(([key,label]) => <div key={key}><i/><span>{label}</span><strong>{values[key]}%</strong></div>)}
    </div>
  </div>
}
