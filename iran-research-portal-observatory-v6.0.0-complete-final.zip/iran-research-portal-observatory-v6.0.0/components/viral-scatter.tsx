import type { University } from "@/lib/types";

function hash(value:string){let h=0;for(let i=0;i<value.length;i++)h=(Math.imul(31,h)+value.charCodeAt(i))|0;return Math.abs(h)}

export function ViralScatter({ universities }: { universities: University[] }) {
  const scored = universities.filter(u => u.score !== null);
  const isScored = scored.length > 0;
  const items = (isScored ? scored : universities).slice(0, isScored ? 40 : 55);
  const maxDocs = Math.max(1, ...items.map(u => u.documentCount));
  return (
    <div className={`scatter ${isScored?"scored":"scopeOnly"}`} role="img" aria-label={isScored?"نقشه جایگاه دانشگاه‌ها بر اساس شفافیت و بلوغ دیجیتال":"نقشه دامنه دانشگاه‌های فهرست‌شده؛ موقعیت نقاط در حالت بدون امتیاز صرفاً چیدمان بصری است"}>
      <div className="scatterGrid"/>
      <div className="scatterAxis axisY">{isScored?"شفافیت ↑":"دامنه ملی"}</div>
      <div className="scatterAxis axisX">{isScored?"بلوغ دیجیتال ←":"بدون رتبه تا پایان ممیزی"}</div>
      {!isScored && <div className="scatterNotice">Scope constellation · no synthetic ranking</div>}
      {items.map((u, i) => {
        const h=hash(u.slug);
        const x = isScored ? 8 + ((u.metrics.digitalSystemsIT || 0) * .84) : 8 + (h % 8400) / 100;
        const y = isScored ? 90 - ((u.metrics.organizationalTransparency || 0) * .78) : 10 + ((Math.floor(h/97)%7600)/100);
        const s = isScored ? 16 + (u.documentCount / maxDocs) * 34 : 18 + (i%5)*3;
        return (
          <a key={u.slug} href={`/universities/${u.slug}`} className="scatterBubble"
             style={{ left:`${x}%`, top:`${y}%`, width:s, height:s, "--delay":`${i*35}ms`} as React.CSSProperties}
             title={isScored?`${u.nameFa} — ${u.score}`:`${u.nameFa} — در انتظار ممیزی`}>
            <span>{isScored?Math.round(u.score || 0):""}</span>
            <em>{u.nameFa.replace("دانشگاه ","")}</em>
          </a>
        )
      })}
    </div>
  )
}
