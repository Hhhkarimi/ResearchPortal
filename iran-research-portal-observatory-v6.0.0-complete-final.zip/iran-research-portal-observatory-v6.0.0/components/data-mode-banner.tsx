export function DataModeBanner({ demo=false }: { demo?:boolean }) {
  if(demo) return <div className="demoBanner"><span>DEMO MODE</span> امتیازها و نمودارهای عددی این حالت نمایشی‌اند و برای بررسی UI هستند؛ این حالت noindex است.</div>;
  return <div className="productionBanner"><span>PRODUCTION DATA</span> داده واقعی پرتال‌ها به‌تدریج وارد می‌شود؛ RTPMI فقط برای رکوردهای کاملاً ممیزی‌شده نمایش داده می‌شود و `partial` یعنی داده رسمی ثبت شده اما ارزیابی هنوز کامل نیست.</div>;
}
