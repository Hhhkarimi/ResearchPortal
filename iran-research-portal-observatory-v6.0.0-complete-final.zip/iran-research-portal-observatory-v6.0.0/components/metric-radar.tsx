const labels = ["اسناد","ساختار","کتابخانه","آزمایشگاه","سامانه/IT","صنعت/فناوری","تازگی داده","UX/دسترسی"];

export function MetricRadar({ values }: { values: number[] }) {
  const center = 150, maxR = 112, n = values.length;
  const point = (value: number, i: number) => {
    const angle = -Math.PI/2 + (i * Math.PI * 2) / n;
    const r = maxR * (value/100);
    return [center + Math.cos(angle)*r, center + Math.sin(angle)*r];
  };
  const grid = [25,50,75,100].map(level => Array.from({length:n},(_,i)=>point(level,i).join(",")).join(" "));
  const data = values.map((v,i)=>point(v,i).join(",")).join(" ");
  return (
    <div className="radarWrap">
      <svg viewBox="0 0 300 300" role="img" aria-label="رادار شاخص بلوغ پرتال معاونت پژوهش و فناوری">
        <defs><linearGradient id="radarFill" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#7c3aed" stopOpacity=".65"/><stop offset="1" stopColor="#22d3ee" stopOpacity=".22"/></linearGradient></defs>
        {grid.map((p,i)=><polygon key={i} points={p} fill="none" className="radarGrid" />)}
        {Array.from({length:n},(_,i)=>{ const [x,y]=point(100,i); return <line key={i} x1={center} y1={center} x2={x} y2={y} className="radarGrid"/>})}
        <polygon points={data} fill="url(#radarFill)" className="radarData"/>
        {values.map((v,i)=>{const [x,y]=point(v,i);return <circle key={i} cx={x} cy={y} r="4" className="radarDot"/>})}
      </svg>
      <div className="radarLabels">{labels.map((l,i)=><span key={l} style={{"--i":i} as React.CSSProperties}>{l}</span>)}</div>
    </div>
  );
}
