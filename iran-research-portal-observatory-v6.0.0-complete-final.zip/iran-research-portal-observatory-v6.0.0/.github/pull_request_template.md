## تغییر

- [ ] کد/UI
- [ ] داده پرتال
- [ ] واحد سازمانی
- [ ] سامانه/خدمت
- [ ] سند
- [ ] روش‌شناسی RTPMI
- [ ] امنیت/CI

## Evidence برای تغییر داده

Official source URL(s):

Last verified date:

Relation (if unit/system):

## Checklist

- [ ] `npm run validate:data`
- [ ] `npm run release:check`
- [ ] candidate به‌عنوان verified جا زده نشده است
- [ ] `not-found` به «فاقد» تبدیل نشده است
- [ ] اگر IT اضافه شده، Evidence سازمانی رسمی دارد
