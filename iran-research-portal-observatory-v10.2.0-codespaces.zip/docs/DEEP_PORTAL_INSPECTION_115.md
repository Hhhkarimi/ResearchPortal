# Deep first-party R&T portal inspection — 115 ISC institutions

> Snapshot: 2026-08-11. This is a bounded, reproducible first-party discovery/inspection pass. It does **not** claim that every page on every portal has been enumerated.

## Executive result

- ISC institutions in scope: **۱۱۵ / ۱۱۵**.
- Confirmed direct R&T portal seeds: **۵۲**.
- Confirmed first-party research-surface crawl seeds (not asserted as portal homepages): **۹**.
- Institutions without a confirmed seed: **۵۴**.
- First-party URLs submitted to web retrieval: **۳۲۸** across **۵۷** institutions; **۱۱۷** returned multi-line content and **۲۱۱** returned only a minimal URL/title surface.
- Same-host central-portal pages: **۸۳**; official related surfaces outside the central host: **۱۵۵**; pages on official domains where the R&T root remains unresolved: **۹۰**.
- Classified document/index candidates: **۱۴۴**, including **۸۴** direct PDF candidates.
- Contentful, dimension-specific same-host candidates: **۲۷**.
- Direct HTTP status codes: **not asserted**. The audit environment's direct egress returned an intermediary 502 for Iranian university hosts; the web retriever exposed page content but not transport-level status codes.

## Method and evidence rules

1. The ISC order and membership are locked to `data/isc/institutions.json`.
2. Only first-party university domains are retained as evidence. Search results from other domains are retained only in the separate seed-candidate ledger and explicitly marked discovery-only.
3. A portal root proves only portal identity. It is not reused to verify organization, library, laboratory, industry, IT, systems, or documents.
4. A page is `central-portal` only when its host exactly matches the registered R&T portal seed host. Other subdomains of the same university are `official-related-surface` and supporting-only.
5. IT remains a candidate unless an official organizational page explicitly places it under the R&T vice-presidency.
6. A one-line/minimal retrieval surface is discovery-grade and cannot verify a dimension.
7. `no-confirmed-seed` and an empty dimension mean unresolved, never absent or zero.
8. Numeric RTPMI ranking should be recomputed only after the package's existing evidence/confidence gates accept dimension-specific evidence.

## Seed ledger — all 115 institutions

| # | institution | outcome | seed | discovered pages | central-host pages | documents |
|---:|---|---|---|---:|---:|---:|
| ۱ | دانشگاه تهران (`tehran`) | پرتال مستقیم تأییدشده | [link](https://research.ut.ac.ir/fa) | ۱۰ | ۵ | ۴ |
| ۲ | دانشگاه تربیت مدرس (`tarbiat-modares`) | پرتال مستقیم تأییدشده | [link](https://res.modares.ac.ir/) | ۹ | ۲ | ۹ |
| ۳ | دانشگاه فردوسی مشهد (`ferdowsi`) | پرتال مستقیم تأییدشده | [link](https://vpr.um.ac.ir/) | ۸ | ۱ | ۴ |
| ۴ | دانشگاه شهید بهشتی (`shahid-beheshti`) | پرتال مستقیم تأییدشده | [link](https://resevp.sbu.ac.ir/) | ۷ | ۰ | ۶ |
| ۵ | دانشگاه شیراز (`shiraz`) | پرتال مستقیم تأییدشده | [link](https://research.shirazu.ac.ir/) | ۰ | ۰ | ۰ |
| ۶ | دانشگاه تبریز (`tabriz`) | پرتال مستقیم تأییدشده | [link](https://research.tabrizu.ac.ir/) | ۲ | ۰ | ۲ |
| ۷ | دانشگاه اصفهان (`isfahan`) | پرتال مستقیم تأییدشده | [link](https://research.ui.ac.ir/) | ۹ | ۰ | ۷ |
| ۸ | دانشگاه رازی (`razi`) | پرتال مستقیم تأییدشده | [link](https://are.razi.ac.ir/) | ۱۰ | ۱ | ۰ |
| ۹ | دانشگاه تحصیلات تکمیلی علوم پایه زنجان (`iasbs`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۰ | دانشگاه خوارزمی (`kharazmi`) | پرتال مستقیم تأییدشده | [link](https://research.khu.ac.ir/) | ۱۰ | ۰ | ۴ |
| ۱۱ | دانشگاه علامه طباطبایی (`allameh`) | پرتال مستقیم تأییدشده | [link](https://research.atu.ac.ir/fa) | ۰ | ۰ | ۰ |
| ۱۲ | دانشگاه شهید باهنر کرمان (`shahid-bahonar-kerman`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://research.uk.ac.ir/%D8%A2%D9%88%D9%86-%D8%AA%D8%AD%D8%AA-%D8%AE%D9%84%D8%A3) | ۳ | ۰ | ۱ |
| ۱۳ | دانشگاه گیلان (`guilan`) | پرتال مستقیم تأییدشده | [link](https://resvp.guilan.ac.ir/) | ۷ | ۰ | ۱ |
| ۱۴ | دانشگاه ارومیه (`urmia`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۵ | دانشگاه سمنان (`semnan`) | پرتال مستقیم تأییدشده | [link](https://research.semnan.ac.ir/) | ۷ | ۰ | ۱ |
| ۱۶ | دانشگاه سیستان و بلوچستان (`sistan-baluchestan`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B1%DA%A9%D8%B2-%DA%A9%D8%B1%D8%B3%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D8%B8%D8%B1%DB%8C%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7) | ۶ | ۰ | ۵ |
| ۱۷ | دانشگاه یزد (`yazd`) | پرتال مستقیم تأییدشده | [link](https://yazd.ac.ir/offices/research/home/introduction) | ۸ | ۸ | ۴ |
| ۱۸ | دانشگاه محقق اردبیلی (`mohaghegh-ardabili`) | پرتال مستقیم تأییدشده | [link](https://uma.ac.ir/find-8.270.2596.fa.html) | ۲ | ۱ | ۲ |
| ۱۹ | دانشگاه کردستان (`kurdistan`) | پرتال مستقیم تأییدشده | [link](https://uok.ac.ir/web/research-and-innovation) | ۶ | ۳ | ۵ |
| ۲۰ | دانشگاه شهید چمران اهواز (`shahid-chamran-ahvaz`) | پرتال مستقیم تأییدشده | [link](https://research.scu.ac.ir/) | ۷ | ۰ | ۲ |
| ۲۱ | دانشگاه کاشان (`kashan`) | پرتال مستقیم تأییدشده | [link](https://research.kashanu.ac.ir/) | ۹ | ۳ | ۷ |
| ۲۲ | دانشگاه شهرکرد (`shahrekord`) | پرتال مستقیم تأییدشده | [link](https://www.sku.ac.ir/Vice-President/research) | ۲ | ۲ | ۱ |
| ۲۳ | دانشگاه بوعلی سینا (`bu-ali-sina`) | پرتال مستقیم تأییدشده | [link](https://res.basu.ac.ir/) | ۰ | ۰ | ۰ |
| ۲۴ | دانشگاه قم (`qom`) | پرتال مستقیم تأییدشده | [link](https://research.qom.ac.ir/) | ۹ | ۰ | ۲ |
| ۲۵ | دانشگاه الزهرا (س) (`alzahra`) | پرتال مستقیم تأییدشده | [link](https://research.alzahra.ac.ir/) | ۱۰ | ۱ | ۰ |
| ۲۶ | دانشگاه مازندران (`mazandaran`) | پرتال مستقیم تأییدشده | [link](https://research.umz.ac.ir/) | ۰ | ۰ | ۰ |
| ۲۷ | دانشگاه بین المللی امام خمینی (ره) (`imam-khomeini-international`) | seed تأییدشده ندارد | — | ۴ | ۰ | ۰ |
| ۲۸ | دانشگاه خلیج فارس (`persian-gulf`) | پرتال مستقیم تأییدشده | [link](https://pgu.ac.ir/fa/researchdeputy) | ۱ | ۰ | ۱ |
| ۲۹ | دانشگاه زنجان (`zanjan`) | پرتال مستقیم تأییدشده | [link](https://research.znu.ac.ir/) | ۰ | ۰ | ۰ |
| ۳۰ | دانشگاه ایلام (`ilam`) | پرتال مستقیم تأییدشده | [link](https://www.ilam.ac.ir/dep/research/) | ۴ | ۴ | ۴ |
| ۳۱ | دانشگاه حکیم سبزواری (`hakim-sabzevari`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://www.hsu.ac.ir/research/) | ۱۰ | ۰ | ۴ |
| ۳۲ | دانشگاه اراک (`arak`) | پرتال مستقیم تأییدشده | [link](https://research.araku.ac.ir/) | ۰ | ۰ | ۰ |
| ۳۳ | دانشگاه شهید مدنی آذربایجان (`azarbaijan-shahid-madani`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۳۴ | دانشگاه بیرجند (`birjand`) | پرتال مستقیم تأییدشده | [link](https://birjand.ac.ir/research/fa) | ۹ | ۹ | ۶ |
| ۳۵ | دانشگاه ولی عصر (عج) رفسنجان (`vali-asr-rafsanjan`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۳۶ | دانشگاه لرستان (`lorestan`) | پرتال مستقیم تأییدشده | [link](https://research.lu.ac.ir/) | ۹ | ۰ | ۰ |
| ۳۷ | دانشگاه مراغه (`maragheh`) | پرتال مستقیم تأییدشده | [link](https://rtm.maragheh.ac.ir/) | ۳ | ۰ | ۳ |
| ۳۸ | دانشگاه زابل (`zabol`) | پرتال مستقیم تأییدشده | [link](https://uoz.ac.ir/prt/) | ۲ | ۲ | ۱ |
| ۳۹ | دانشگاه یاسوج (`yasouj`) | پرتال مستقیم تأییدشده | [link](https://yu.ac.ir/fa/res/) | ۱ | ۱ | ۱ |
| ۴۰ | دانشگاه دامغان (`damghan`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۴۱ | دانشگاه بناب (`bonab`) | پرتال مستقیم تأییدشده | [link](https://research.ubonab.ac.ir/) | ۰ | ۰ | ۰ |
| ۴۲ | دانشگاه گلستان (`golestan`) | پرتال مستقیم تأییدشده | [link](https://gu.ac.ir/research/) | ۴ | ۴ | ۱ |
| ۴۳ | دانشگاه هرمزگان (`hormozgan`) | پرتال مستقیم تأییدشده | [link](https://www.hormozgan.ac.ir/home/index/10/28/373) | ۱ | ۱ | ۱ |
| ۴۴ | دانشگاه تفرش (`tafresh`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۴۵ | دانشگاه اردکان (`ardakan`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۴۶ | دانشگاه فسا (`fasa`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۴۷ | دانشگاه آیت الله العظمی بروجردی (ره) (`ayatollah-borujerdi`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۴۸ | دانشگاه بجنورد (`bojnord`) | پرتال مستقیم تأییدشده | [link](https://vr.ub.ac.ir/) | ۰ | ۰ | ۰ |
| ۴۹ | دانشگاه علوم و فنون دریایی خرمشهر (`khorramshahr-marine`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۰ | دانشگاه میبد (`meybod`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://new.meybod.ac.ir/research/forms) | ۱۰ | ۰ | ۳ |
| ۵۱ | دانشگاه بزرگمهر قائنات (`bozorgmehr-qaenat`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://www.buqaen.ac.ir/%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C) | ۱۰ | ۰ | ۴ |
| ۵۲ | دانشگاه دریانوردی و علوم دریایی چابهار (`chabahar-maritime`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۳ | دانشگاه ولایت (`velayat`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۴ | دانشگاه تخصصی فناوری های نوین آمل (`amol-special-tech`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://ausmt.ac.ir/forms) | ۹ | ۰ | ۲ |
| ۵۵ | دانشگاه ملایر (`malayer`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۶ | دانشگاه گنبد کاووس (`gonbad-kavous`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۷ | دانشگاه تربت حیدریه (`torbat-heydarieh`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۸ | دانشگاه حضرت معصومه (س) (`hazrat-masoumeh`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۵۹ | دانشگاه جهرم (`jahrom`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۰ | دانشگاه کوثر (`kosar`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۱ | دانشگاه جیرفت (`jiroft`) | seed تأییدشده ندارد | — | ۱ | ۰ | ۰ |
| ۶۲ | دانشگاه سلمان فارسی کازرون (`salman-farsi-kazerun`) | seed تأییدشده ندارد | — | ۲ | ۰ | ۱ |
| ۶۳ | مرکز آموزش عالی لار (`lar-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۴ | مجتمع آموزش عالی گناباد (`gonabad-higher-ed`) | seed تأییدشده ندارد | — | ۸ | ۰ | ۰ |
| ۶۵ | مجتمع آموزش عالی بم (`bam-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۶ | دانشگاه نیشابور (`neyshabur`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۷ | مرکز آموزش عالی اقلید (`eghlid-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۸ | مرکز آموزش عالی کاشمر (`kashmar-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۶۹ | دانشگاه سید جمال الدین اسدآبادی (`seyed-jamaleddin-asadabadi`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۷۰ | دانشگاه علم و صنعت ایران (`iust`) | پرتال مستقیم تأییدشده | [link](https://research.iust.ac.ir/) | ۸ | ۰ | ۳ |
| ۷۱ | دانشگاه صنعتی شریف (`sharif`) | پرتال مستقیم تأییدشده | [link](https://research.sharif.ir/) | ۱۰ | ۰ | ۳ |
| ۷۲ | دانشگاه صنعتی امیرکبیر (`amirkabir`) | پرتال مستقیم تأییدشده | [link](https://research.aut.ac.ir/) | ۰ | ۰ | ۰ |
| ۷۳ | دانشگاه صنعتی خواجه نصیرالدین طوسی (`kntu`) | پرتال مستقیم تأییدشده | [link](https://research.kntu.ac.ir/) | ۸ | ۰ | ۲ |
| ۷۴ | دانشگاه صنعتی اصفهان (`isfahan-technology`) | پرتال مستقیم تأییدشده | [link](https://research.iut.ac.ir/) | ۸ | ۸ | ۵ |
| ۷۵ | دانشگاه صنعتی شاهرود (`shahrood-technology`) | پرتال مستقیم تأییدشده | [link](https://www.shahroodut.ac.ir/fa/sec/index.php?id=11) | ۱۰ | ۱۰ | ۱ |
| ۷۶ | دانشگاه صنعتی نوشیروانی بابل (`babol-noshirvani`) | پرتال مستقیم تأییدشده | [link](https://research.nit.ac.ir/) | ۸ | ۲ | ۸ |
| ۷۷ | دانشگاه صنعتی سهند (`sahand`) | پرتال مستقیم تأییدشده | [link](https://sut.ac.ir/research/fa/) | ۴ | ۴ | ۲ |
| ۷۸ | دانشگاه صنعتی شیراز (`shiraz-technology`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۷۹ | دانشگاه تحصیلات تکمیلی صنعتی و فناوری پیشرفته کرمان (`kgut`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۰ | دانشگاه صنعتی ارومیه (`urmia-technology`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۱ | دانشگاه صنعتی قوچان (`qochan-technology`) | پرتال مستقیم تأییدشده | [link](https://research.qiet.ac.ir/) | ۰ | ۰ | ۰ |
| ۸۲ | دانشگاه صنعتی اراک (`arak-technology`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۳ | دانشگاه صنعتی کرمانشاه (`kermanshah-technology`) | پرتال مستقیم تأییدشده | [link](https://research.kut.ac.ir/) | ۰ | ۰ | ۰ |
| ۸۴ | دانشگاه صنعتی قم (`qom-technology`) | پرتال مستقیم تأییدشده | [link](https://qut.ac.ir/fa/researches/index) | ۱ | ۱ | ۱ |
| ۸۵ | دانشگاه صنعتی جندی شاپور دزفول (`jundi-shapur-dezful`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۶ | دانشگاه صنعتی همدان (`hamedan-technology`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۷ | دانشگاه صنعتی خاتم الانبیاء بهبهان (`khatam-behbahan`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۸ | دانشگاه صنعتی سیرجان (`sirjan-technology`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۸۹ | دانشگاه علم و فناوری مازندران (بهشهر) (`mazandaran-science-tech`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۰ | مجتمع آموزش عالی فنی و مهندسی اسفراین (`esfarayen-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۱ | دانشگاه صنعتی بیرجند (`birjand-technology`) | پرتال مستقیم تأییدشده | [link](https://research.birjandut.ac.ir/) | ۰ | ۰ | ۰ |
| ۹۲ | مرکز آموزش عالی فنی و مهندسی بوئین زهرا (`buin-zahra-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۳ | مرکز آموزش عالی محلات (`mahallat-higher-ed`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۴ | دانشگاه علوم کشاورزی و منابع طبیعی گرگان (`gorgan-agri`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۵ | دانشگاه علوم کشاورزی و منابع طبیعی ساری (`sari-agri`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۶ | دانشگاه علوم کشاورزی و منابع طبیعی خوزستان (`khuzestan-agri`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://asnrukh.ac.ir/research/fa/regulation?sort=-categoryId) | ۲ | ۰ | ۲ |
| ۹۷ | دانشکده کشاورزی و دامپروری تربت جام (`torbat-jam-agri`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۹۸ | دانشگاه هنر ایران (`iran-art`) | پرتال مستقیم تأییدشده | [link](https://research.art.ac.ir/fa) | ۱ | ۱ | ۱ |
| ۹۹ | دانشگاه هنر اسلامی تبریز (`tabriz-islamic-art`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://research.tabriziau.ac.ir/News/159/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D8%AA%DA%A9%D9%85%DB%8C%D9%84%DB%8C-%D9%81%D8%B1%D8%A7%D8%AE%D9%88%D8%A7%D9%86-%D8%B7%D8%B1%D8%A7%D8%AD%DB%8C-%C2%AB%D8%B2%D8%A8%D8%A7%D9%86-%D9%85%D9%84%DB%8C-%D8%A7%D9%84%D9%85%D8%A7%D9%86%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B3%D8%AA%E2%80%8C%D8%A8%D9%88%D9%85-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%88-%D9%86%D9%88%D8%A2%D9%88%D8%B1%DB%8C-%D8%A7%DB%8C%D8%B1%D8%A7%D9%86%C2%BB.html) | ۴ | ۰ | ۲ |
| ۱۰۰ | دانشگاه هنر اصفهان (`isfahan-art`) | سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی | [link](https://entrepreneurship.aui.ac.ir/Index.aspx?BlockName=tool_link_sample_moavenatpajooheshi_block276&codel=231&lang=1&page_=form&referrer=link&sub=7&tempname=Moavenatshow) | ۶ | ۰ | ۳ |
| ۱۰۱ | دانشگاه هنر شیراز (`shiraz-art`) | seed تأییدشده ندارد | — | ۱۰ | ۰ | ۰ |
| ۱۰۲ | دانشگاه پیام نور (`payame-noor`) | seed تأییدشده ندارد | — | ۱ | ۰ | ۱ |
| ۱۰۳ | دانشگاه ملی مهارت (`national-skills`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۰۴ | دانشگاه فرهنگیان (`farhangian`) | پرتال مستقیم تأییدشده | [link](https://cfu.ac.ir/fa/grid/11/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C) | ۲ | ۲ | ۰ |
| ۱۰۵ | دانشگاه جامع علمی کاربردی (`applied-science`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۰۶ | دانشگاه جامع امام حسین (ع) (`imam-hossein`) | seed تأییدشده ندارد | — | ۱ | ۰ | ۱ |
| ۱۰۷ | دانشگاه شاهد (`shahed`) | پرتال مستقیم تأییدشده | [link](https://res.shahed.ac.ir) | ۵ | ۰ | ۲ |
| ۱۰۸ | دانشگاه صنعتی مالک اشتر (`malek-ashtar`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۰۹ | دانشگاه تربیت دبیر شهید رجایی (`shahid-rajaee`) | پرتال مستقیم تأییدشده | [link](https://www.sru.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/) | ۴ | ۴ | ۳ |
| ۱۱۰ | دانشگاه فرماندهی و ستاد آجا (دافوس) (`aja-command`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۱۱ | دانشگاه عالی دفاع ملی (`national-defense`) | seed تأییدشده ندارد | — | ۳ | ۰ | ۳ |
| ۱۱۲ | دانشگاه علوم انتظامی امین (`amin-police`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۱۳ | دانشگاه صنعت نفت (`petroleum`) | پرتال مستقیم تأییدشده | [link](https://www.put.ac.ir/fa-IR/put/4793/page/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%D9%8A) | ۳ | ۳ | ۲ |
| ۱۱۴ | دانشگاه صدا و سیمای جمهوری اسلامی ایران (`irib`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |
| ۱۱۵ | مرکز آموزش عالی هوانوردی و فرودگاهی کشور (`civil-aviation`) | seed تأییدشده ندارد | — | ۰ | ۰ | ۰ |

## Dimension coverage matrix

> `direct` requires at least one contentful, dimension-tagged page on the registered central portal host. `support` means a first-party university page outside that host or a minimal retrieval. `unresolved` is not absence.

| # | institution | ساختار | کتابخانه/اسناد | آزمایشگاه | صنعت/فناوری | IT نامزد | سامانه | اسناد/فرم‌ها |
|---:|---|---|---|---|---|---|---|---|
| ۱ | دانشگاه تهران | direct | unresolved | unresolved | direct | unresolved | unresolved | support |
| ۲ | دانشگاه تربیت مدرس | direct | unresolved | unresolved | direct | unresolved | unresolved | direct |
| ۳ | دانشگاه فردوسی مشهد | support | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴ | دانشگاه شهید بهشتی | unresolved | support | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵ | دانشگاه شیراز | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶ | دانشگاه تبریز | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | support |
| ۷ | دانشگاه اصفهان | unresolved | unresolved | unresolved | support | unresolved | unresolved | support |
| ۸ | دانشگاه رازی | support | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۹ | دانشگاه تحصیلات تکمیلی علوم پایه زنجان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰ | دانشگاه خوارزمی | unresolved | unresolved | support | support | unresolved | unresolved | support |
| ۱۱ | دانشگاه علامه طباطبایی | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۲ | دانشگاه شهید باهنر کرمان | support | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۱۳ | دانشگاه گیلان | support | support | unresolved | unresolved | unresolved | support | support |
| ۱۴ | دانشگاه ارومیه | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۵ | دانشگاه سمنان | support | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۱۶ | دانشگاه سیستان و بلوچستان | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۱۷ | دانشگاه یزد | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | direct |
| ۱۸ | دانشگاه محقق اردبیلی | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۹ | دانشگاه کردستان | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۲۰ | دانشگاه شهید چمران اهواز | unresolved | unresolved | support | support | unresolved | unresolved | unresolved |
| ۲۱ | دانشگاه کاشان | support | unresolved | unresolved | support | unresolved | direct | support |
| ۲۲ | دانشگاه شهرکرد | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۲۳ | دانشگاه بوعلی سینا | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۲۴ | دانشگاه قم | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۲۵ | دانشگاه الزهرا (س) | support | support | unresolved | support | unresolved | unresolved | unresolved |
| ۲۶ | دانشگاه مازندران | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۲۷ | دانشگاه بین المللی امام خمینی (ره) | support | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۲۸ | دانشگاه خلیج فارس | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۲۹ | دانشگاه زنجان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۳۰ | دانشگاه ایلام | unresolved | unresolved | unresolved | direct | unresolved | unresolved | support |
| ۳۱ | دانشگاه حکیم سبزواری | support | unresolved | support | unresolved | unresolved | unresolved | support |
| ۳۲ | دانشگاه اراک | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۳۳ | دانشگاه شهید مدنی آذربایجان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۳۴ | دانشگاه بیرجند | direct | unresolved | unresolved | unresolved | unresolved | unresolved | direct |
| ۳۵ | دانشگاه ولی عصر (عج) رفسنجان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۳۶ | دانشگاه لرستان | support | unresolved | support | support | unresolved | support | unresolved |
| ۳۷ | دانشگاه مراغه | support | unresolved | unresolved | unresolved | unresolved | support | support |
| ۳۸ | دانشگاه زابل | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۳۹ | دانشگاه یاسوج | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۰ | دانشگاه دامغان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۱ | دانشگاه بناب | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۲ | دانشگاه گلستان | support | unresolved | unresolved | direct | unresolved | direct | direct |
| ۴۳ | دانشگاه هرمزگان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۴ | دانشگاه تفرش | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۵ | دانشگاه اردکان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۶ | دانشگاه فسا | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۷ | دانشگاه آیت الله العظمی بروجردی (ره) | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۸ | دانشگاه بجنورد | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۴۹ | دانشگاه علوم و فنون دریایی خرمشهر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۰ | دانشگاه میبد | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | support |
| ۵۱ | دانشگاه بزرگمهر قائنات | support | support | support | support | unresolved | unresolved | support |
| ۵۲ | دانشگاه دریانوردی و علوم دریایی چابهار | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۳ | دانشگاه ولایت | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۴ | دانشگاه تخصصی فناوری های نوین آمل | support | unresolved | support | support | unresolved | unresolved | support |
| ۵۵ | دانشگاه ملایر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۶ | دانشگاه گنبد کاووس | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۷ | دانشگاه تربت حیدریه | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۸ | دانشگاه حضرت معصومه (س) | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۵۹ | دانشگاه جهرم | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۰ | دانشگاه کوثر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۱ | دانشگاه جیرفت | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۲ | دانشگاه سلمان فارسی کازرون | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۳ | مرکز آموزش عالی لار | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۴ | مجتمع آموزش عالی گناباد | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۵ | مجتمع آموزش عالی بم | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۶ | دانشگاه نیشابور | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۷ | مرکز آموزش عالی اقلید | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۸ | مرکز آموزش عالی کاشمر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۶۹ | دانشگاه سید جمال الدین اسدآبادی | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۷۰ | دانشگاه علم و صنعت ایران | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۷۱ | دانشگاه صنعتی شریف | unresolved | unresolved | unresolved | support | unresolved | unresolved | support |
| ۷۲ | دانشگاه صنعتی امیرکبیر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۷۳ | دانشگاه صنعتی خواجه نصیرالدین طوسی | unresolved | unresolved | support | support | unresolved | unresolved | support |
| ۷۴ | دانشگاه صنعتی اصفهان | direct | unresolved | unresolved | direct | unresolved | direct | direct |
| ۷۵ | دانشگاه صنعتی شاهرود | direct | unresolved | support | direct | support | unresolved | direct |
| ۷۶ | دانشگاه صنعتی نوشیروانی بابل | support | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۷۷ | دانشگاه صنعتی سهند | unresolved | unresolved | unresolved | support | unresolved | unresolved | unresolved |
| ۷۸ | دانشگاه صنعتی شیراز | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۷۹ | دانشگاه تحصیلات تکمیلی صنعتی و فناوری پیشرفته کرمان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۰ | دانشگاه صنعتی ارومیه | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۱ | دانشگاه صنعتی قوچان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۲ | دانشگاه صنعتی اراک | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۳ | دانشگاه صنعتی کرمانشاه | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۴ | دانشگاه صنعتی قم | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | support |
| ۸۵ | دانشگاه صنعتی جندی شاپور دزفول | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۶ | دانشگاه صنعتی همدان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۷ | دانشگاه صنعتی خاتم الانبیاء بهبهان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۸ | دانشگاه صنعتی سیرجان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۸۹ | دانشگاه علم و فناوری مازندران (بهشهر) | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۰ | مجتمع آموزش عالی فنی و مهندسی اسفراین | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۱ | دانشگاه صنعتی بیرجند | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۲ | مرکز آموزش عالی فنی و مهندسی بوئین زهرا | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۳ | مرکز آموزش عالی محلات | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۴ | دانشگاه علوم کشاورزی و منابع طبیعی گرگان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۵ | دانشگاه علوم کشاورزی و منابع طبیعی ساری | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۶ | دانشگاه علوم کشاورزی و منابع طبیعی خوزستان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | support |
| ۹۷ | دانشکده کشاورزی و دامپروری تربت جام | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۹۸ | دانشگاه هنر ایران | direct | unresolved | unresolved | direct | unresolved | unresolved | unresolved |
| ۹۹ | دانشگاه هنر اسلامی تبریز | support | unresolved | unresolved | support | unresolved | unresolved | support |
| ۱۰۰ | دانشگاه هنر اصفهان | support | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۱ | دانشگاه هنر شیراز | support | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۲ | دانشگاه پیام نور | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۳ | دانشگاه ملی مهارت | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۴ | دانشگاه فرهنگیان | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۵ | دانشگاه جامع علمی کاربردی | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۶ | دانشگاه جامع امام حسین (ع) | support | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۷ | دانشگاه شاهد | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۸ | دانشگاه صنعتی مالک اشتر | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۰۹ | دانشگاه تربیت دبیر شهید رجایی | direct | unresolved | unresolved | direct | unresolved | unresolved | direct |
| ۱۱۰ | دانشگاه فرماندهی و ستاد آجا (دافوس) | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۱۱ | دانشگاه عالی دفاع ملی | unresolved | unresolved | unresolved | unresolved | support | support | unresolved |
| ۱۱۲ | دانشگاه علوم انتظامی امین | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۱۳ | دانشگاه صنعت نفت | unresolved | unresolved | unresolved | direct | unresolved | unresolved | direct |
| ۱۱۴ | دانشگاه صدا و سیمای جمهوری اسلامی ایران | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |
| ۱۱۵ | مرکز آموزش عالی هوانوردی و فرودگاهی کشور | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved | unresolved |

## Exact inspected-page inventory

> Each entry records the exact first-party URL, retrieval state, scope, dimension tags, and controlled document type/topic when applicable.

### ۱. دانشگاه تهران (`tehran`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.ut.ac.ir/fa](https://research.ut.ac.ir/fa).
- Official base domain: `ut.ac.ir`.
- [قوانین و فرم‌ها - معاونت پژوهش و فناوری- فارسی - دانشگاه تهران](https://research.ut.ac.ir/fa/page/8922/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%88-%D9%81%D8%B1%D9%85-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه و فرم و فرآیندها - اداره امور پژوهش و ارتباط با صنعت و جامعه](https://canres.ut.ac.ir/%D8%A7%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%88-%D9%81%D8%B1%D9%85-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرصت-مطالعاتی-دانشجویان - science - دانشکدگان علوم](https://science.ut.ac.ir/fmd) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جشنواره پژوهش و فناوری - معاونت پژوهش و فناوری- فارسی](https://research.ut.ac.ir/fa/page/9028) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کمیته-اخلاق-در-پژوهش-های-زیست-پزشکی - دانشکدگان علوم](https://science.ut.ac.ir/rec) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ها و مقررات - ece - دانشکده مهندسی برق و کامپیوتر](https://ece.ut.ac.ir/%D8%A7%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D9%85%D9%82%D8%B1%D8%B1%D8%A7%D8%AA) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت پژوهش و فناوری- فارسی - دانشگاه تهران](https://research.ut.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌های اعضای هیات علمی - معاونت پژوهشی دانشکدگان فنی](https://engresearch.ut.ac.ir/fa/page/1724/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7%DB%8C-%D8%A7%D8%B9%D8%B6%D8%A7%DB%8C-%D9%87%DB%8C%D8%A7%D8%AA-%D8%B9%D9%84%D9%85%DB%8C) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اعتبار ویژه (گرنت) - معاونت پژوهش و فناوری- فارسی](https://research.ut.ac.ir/fa/page/9024/%D8%A7%D8%B9%D8%AA%D8%A8%D8%A7%D8%B1-%D9%88%DB%8C%DA%98%D9%87-%DA%AF%D8%B1%D9%86%D8%AA-) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پژوهش‌های بنیادی - معاونت پژوهش و فناوری- فارسی - دانشگاه تهران](https://research.ut.ac.ir/fa/page/9035/%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%87%D8%A7%DB%8C-%D8%A8%D9%86%DB%8C%D8%A7%D8%AF%DB%8C) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲. دانشگاه تربیت مدرس (`tarbiat-modares`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://res.modares.ac.ir/](https://res.modares.ac.ir/).
- Official base domain: `modares.ac.ir`.
- [معاونت پژوهشی و فناوری - فرم‌ها](https://res.modares.ac.ir/res/forms) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`form/template` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کاشت نهال میوه به مناسبت چهلمین سالگرد تأسیس دانشگاه](https://stu.modares.ac.ir/uploads/News.Newsletters.16772.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Untitled - معاونت آموزشی - دانشگاه تربیت مدرس](https://edu.modares.ac.ir/uploads/Res.Rm.Oth.9.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تاکید بر نقش آفرینی دانشگاه تربیت مدرس در تدوین برنامه های ...](https://news.modares.ac.ir/uploads/4/2025/Nov/22/News.Newsletters.3649_1.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تولید و نصب غالفکامپوزیتی پیش ساخته جهت تعمیرات خطوط ...](https://res.modares.ac.ir/uploads/News.Newsletters.17565.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مجموعه برنامه پنج ساله پنجم توسعه جمهوري اسلامی ایران](https://cls.modares.ac.ir/uploads/Adm.Fbo.Rar.14.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [5 درخشش دانشگاه تربیت مدرس در میان دانشگاه های ... - معاونت آموزشی](https://mrc.modares.ac.ir/uploads/News.Newsletters.21416.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ماهنامه خبری 3 6 - معاونت آموزشی - دانشگاه تربیت مدرس](https://edu.modares.ac.ir/uploads/News.Newsletters.25060.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هفت عضو هیات علمی دانشگاه تربیت مدرس در میان سرآمدان ...](https://en-tmuit.modares.ac.ir/uploads/News.Newsletters.18108.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳. دانشگاه فردوسی مشهد (`ferdowsi`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://vpr.um.ac.ir/](https://vpr.um.ac.ir/).
- Official base domain: `um.ac.ir`.
- [اطلاعیه فوری آموزشی - دانشکده دامپزشکی - دانشگاه فردوسی مشهد](https://vet.um.ac.ir/index.php/fa/2016-05-01-06-55-48/1948-2023-11-07-04-07-35) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پرسش های متداول - صفحه اصلی - دانشگاه فردوسی مشهد](https://sshi.um.ac.ir/index.php/en/site-map?id=1588) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [درباره ما - صفحه اصلی - دانشگاه فردوسی مشهد](https://eng2.um.ac.ir/index.php/fa/2014-08-19-04-38-57) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مبارك باد...](https://vpr.um.ac.ir/images/32/stories/moavenat/etelaiyeha/24atf.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سومین کارگاه ریاضی در دانشکده ... - دانشکده ریاضی دانشگاه فردوسی مشهد](https://mathsci.um.ac.ir/index.php/fa/newsmathstat/1266-2015-12-20-07-24-31) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [خبرانهم آموزش عالی - دانشکده علوم تربیتی و روانشناسی - دانشگاه ...](https://epl.um.ac.ir/images/76/News/Doc/Khabarname.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه درسي - معاونت آموزشی - دانشگاه فردوسی مشهد](https://vpap.um.ac.ir/images/34/sfm/barnamedarsi/mecanic_biosistem.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [A Phenomenological Anal- ysis of the Semnan Water Market](https://jm.um.ac.ir/article_46500_38133c4c5bf577531ee2b1c66261c72f.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۴. دانشگاه شهید بهشتی (`shahid-beheshti`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://resevp.sbu.ac.ir/](https://resevp.sbu.ac.ir/).
- Official base domain: `sbu.ac.ir`.
- [انتشارات دانشگاه شهید بهشتی](https://press.sbu.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=کتابخانه/اسناد; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [چارچوب معماری سازمانی ایران](https://soea.sbu.ac.ir/wp-content/uploads/2024/03/IEAF_FM_V1.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سری جدید نسخه الکترونیکی](https://saad.sbu.ac.ir/article_103032_496073b831115506842000c964864fea.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Untitled - نشریات دانشجویی - دانشگاه شهید بهشتی](https://journalsstu.sbu.ac.ir/wp-content/uploads/Archive/03/37.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سرمقاله - نشریات دانشجویی](https://journalsstu.sbu.ac.ir/wp-content/uploads/Archive/03/40.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تاثیر آموزش گروهی خودارزشمندی مبتنی بر رویکرد ...](https://familycong.fri.sbu.ac.ir/files_site/files/r_15_250524212823.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [علی وفایی خسروشاهی](https://journalsstu.sbu.ac.ir/wp-content/uploads/Archive/26/2.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۵. دانشگاه شیراز (`shiraz`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.shirazu.ac.ir/](https://research.shirazu.ac.ir/).
- Official base domain: `shirazu.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۶. دانشگاه تبریز (`tabriz`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.tabrizu.ac.ir/](https://research.tabrizu.ac.ir/).
- Official base domain: `tabrizu.ac.ir`.
- [https://tabrizu.ac.ir/fa/page/8201/فرم-ها-و-آیین-ن...](https://tabrizu.ac.ir/fa/page/8201/%D9%81%D8%B1%D9%85-%D9%87%D8%A7-%D9%88-%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Untitled - نشریه مطالعات دانش پژوهی](https://jkrs.tabrizu.ac.ir/article_14179_749d68e4dab90e3ca7e312e21559e850.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷. دانشگاه اصفهان (`isfahan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.ui.ac.ir/](https://research.ui.ac.ir/).
- Official base domain: `ui.ac.ir`.
- [دانشکده علوم و فناوری های زیستی — خانه](https://bio.ui.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده فنی و مهندسی](https://uiold.ui.ac.ir/Index.aspx?PageId=16137&PageIdF=0&isPopUp=False&lang=1&order=list&page_=sitesap&sub=11&tempname=Engineering) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [راهـنمای جـامع دانشـگاه اصفـهان](https://tmk.ui.ac.ir/Dorsapax/userfiles/Sub0/Rahnema98.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پیــــام دانـشــگاه - دانشکده فنی و مهندسی - دانشگاه اصفهان](https://eng.ui.ac.ir/dorsapax/Data/Sub_36/File/1_9878011224.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [شیو ۀ نگارش پایان نام ۀ کارشناسی ارشد و رسال ۀ دکتری](https://library.ui.ac.ir/uploads/117/2025/Feb/05/%D8%B4%DB%8C%D9%88%D9%87%20%D9%86%DA%AF%D8%A7%D8%B1%D8%B4%20%D9%88%DB%8C%D8%B1%D8%A7%DB%8C%D8%B4%20%D8%B4%D8%AF%D9%87%20%D8%AF%DB%8C%20%D9%85%D8%A7%D9%87%201403docx.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مشخصات کلی برنامه و سرفصل دروس عمران ی مهندس کارشناسی](https://academics.ui.ac.ir/uploads/12/2024/Dec/01/BSc_CivilEngineering.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پیــــام دانـشــگاه - روابط عمومی - دانشگاه اصفهان](https://pr.ui.ac.ir/uploads/167/2025/Oct/01/tir1402.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آمار](https://academics.ui.ac.ir/uploads/12/2025/Oct/22/BS_Statistics_new.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فـــهـرســـت](https://ala.ui.ac.ir/fa/wp-content/uploads/2019/05/4.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۸. دانشگاه رازی (`razi`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://are.razi.ac.ir/](https://are.razi.ac.ir/).
- Official base domain: `razi.ac.ir`.
- [کارگاه های علمی - معاونت پژوهشی و فناوری](https://are.razi.ac.ir/%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D9%87%D8%A7%DB%8C-%D8%B9%D9%84%D9%85%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اخبار - گروه کارآفرینی و ارتباط با صنعت - دانشگاه رازی](https://relation.razi.ac.ir/en/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1?category=2283085&category=8458124&category=893707&category=894622&delta=40) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه رازی - پرتال اصلی دانشگاه رازی](https://razi.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اخبار - گروه کارآفرینی و ارتباط با صنعت - دانشگاه رازی](https://relation.razi.ac.ir/en/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1?category=893622&category=894618&category=894622&delta=60) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اجرای تدریجی و ترکیبی، کلید کاهش مقاومت‌های ساختاری و ...](https://razi.ac.ir/fa/w/%D8%A7%D8%AC%D8%B1%D8%A7%DB%8C-%D8%AA%D8%AF%D8%B1%DB%8C%D8%AC%DB%8C-%D9%88-%D8%AA%D8%B1%DA%A9%DB%8C%D8%A8%DB%8C%D8%8C-%DA%A9%D9%84%DB%8C%D8%AF-%DA%A9%D8%A7%D9%87%D8%B4-%D9%85%D9%82%D8%A7%D9%88%D9%85%D8%AA%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%B3%D8%A7%D8%AE) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [محمود مرادی - profile - دانشکده علوم اجتماعی](https://soc.razi.ac.ir/~mahmoudmoradi/group-two) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کیومرث سهیلی](https://razi.ac.ir/~ksohaili/group-two) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اخبار - پرتال اصلی دانشگاه رازی](https://razi.ac.ir/web/razi/news?delta=60&sort=createDate-&start=13) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دروس ارائه شده نیمسال جاری](https://razi.ac.ir/~ghrhaidari/group-two) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [محسن زاهدی - دانشکده فنی - دانشگاه رازی](https://eng.razi.ac.ir/~zahedi/group-two) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۹. دانشگاه تحصیلات تکمیلی علوم پایه زنجان (`iasbs`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `iasbs.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۱۰. دانشگاه خوارزمی (`kharazmi`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.khu.ac.ir/](https://research.khu.ac.ir/).
- Official base domain: `khu.ac.ir`.
- [خدمات ویژه اعضای هیات علمی-آیین نامه ها - دانشگاه خوارزمی](https://eng.khu.ac.ir/page/25910/%D8%AE%D8%AF%D9%85%D8%A7%D8%AA-%D9%88%DB%8C%DA%98%D9%87-%D8%A7%D8%B9%D8%B6%D8%A7%DB%8C-%D9%87%DB%8C%D8%A7%D8%AA-%D8%B9%D9%84%D9%85%DB%8C-%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه راهبردی آزمایشگاه در سال 1400](https://khu.ac.ir/page/26205/%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87-%D8%B1%D8%A7%D9%87%D8%A8%D8%B1%D8%AF%DB%8C-%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D8%AF%D8%B1-%D8%B3%D8%A7%D9%84-1400) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=آزمایشگاه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فعالیتهای پژوهشی و فناورانه](https://khu.ac.ir/find-35.26615.62321.fa.html) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ورود یا ثبت نام](https://khu.ac.ir/sitemap.php) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آزمایشگاه مرکزی - دانشگاه خوارزمی](https://lab.khu.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=آزمایشگاه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گزارش عملکرد دانشگاه خوارزمی 1400](https://mec.khu.ac.ir/files/site91/files/%DA%AF%D8%B2%D8%A7%D8%B1%D8%B4%2B%D8%B9%D9%85%D9%84%DA%A9%D8%B1%D8%AF%2B1400_188838.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برگزاری آیین بزرگداشت هفته پژوهش و تجلیل از پژوهشگران ...](https://khu.ac.ir/content/73626/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`document-index/page` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [خدمات ویژه اعضای هیات علمی-آیین نامه ها](https://hss.khu.ac.ir/page/25910/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده علوم مالی - دانشگاه خوارزمی](https://fs.khu.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گزارش مسئولیت و مشارکت اجتماعی دانشگاه خوارزمی](https://khu.ac.ir/content/62238/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۱. دانشگاه علامه طباطبایی (`allameh`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.atu.ac.ir/fa](https://research.atu.ac.ir/fa).
- Official base domain: `atu.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۱۲. دانشگاه شهید باهنر کرمان (`shahid-bahonar-kerman`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://research.uk.ac.ir/%D8%A2%D9%88%D9%86-%D8%AA%D8%AD%D8%AA-%D8%AE%D9%84%D8%A3](https://research.uk.ac.ir/%D8%A2%D9%88%D9%86-%D8%AA%D8%AD%D8%AA-%D8%AE%D9%84%D8%A3).
- Official base domain: `uk.ac.ir`.
- [طرح توسعه دانشکده کشاورزی دانشگاه با حضور وزیر علوم](https://uk.ac.ir/complaint_kuma/%D8%B7%D8%B1%D8%AD-%D8%AA%D9%88%D8%B3%D8%B9%D9%87-%D8%AF%D8%A7%D9%86%D8%B4%DA%A9%D8%AF%D9%87-%DA%A9%D8%B4%D8%A7%D9%88%D8%B1%D8%B2%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%A8%D8%A7-%D8%AD%D8%B6%D9%88%D8%B1-%D9%88%D8%B2%DB%8C%D8%B1-%D8%B9%D9%84%D9%88%D9%85%D8%8C-%D8%AA%D8%AD%D9%82%DB%8C%D9%82%D8%A7%D8%AA-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D8%A8%D9%87-%D8%A8%D9%87%D8%B1%D9%87-%D8%A8%D8%B1%D8%AF%D8%A7%D8%B1%DB%8C-%D8%B1%D8%B3%DB%8C%D8%AF) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آون تحت خلأ - معاونت پژوهشی و فناوری](https://research.uk.ac.ir/%D8%A2%D9%88%D9%86-%D8%AA%D8%AD%D8%AA-%D8%AE%D9%84%D8%A3) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اولین شماره نشریه الکترونیک انجمن علمی علوم و مهندسی صنایع غذایی](https://psaba.uk.ac.ir/wp-content/uploads/2021/10/%D8%B3%DB%8C%D8%A8-%D8%B3%D8%A8%D8%B2-1.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۳. دانشگاه گیلان (`guilan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://resvp.guilan.ac.ir/](https://resvp.guilan.ac.ir/).
- Official base domain: `guilan.ac.ir`.
- [پايان نامه ها و رساله هاي تحصيلات تکميلي - دانشکده علوم پایه](https://sci.guilan.ac.ir/fa/w/%D8%A2%D8%A6%D9%8A%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D8%AB%D8%A8%D8%AA-%D9%BE%D9%8A%D8%B4%D9%86%D9%87%D8%A7%D8%AF%D9%87%D8%A7%D8%8C-%D9%BE%D8%A7%D9%8A%D8%A7%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%B1%D8%B3%D8%A7%D9%84%D9%87-%D9%87%D8%A7%D9%8A?p_l_back_url=%2Fsearch%3Fdelta%3D60%26category%3D3178518) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [قوانین و آئین نامه ها - معاونت فرهنگی و اجتماعی - دانشگاه گیلان](https://farhangi.guilan.ac.ir/instructions) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فراخوان کار دانشجویی (بهار 1404) - دفتر ریاست و روابط عمومی](https://pr.guilan.ac.ir/en/w/%D9%81%D8%B1%D8%A7%D8%AE%D9%88%D8%A7%D9%86-%DA%A9%D8%A7%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%D8%AC%D9%88%DB%8C%DB%8C?redirect=%2Fen%2F) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارگاه آموزشی نحوه گزارش‌گیری از سامانه جامع آموزشی](https://education.guilan.ac.ir/fa/w/%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D9%86%D8%AD%D9%88%D9%87-%DA%AF%D8%B2%D8%A7%D8%B1%D8%B4%E2%80%8C%DA%AF%DB%8C%D8%B1%DB%8C-%D8%A7%D8%B2-%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87-%D8%AC%D8%A7%D9%85%D8%B9-%D8%A2%D9%85?redirect=%2Ffa%2Fw%2F%25D8%25A8%25D9%2588%25D8%25B1%25D8%25B3-%25D8%25AA%25D8%25AD%25D8%25B5%25DB%258C%25D9%2584%25DB%258C-%25DA%25A9%25D8%25B4%25D9%2588%25D8%25B1-%25DA%25A9%25D9%2588%25DB%258C%25D8%25AA-%25D8%25AF%25D8%25A7%25D9%2586%25D8%25B4%25DA%25AF%25D8%25A7%25D9%2587-%25DA%25A9%25D9%2588%25DB%258C%25D8%25AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارگاه بازخوانی دستورالعمل داوری نشریات دانشجویی ـ 21 آبان ماه ...](https://soea.guilan.ac.ir/en/web/farhangi/w/%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D8%A8%D8%A7%D8%B2%D8%AE%D9%88%D8%A7%D9%86%DB%8C-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D8%AF%D8%A7%D9%88%D8%B1%DB%8C-%D9%86%D8%B4%D8%B1%DB%8C%D8%A7%D8%AA-%D8%AF%D8%A7%D9%86%D8%B4%D8%AC%D9%88-3?p_l_back_url=%2Fen%2Fnews%3Fcategory%3D3178834%26category%3D3177776%26delta%3D60%26start%3D139) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`procedure/guideline` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مروری بر آنچه که در سال 1397 در دانشگاه گیلان گذشت - کتابخانه و نشر](https://library.guilan.ac.ir/fa/web/guilan/w/%D9%85%D8%B1%D9%88%D8%B1%DB%8C-%D8%A8%D8%B1-%D8%A2%D9%86%DA%86%D9%87-%DA%A9%D9%87-%D8%AF%D8%B1-%D8%B3%D8%A7%D9%84-1397-%D8%AF%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%DB%8C%D9%84%D8%A7%D9%86-%DA%AF%D8%B0%D8%B4%D8%AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=کتابخانه/اسناد; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سامانه کمیته اخلاق در پژوهش های زیست پزشکی دانشگاه گیلان](https://ethics.guilan.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۴. دانشگاه ارومیه (`urmia`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `urmia.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۱۵. دانشگاه سمنان (`semnan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.semnan.ac.ir/](https://research.semnan.ac.ir/).
- Official base domain: `semnan.ac.ir`.
- [دانشگاه سمنان: Semnan University](https://semnan.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پارک علم و فناوری دانشگاه سمنان](https://sustp.semnan.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پایگاه خبری دانشگاه سمنان](https://semnan.ac.ir/news) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هسته های فناور](https://sustp.semnan.ac.ir/PishRoshd) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بازدید اعضای هیات علمی دانشگاه سمنان از شرکت تولیدی ...](https://semnan.ac.ir/%D9%87%D9%85%D9%87-%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D8%A7%D8%B9%D8%B6%D8%A7%DB%8C-%D9%87%DB%8C%D8%A7%D8%AA-%D8%B9%D9%84%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%B3%D9%85%D9%86%D8%A7%D9%86-%D8%A7%D8%B2-%D8%B4%D8%B1%DA%A9%D8%AA-%D8%AA%D9%88%D9%84%DB%8C%D8%AF%DB%8C-%D8%B4%DB%8C%D9%85%DB%8C%D8%A7%DB%8C%DB%8C-%DA%A9%D9%84%D8%B1%D8%A7%D9%86) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [وبینار معرفی کمک هزینه تحقیق و توسعه صندوق نوآوری و ...](https://sustp.semnan.ac.ir/fanavarsho/%D9%88%D8%A8%DB%8C%D9%86%D8%A7%D8%B1-%D9%85%D8%B9%D8%B1%D9%81%DB%8C-%DA%A9%D9%85%DA%A9-%D9%87%D8%B2%DB%8C%D9%86%D9%87-%D8%AA%D8%AD%D9%82%DB%8C%D9%82-%D9%88-%D8%AA%D9%88%D8%B3%D8%B9%D9%87-%D8%B5%D9%86%D8%AF%D9%88%D9%82-%D9%86%D9%88%D8%A2%D9%88%D8%B1%DB%8C-%D9%88-%D8%B4%DA%A9%D9%88%D9%81%D8%A7%DB%8C%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه راهبردی و عملیاتی دانشگاه - معاونت برنامه ریزی و توسعه منابع ...](https://economic.semnan.ac.ir/uploads/47/%D8%AF%D9%88%D9%85%DB%8C%D9%86%20%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87%20%D8%B1%D8%A7%D9%87%D8%A8%D8%B1%D8%AF%DB%8C.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۶. دانشگاه سیستان و بلوچستان (`sistan-baluchestan`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B1%DA%A9%D8%B2-%DA%A9%D8%B1%D8%B3%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D8%B8%D8%B1%DB%8C%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B1%DA%A9%D8%B2-%DA%A9%D8%B1%D8%B3%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D8%B8%D8%B1%DB%8C%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7).
- Official base domain: `usb.ac.ir`.
- [فرم ها](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B1%DA%A9%D8%B2-%DA%A9%D8%B1%D8%B3%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D8%B8%D8%B1%DB%8C%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`form/template` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ها و دستورالعمل ها](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B1%DA%A9%D8%B2-%DA%A9%D8%B1%D8%B3%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D8%B8%D8%B1%DB%8C%D9%87-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%DB%8C/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آئین نامه ها و دستورالعمل ها](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA/-%D8%A2%D8%A6%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`procedure/guideline` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم ها](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%BE%D8%B3%D8%A7-%D8%AF%DA%A9%D8%AA%D8%B1%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`form/template` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ها و شیوه نامه ها](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D8%A7%D8%AF%D8%A7%D8%B1%D9%87-%D9%86%D8%B4%D8%B1%DB%8C%D8%A7%D8%AA/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%B4%DB%8C%D9%88%D9%87-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اخبار ارتباط با صنعت](https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA/%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۷. دانشگاه یزد (`yazd`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://yazd.ac.ir/offices/research/home/introduction](https://yazd.ac.ir/offices/research/home/introduction).
- Official base domain: `yazd.ac.ir`.
- [قوانین و آیین‌نامه‌ها](https://yazd.ac.ir/offices/research/home/rules) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه یزد - قوانین و آیین‌نامه‌ها](https://yazd.ac.ir/president/administration/evaluation/home/rules) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ترفیع](https://yazd.ac.ir/offices/educational/other/promotion) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [قوانین نگارش پایان‌نامه](https://yazd.ac.ir/offices/educational/deputy/graduate/information/thesis) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌ها و دستورالعمل‌ها](https://yazd.ac.ir/cultural/home/rules) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارآموزی](https://yazd.ac.ir/offices/research/deputy/entrepreneurship/internship) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم برنامه جامع پنج ساله اساتید](https://yazd.ac.ir/Page.aspx?Page=eForms%2FeFormView&frmId=477&ft=0&mID=14439) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=اسناد/فرم‌ها; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [موافقت شورای دانشگاه یزد با راه‌اندازی ۶ رشته گرایش جدید](https://yazd.ac.ir/4006-5-9174) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۸. دانشگاه محقق اردبیلی (`mohaghegh-ardabili`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://uma.ac.ir/find-8.270.2596.fa.html](https://uma.ac.ir/find-8.270.2596.fa.html).
- Official base domain: `uma.ac.ir`.
- [Analysis of structural factors affecting the implementation of ...](https://journal.uma.ac.ir/article_4130_abd95fdf87e79405bd1d212938fbf1f7.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پژوهش های جغرافیایی-برنامه ریزی](https://uma.ac.ir/files/publications/files/nashriat/%D8%B9%D9%84%D9%88%D9%85_%D8%A7%D8%AC%D8%AA%D9%85%D8%A7%D8%B9%DB%8C/%D9%BE%DA%98%D9%88%D9%87%D8%B4_%D9%87%D8%A7%DB%8C_%D8%AC%D8%BA%D8%B1%D8%A7%D9%81%DB%8C%D8%A7%DB%8C%DB%8C-%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87_%D8%B1%DB%8C%D8%B2%DB%8C/PAGUOHESH_HAYE_JOGRAFIYA%282%29.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۹. دانشگاه کردستان (`kurdistan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://uok.ac.ir/web/research-and-innovation](https://uok.ac.ir/web/research-and-innovation).
- Official base domain: `uok.ac.ir`.
- [فرم‌ها و آیین‌نامه‌ها - معاونت پژوهشی و نوآوری](https://uok.ac.ir/web/research-and-innovation/research-forms-regulations/-/document_library/nqsj/view/436481) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت پژوهش و فناوری - مرکز محاسبات سریع - دانشگاه کردستان](https://hpc.uok.ac.ir/jirocms/files/upload/websites/uok/vicechancelleries/vcresearch/%21report/1397.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جمال سلیمی](https://uok.ac.ir/~j.salimi/thesis) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [( 1390 ـ 1394 ) ﻣﺘﻦ ﮐﺎﻣﻞ ﻗﺎﻧﻮن ﺑﺮﻧﺎﻣﻪ ﭘﻨﺠﺴﺎﻟﻪ ﭘﻨﺠﻢ ﺗﻮﺳﻌﻪ ﺟ](https://uok.ac.ir/documents/2936244/4312423/%D9%85%D8%AA%D9%86-%DA%A9%D8%A7%D9%85%D9%84-%D9%82%D8%A7%D9%86%D9%88%D9%86-%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87-%D9%BE%D9%86%D8%AC%D8%B3%D8%A7%D9%84%D9%87-%D9%BE%D9%86%D8%AC%D9%85-%D8%AA%D9%88%D8%B3%D8%B9%D9%87-%D8%AC%D9%85%D9%87%D9%88%D8%B1%DB%8C-%D8%A7%D8%B3%D9%84%D8%A7%D9%85%DB%8C-%D8%A7%DB%8C%D8%B1%D8%A7%D9%86-1390-1394.pdf/b3c7a320-7df3-cd04-0f67-ac18b4fb00bc?download=true&t=1699770856351) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`law/resolution` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Untitled - مرکز محاسبات سریع](https://hpc.uok.ac.ir/jirocms/files/upload/websites/uok/vicechancelleries/vcresearch/%21report/1399.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بررسی قابلیت تحقق جرائم علیه شخصیت معنوی ...](https://libapp.uok.ac.ir/multiMediaFile/170447929-4-1.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۰. دانشگاه شهید چمران اهواز (`shahid-chamran-ahvaz`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.scu.ac.ir/](https://research.scu.ac.ir/).
- Official base domain: `scu.ac.ir`.
- [ویژه نامه هفته ی پژوهش و فناوری](https://gnrc.scu.ac.ir/documents/178527/1080176/%D9%88%DB%8C%DA%98%D9%87%20%D9%86%D8%A7%D9%85%D9%87%20%D9%87%D9%81%D8%AA%D9%87%20%D9%BE%DA%98%D9%88%D9%87%D8%B4%201399.pdf?t=1608970962516&version=1.0) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آزمایشگاه های بخش میکروب شناسی - دانشکده دامپزشکی](https://oldveterinary.scu.ac.ir/-/%D8%A7%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7%DB%8C-%D8%A8%D8%AE%D8%B4-%D9%85%DB%8C%DA%A9%D8%B1%D9%88%D8%A8-%D8%B4%D9%86%D8%A7%D8%B3%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=آزمایشگاه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده دامپزشکی - دانشگاه شهید چمران اهواز](https://veterinary.scu.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [لیست کتابهای لاتین خریداری شده - دانشکده دامپزشکی](https://oldveterinary.scu.ac.ir/-/%D9%84%DB%8C%D8%B3%D8%AA-%DA%A9%D8%AA%D8%A7%D8%A8%D9%87%D8%A7%DB%8C-%D9%84%D8%A7%D8%AA%DB%8C%D9%86-%D8%AE%D8%B1%DB%8C%D8%AF%D8%A7%D8%B1%DB%8C-%D8%B4-2) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تبریک ارتقا سرکار خانم دکتر مریم قادری قهفرخی](https://oldveterinary.scu.ac.ir/-/%D8%AA%D8%A8%D8%B1%DB%8C%DA%A9-%D8%A7%D8%B1%D8%AA%D9%82%D8%A7-%D8%B3%D8%B1%DA%A9%D8%A7%D8%B1-%D8%AE%D8%A7%D9%86%D9%85-%D8%AF%DA%A9%D8%AA%D8%B1-%D9%85%D8%B1%DB%8C%D9%85-%D9%82%D8%A7%D8%AF%D8%B1%DB%8C-%D9%82%D9%87%D9%81%D8%B1%D8%AE%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [در ﺳﻼﻣﺖ ﺗﺤﻮل ﻧﻈﺎم ي ﻫﺎ ﮔﻔﺘﻤﺎن ﺷﻨﺎﺧﺘﯽ ﺟﺎﻣﻌﻪ ﺗﺤﻠﯿﻞ ﺎزد](https://qjsd.scu.ac.ir/article_17451_2a8dd8b3774760c9a4f456b9a30f940b.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اسامي پذیرفته شدگان نهایي آزمون دكتري نيمه متمركز ... - دانشکده مهندسی](https://eng.scu.ac.ir/documents/62103/0/%D9%BE2.pdf/e34269e0-a16e-99e7-2ad6-e5903262c3d1?download=true&t=1724534073160) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۱. دانشگاه کاشان (`kashan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.kashanu.ac.ir/](https://research.kashanu.ac.ir/).
- Official base domain: `kashanu.ac.ir`.
- [آیین‌نامه‌ها و مصوبات- آئین نامه و دستورالعمل هیئت علمی](https://research-affairs.kashanu.ac.ir/fa/regulation/category/134/%D8%A2%D8%A6%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%DB%8C%D8%A6%D8%AA-%D8%B9%D9%84%D9%85%DB%8C?sort=categoryId) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌ها و مصوبات](https://research-affairs.kashanu.ac.ir/fa/regulation?page=1&sort=title) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [شرح وظایف کارکنان - معاونت پژوهشی و ارتباطات علمی](https://research.kashanu.ac.ir/fa/page/3816/%D8%B4%D8%B1%D8%AD-%D9%88%D8%B8%D8%A7%DB%8C%D9%81-%DA%A9%D8%A7%D8%B1%DA%A9%D9%86%D8%A7%D9%86) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [در مسير تحول، نوآوري و پيشرفت دانشگاه كاشان](https://research.kashanu.ac.ir/file/download/news/66e7dbac7c493-.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌ها و مصوبات- اخلاق در پژوهش](https://research-affairs.kashanu.ac.ir/fa/regulation/category/139/%D8%A7%D8%AE%D9%84%D8%A7%D9%82-%D8%AF%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4?sort=approvalDate) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `research ethics`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سامانه ارزیابی نشریات دانشگاه آزاد اسلامی](https://research.kashanu.ac.ir/fa/page/3979/%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87-%D8%A7%D8%B1%D8%B2%DB%8C%D8%A7%D8%A8%DB%8C-%D9%86%D8%B4%D8%B1%DB%8C%D8%A7%D8%AA-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7%DB%8C-%D8%A2%D8%B2%D8%A7%D8%AF-%D8%A7%D8%B3%D9%84%D8%A7%D9%85%DB%8C) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه باید از نزدیک با مشکالت صنعت آشنا شود](https://kashanu.ac.ir/file/download/news/1529403325-21-.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم های مورد نیاز دانشجویان غیرایرانی و انتقالی خارج از کشور](https://intl.kashanu.ac.ir/fa/page/3607/%D9%81%D8%B1%D9%85-%D9%87%D8%A7%DB%8C-%D9%85%D9%88%D8%B1%D8%AF-%D9%86%DB%8C%D8%A7%D8%B2-%D8%AF%D8%A7%D9%86%D8%B4%D8%AC%D9%88%DB%8C%D8%A7%D9%86-%D8%BA%DB%8C%D8%B1%D8%A7%DB%8C%D8%B1%D8%A7%D9%86%DB%8C-%D9%88-%D8%A7%D9%86%D8%AA%D9%82%D8%A7%D9%84%DB%8C-%D8%AE%D8%A7%D8%B1%D8%AC-%D8%A7%D8%B2-%DA%A9%D8%B4%D9%88%D8%B1) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ارتقاي اعضاي هیات علمي بازنگري مي شود](https://kashanu.ac.ir/file/download/news/1520882672-19.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۲. دانشگاه شهرکرد (`shahrekord`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.sku.ac.ir/Vice-President/research](https://www.sku.ac.ir/Vice-President/research).
- Official base domain: `sku.ac.ir`.
- [معاونت پژوهش و فناوري](https://sku.ac.ir/File/32440/) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هـای صنعتـی برگـزیده طـرح های کشور ها و پژوهشگاه ...](https://sku.ac.ir/File/33547/%D8%AF%D8%A7%D9%86%D9%84%D9%88%D8%AF-%DA%A9%D8%AA%D8%A7%D8%A8-%D8%B7%D8%B1%D8%AD-%D9%87%D8%A7%D9%8A-%D8%A8%D8%B1%DA%AF%D8%B2%D9%8A%D8%AF%D9%87-%D8%B5%D9%86%D8%B9%D8%AA%D9%8A) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`document-index/page` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۳. دانشگاه بوعلی سینا (`bu-ali-sina`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://res.basu.ac.ir/](https://res.basu.ac.ir/).
- Official base domain: `basu.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۲۴. دانشگاه قم (`qom`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.qom.ac.ir/](https://research.qom.ac.ir/).
- Official base domain: `qom.ac.ir`.
- [دانشگاه قم - صفحه اصلی](https://qom.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [راهنمای جامع خدمات دانشگاهی دانشگاه قم](https://qom.ac.ir/uploads/24/ServiceHelp_UniQom.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`procedure/guideline` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دیدار و گفت و گو معاون و مدیران پژوهش و فناوری دانشگاه قم با ...](https://qom.ac.ir/%D8%A7%D8%B1%D8%B4%DB%8C%D9%88%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D8%AF%DB%8C%D8%AF%D8%A7%D8%B1-%D9%88-%DA%AF%D9%81%D8%AA-%D9%88-%DA%AF%D9%88-%D9%85%D8%B9%D8%A7%D9%88%D9%86-%D9%88-%D9%85%D8%AF%DB%8C%D8%B1%D8%A7%D9%86-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%82%D9%85-%D8%A8%D8%A7-%D9%85%D8%B9%D8%A7%D9%88%D9%86-%D9%88-%D9%85%D8%AF%DB%8C%D8%B1%D8%A7%D9%86-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88%D8%B2%D8%A7%D8%B1%D8%AA-%D8%B9%D9%84%D9%88%D9%85-) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [چارت سازمانی](https://qom.ac.ir/%DA%86%D8%A7%D8%B1%D8%AA-%D8%B3%D8%A7%D8%B2%D9%85%D8%A7%D9%86%DB%8C) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه قم - آرشیو دستاوردها](https://qom.ac.ir/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%AF%D8%B3%D8%AA%D8%A7%D9%88%D8%B1%D8%AF%D9%87%D8%A7) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه قم را سرمایه ملی یم دامن](https://qom.ac.ir/uploads/24/2024/Mar/27/%D9%86%D8%B4%D8%B1%DB%8C%D9%87%20%D8%AE%D8%A8%D8%B1%DB%8C%20%D8%AA%D8%A7%D8%A8%D8%B3%D8%AA%D8%A7%D9%86%201401%20-%20%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87%20%D9%82%D9%85.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [افتخار آفرینی دانشگاه قم در توسعه دوره های مهارت افزایی ...](https://qom.ac.ir/%D8%A7%D8%B1%D8%B4%DB%8C%D9%88%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D8%A7%D9%81%D8%AA%D8%AE%D8%A7%D8%B1-%D8%A2%D9%81%D8%B1%DB%8C%D9%86%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%82%D9%85-%D8%AF%D8%B1-%D8%AA%D9%88%D8%B3%D8%B9%D9%87-%D8%AF%D9%88%D8%B1%D9%87-%D9%87%D8%A7%DB%8C-%D9%85%D9%87%D8%A7%D8%B1%D8%AA-%D8%A7%D9%81%D8%B2%D8%A7%DB%8C%DB%8C-%D8%AF%D8%B1-%D8%A8%DB%8C%D9%86-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7%DB%8C-%DA%A9%D8%B4%D9%88%D8%B1) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پژوهشگران و فناوران برتر دانشگاه قم تجلیل شدند](https://qom.ac.ir/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%AA%D8%A7%D8%A8%D9%84%D9%88%D8%A7%D8%B9%D9%84%D8%A7%D9%86%D8%A7%D8%AA/%D9%BE%DA%98%D9%88%D9%87%D8%B4%DA%AF%D8%B1%D8%A7%D9%86-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%D8%A7%D9%86-%D8%A8%D8%B1%D8%AA%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%82%D9%85-%D8%AA%D8%AC%D9%84%DB%8C%D9%84-%D8%B4%D8%AF%D9%86%D8%AF) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [انتشار اولین مجله گروه شیمی دانشگاه قم در حوزه مواد و انرژی](https://qom.ac.ir/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%AF%D8%B3%D8%AA%D8%A7%D9%88%D8%B1%D8%AF%D9%87%D8%A7/%D8%A7%D9%86%D8%AA%D8%B4%D8%A7%D8%B1-%D8%A7%D9%88%D9%84%DB%8C%D9%86-%D9%85%D8%AC%D9%84%D9%87-%DA%AF%D8%B1%D9%88%D9%87-%D8%B4%DB%8C%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%82%D9%85-%D8%AF%D8%B1-%D8%AD%D9%88%D8%B2%D9%87-%D9%85%D9%88%D8%A7%D8%AF-%D9%88-%D8%A7%D9%86%D8%B1%DA%98%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۵. دانشگاه الزهرا (س) (`alzahra`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.alzahra.ac.ir/](https://research.alzahra.ac.ir/).
- Official base domain: `alzahra.ac.ir`.
- [معاونت پژوهشی و فناوری - دانشگاه الزهرا](https://research.alzahra.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [انتشارات دانشگاه الزهرا(س)](https://book.alzahra.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=کتابخانه/اسناد; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [درباره کتابخانه کوثر - دانشكده ادبيات - دانشکده ادبیات](https://adabiat.alzahra.ac.ir/%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87-%DA%A9%D8%AA%D8%A7%D8%A8%D8%AE%D8%A7%D9%86%D9%87-%DA%A9%D9%88%D8%AB%D8%B1) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=کتابخانه/اسناد; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [الگوی پایان نامه و رساله - دانشكده ادبيات - دانشکده ادبیات](https://adabiat.alzahra.ac.ir/%D8%A7%D9%84%DA%AF%D9%88%DB%8C-%D9%BE%D8%A7%DB%8C%D8%A7%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%88-%D8%B1%D8%B3%D8%A7%D9%84%D9%87) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گردآوری و تدوین : مدیریت خدمات آموزشی ...](https://alzahra.ac.ir/documents/541574/19792046/ketab.pdf/bb14c6c0-2db2-e78c-4c67-981899003970?t=1756283191752) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گروه زبان شناسی - دانشكده ادبيات - دانشکده ادبیات](https://adabiat.alzahra.ac.ir/%DA%AF%D8%B1%D9%88%D9%87-%D8%B2%D8%A8%D8%A7%D9%86-%D8%B4%D9%86%D8%A7%D8%B3%DB%8C1) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برگزاری کارگاه تدوین و طراحی پروپزال صنعتی](https://alzahra.ac.ir/en-GB/web/research/w/%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1%DB%8C-%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D8%AA%D8%AF%D9%88%DB%8C%D9%86-%D9%88-%D8%B7%D8%B1%D8%A7%D8%AD%DB%8C-%D9%BE%D8%B1%D9%88%D9%BE%D8%B2%D8%A7%D9%84-%D8%B5%D9%86%D8%B9%D8%AA%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده علوم ریاضی - دانشگاه الزهرا](https://math.alzahra.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده فیزیک - دانشگاه الزهرا](https://physics.alzahra.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گروه تاریخ - دانشكده ادبيات - دانشکده ادبیات](https://adabiat.alzahra.ac.ir/%DA%AF%D8%B1%D9%88%D9%87-%D8%AA%D8%A7%D8%B1%DB%8C%D8%AE2) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۶. دانشگاه مازندران (`mazandaran`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.umz.ac.ir/](https://research.umz.ac.ir/).
- Official base domain: `umz.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۲۷. دانشگاه بین المللی امام خمینی (ره) (`imam-khomeini-international`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `ikiu.ac.ir`.
- [اولین جلسه شورای آموزش های آزاد برگزار شد](https://ftp.ikiu.ac.ir/en/web/news_portal/news?_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_assetEntryId=4427105&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_mvcPath=%2Fview_content.jsp&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_type=content&p_l_back_url=%2Fen%2Fweb%2Fnews_portal%2Fnews%3Fdelta%3D40%26start%3D24&p_p_id=com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet&p_p_lifecycle=0&p_p_mode=view&p_p_state=maximized) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اخبار - پرتال خبری دانشگاه بین المللی امام خمینی(ره)](https://ftp.ikiu.ac.ir/en/web/news_portal/news?_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_assetEntryId=5715294&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_mvcPath=%2Fview_content.jsp&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_type=content&p_l_back_url=%2Fen%2Fweb%2Fnews_portal%2Fnews%3Fdelta%3D40%26start%3D22&p_p_id=com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet&p_p_lifecycle=0&p_p_mode=view&p_p_state=maximized) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اخبار - پرتال خبری دانشگاه بین المللی امام خمینی(ره)](https://ftp.ikiu.ac.ir/en/web/news_portal/news?_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_assetEntryId=6767734&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_mvcPath=%2Fview_content.jsp&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_type=content&p_l_back_url=%2Fen%2Fweb%2Fnews_portal%2Fnews%3Fdelta%3D40%26start%3D19&p_p_id=com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet&p_p_lifecycle=0&p_p_mode=view&p_p_state=maximized) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [رونمایی از محصول دانش بنیان مرکز رشد دانشگاه در حوزه مدیریت ...](https://ftp.ikiu.ac.ir/en/web/news_portal/news?_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_assetEntryId=5360403&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_mvcPath=%2Fview_content.jsp&_com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet_type=content&p_l_back_url=%2Fen%2Fweb%2Fnews_portal%2Fnews%3Fdelta%3D40%26start%3D23&p_p_id=com_liferay_portal_search_web_search_results_portlet_SearchResultsPortlet&p_p_lifecycle=0&p_p_mode=view&p_p_state=maximized) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۸. دانشگاه خلیج فارس (`persian-gulf`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://pgu.ac.ir/fa/researchdeputy](https://pgu.ac.ir/fa/researchdeputy).
- Official base domain: `pgu.ac.ir`.
- [Azad University Managers Providing A Customer ...](https://asm.pgu.ac.ir/article_704543_61d112a744cbae23e7b3033994fd07c2.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۲۹. دانشگاه زنجان (`zanjan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.znu.ac.ir/](https://research.znu.ac.ir/).
- Official base domain: `znu.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۳۰. دانشگاه ایلام (`ilam`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.ilam.ac.ir/dep/research/](https://www.ilam.ac.ir/dep/research/).
- Official base domain: `ilam.ac.ir`.
- [آيين‌نامه‌ها و دستورالعمل هاي پژوهشي](https://www.ilam.ac.ir/dep/research/page/ihwfsyqzw-%D8%A2%D9%8A%D9%8A%D9%86%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7%D9%8A-%D9%BE%DA%98%D9%88%D9%87%D8%B4%D9%8A) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تجاربوالگوهایموفقدانشگاه ها و پژوهشــگاه های کشــور در ...](https://www.ilam.ac.ir/file_bank/1398/891398223-%DA%A9%D8%AA%D8%A7%D8%A8-%D8%AA%D8%AC%D8%A7%D8%B1%D8%A8-%D9%88-%D8%A7%D9%84%DA%AF%D9%88%D9%87%D8%A7%DB%8C-%D9%85%D9%88%D9%81%D9%82-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`form/template` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پژوهش و فناوری](https://www.ilam.ac.ir/file_bank/1396/913961023-%D8%B9%D8%AA%D9%81-%D8%B4%D9%85%D8%A7%D8%B1%D9%8717.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مجموعه برنامه پنج ساله پنجم توسعه جمهوري اسلامی ایران](https://www.ilam.ac.ir/file_bank/13901020-%D9%85%D8%AC%D9%85%D9%88%D8%B9%D9%87%20%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87%20%D9%BE%D9%86%D8%AC%20%D8%B3%D8%A7%D9%84%D9%87%20%D9%BE%D9%86%D8%AC%D9%85%20%D8%AA%D9%88%D8%B3%D8%B9%D9%87.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۱. دانشگاه حکیم سبزواری (`hakim-sabzevari`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://www.hsu.ac.ir/research/](https://www.hsu.ac.ir/research/).
- Official base domain: `hsu.ac.ir`.
- [آزمایشگاه مرکزی – معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، آزمایشگاه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تجهیزات آزمایشگاهی شیمی – معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/%D8%AA%D8%AC%D9%87%DB%8C%D8%B2%D8%A7%D8%AA-%D8%AF%D8%A7%D9%86%D8%B4%DA%A9%D8%AF%D9%87-%D8%B4%DB%8C%D9%85%DB%8C/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، آزمایشگاه، اسناد/فرم‌ها; document=`regulation/bylaw` / `laboratory`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اطلاع رسانی پژوهشی – معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/researchnotification/) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانلود طرح نامه ها – معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/%D8%AF%D8%A7%D9%86%D9%84%D9%88%D8%AF-%D8%B7%D8%B1%D8%AD-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، اسناد/فرم‌ها; document=`document-index/page` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بودجه، تحول اداری و بهره وری در شش ماهه دوم سال 1404](https://www.hsu.ac.ir/%DA%AF%D8%B2%D8%A7%D8%B1-%D8%B4-%D8%B9%D9%85%D9%84%DA%A9%D8%B1%D8%AF-%D9%85%D8%AF%DB%8C%D8%B1%DB%8C%D8%AA-%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87%D8%8C-%D8%A8%D9%88%D8%AF%D8%AC%D9%87%D8%8C-%D8%AA%D8%AD/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هسته محاسبات سریع حکیم – معاونت پژوهشی و فن آوری](https://www.hsu.ac.ir/research/%D9%85%D8%B1%D8%A7%DA%A9%D8%B2-%D8%AA%D8%AD%D9%82%DB%8C%D9%82%D8%A7%D8%AA%DB%8C-%D8%AD%DA%A9%DB%8C%D9%85/%D9%87%D8%B3%D8%AA%D9%87-%D9%85%D8%AD%D8%A7%D8%B3%D8%A8%D8%A7%D8%AA%DB%8C-%D8%B3%D8%B1%DB%8C%D8%B9-%D8%AD%DA%A9%DB%8C%D9%85/) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دستور العمل های دانشگاه](https://www.hsu.ac.ir/%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87/%D8%AF%D8%B3%D8%AA%D9%88%D8%B1-%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه راهبردی پنج ساله هشتم) 1405](https://www.hsu.ac.ir/nezarat/wp-content/uploads/sites/29/2022/05/%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87-%D8%B1%D8%A7%D9%87%D8%A8%D8%B1%D8%AF%DB%8C-%D9%86%D9%87%D8%A7%DB%8C%DB%8C-%D9%86%D9%87%D8%A7%DB%8C%DB%8C-1405-1.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ﺑﺴﻢ اﷲ اﻟﺮﺣﻤﻦ اﻟﺮﺣﯿﻢ](https://www.hsu.ac.ir/ent-inn/wp-content/uploads/sites/76/2022/04/%D8%B3%D9%88%D8%A7%D9%84%D8%A7%D8%AA_%D9%85%D8%AA%D8%AF%D8%A7%D9%88%D9%84.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۲. دانشگاه اراک (`arak`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.araku.ac.ir/](https://research.araku.ac.ir/).
- Official base domain: `araku.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۳۳. دانشگاه شهید مدنی آذربایجان (`azarbaijan-shahid-madani`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `azaruniv.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۳۴. دانشگاه بیرجند (`birjand`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://birjand.ac.ir/research/fa](https://birjand.ac.ir/research/fa).
- Official base domain: `birjand.ac.ir`.
- [آیین‌نامه‌ها و مصوبات- آیین نامه های پژوهشی](https://birjand.ac.ir/research/fa/regulation/category/150/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7%DB%8C-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین گرامیداشت هفته پژوهش و تجلیل از پژوهشگران نمونه ...](https://birjand.ac.ir/research/fa/news/15967/%D8%A2%DB%8C%DB%8C%D9%86-%DA%AF%D8%B1%D8%A7%D9%85%DB%8C%D8%AF%D8%A7%D8%B4%D8%AA-%D9%87%D9%81%D8%AA%D9%87-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D8%AA%D8%AC%D9%84%DB%8C%D9%84-%D8%A7%D8%B2-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DA%AF%D8%B1%D8%A7%D9%86-%D9%86%D9%85%D9%88%D9%86%D9%87-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%A8%DB%8C%D8%B1%D8%AC%D9%86%D8%AF) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=اسناد/فرم‌ها; document=`document-index/page` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برگزاری نشست معاونان پژوهشی دانشگاه‌ها و مؤسسات آموزش ...](https://www.birjand.ac.ir/fa/news/11605/%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1%DB%8C-%D9%86%D8%B4%D8%B3%D8%AA-%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%A7%D9%86-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7-%D9%88-%D9%85%D8%A4%D8%B3%D8%B3%D8%A7%D8%AA-%D8%A2%D9%85%D9%88%D8%B2%D8%B4-%D8%B9%D8%A7%D9%84%DB%8C-%D8%AE%D8%B1%D8%A7%D8%B3%D8%A7%D9%86-%D8%AC%D9%86%D9%88%D8%A8%DB%8C) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌ها و مصوبات- فرم های پژوهشی](https://birjand.ac.ir/research/fa/regulation/category/58/%D9%81%D8%B1%D9%85-%D9%87%D8%A7%DB%8C-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه بزرگمهر قائنات](https://birjand.ac.ir/gozinesh/fa/page/4790/%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%A8%D8%B2%D8%B1%DA%AF%D9%85%D9%87%D8%B1-%D9%82%D8%A7%D8%A6%D9%86%D8%A7%D8%AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه سمنان: Semnan University](https://birjand.ac.ir/gozinesh/fa/page/4774/%D9%87%D8%B3%D8%AA%D9%87-%DA%AF%D8%B2%DB%8C%D9%86%D8%B4-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%B3%D9%85%D9%86%D8%A7%D9%86) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین‌نامه‌ها و مصوبات](https://birjand.ac.ir/graduate/fa/regulation) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آشنایی با فعالیت‌های گروه برنامه‌ریزی توسعه آموزشی](https://birjand.ac.ir/file/download/page/1653803886-.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تأثیر معدل در کنکور ۹۸، مثبت شد](https://birjand.ac.ir/file/download/news/1542610728-209220...1.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۵. دانشگاه ولی عصر (عج) رفسنجان (`vali-asr-rafsanjan`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `vru.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۳۶. دانشگاه لرستان (`lorestan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.lu.ac.ir/](https://research.lu.ac.ir/).
- Official base domain: `lu.ac.ir`.
- [سامانه پروژه های تحقیق و توسعه - معاونت علمی، فناوری و اقتصاد ...](https://industry.lu.ac.ir/%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87-%D9%87%D8%A7/smnh-rh-tlaat-roh-h-thkk-o-tosaah/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، صنعت/فناوری، سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه لرستان مرکز رشد](https://roshd.lu.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارگاه آشنایی با الزامات عمومی و فرایند تأیید صلاحیت ...](https://www.lu.ac.ir/news/kargah-ashnaii-ba-alzamat-amvmi-v-fraind-taiid-slahit-azmaishgah-hai-azmvn-v-kalibrasivn-brgzar-mi-shvd/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مصوبات هیأت امناء](https://msr.lu.ac.ir/%D9%88%D8%A7%D8%AD%D8%AF%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B1-%D9%85%D8%AC%D9%85%D9%88%D8%B9%D9%87/%D8%AF%D8%A8%DB%8C%D8%B1%D8%AE%D8%A7%D9%86%D9%87-%D9%87%DB%8C%D8%A7%D8%AA-%D8%A7%D9%85%D9%86%D8%A7/%D9%85%D8%B5%D9%88%D8%A8%D8%A7%D8%AA-%D9%87%DB%8C%D8%A7%D8%AA-%D8%A7%D9%85%D9%86%D8%A7%D8%A1/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آزمایشگاه مرکزی دانشگاه لرستان به عضویت شبکه ...](https://www.lu.ac.ir/announcements/2016/05/20/%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%84%D8%B1%D8%B3%D8%AA%D8%A7%D9%86-%D8%A8%D9%87-%D8%B9%D8%B6%D9%88%DB%8C%D8%AA-%D8%B4%D8%A8%DA%A9%D9%87-%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%87%D8%A7%DB%8C-%D8%B1%D8%A7%D9%87%D8%A8%D8%B1%D8%AF%DB%8C-%DA%A9%D8%B4%D9%88%D8%B1-%D8%AF%D8%B1%D8%A2%D9%85%D8%AF/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=آزمایشگاه، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فهرست اخبار دانشگاه](https://www.lu.ac.ir/news/?fkeyid=&fkeyid=&newsview=2947&page=5&pageid=4006&siteid=1&siteid=1) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مصاحبه با مهندس شجاع مدیر گروه آموزشی برق_قدرت](https://eng.lu.ac.ir/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%A9%D8%AF%D9%87-%D9%81%D9%86%DB%8C-%D9%88-%D9%85%D9%87%D9%86%D8%AF%D8%B3%DB%8C/2018/12/16/%D9%85%D8%B5%D8%A7%D8%AD%D8%A8%D9%87-%D8%A8%D8%A7-%D9%85%D9%87%D9%86%D8%AF%D8%B3-%D8%B4%D8%AC%D8%A7%D8%B9-%D9%85%D8%AF%DB%8C%D8%B1-%DA%AF%D8%B1%D9%88%D9%87-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D8%A8%D8%B1%D9%82_%D9%82%D8%AF%D8%B1%D8%AA/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [گروه علوم باغبانی - دانشکده کشاورزی - دانشگاه لرستان](https://agri.lu.ac.ir/%DA%AF%D8%B1%D9%88%D9%87-%D8%B9%D9%84%D9%88%D9%85-%D8%A8%D8%A7%D8%BA%D8%A8%D8%A7%D9%86%DB%8C/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هدیه تعهد و تخصص دانشگاه لرستان به روستای دیمه یعقوب ...](https://www.lu.ac.ir/news/hdih-tahd-v-tkhss-danshgah-lrstan-bh-rvstai-dimh-iaghvb-khvzstan-tsfih-khanh-ab-shrb-rah-andazi-shd/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۷. دانشگاه مراغه (`maragheh`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://rtm.maragheh.ac.ir/](https://rtm.maragheh.ac.ir/).
- Official base domain: `maragheh.ac.ir`.
- [آیین‌نامه‌های پژوهشی - سامانه مدیریت امور پژوهشی دانشگاه مراغه](https://res.maragheh.ac.ir/_Pages/Regulations/Default.aspx) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، سامانه، اسناد/فرم‌ها; document=`regulation/bylaw` / `systems/data`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [شیوه نامه نحوه تخصیص اعتبار ویژه پژوهشی )گرنت( و تشویق ...](https://res.maragheh.ac.ir/_Pages/FileDownloadHandler.aspx?Code=b5ebb45a-b794-4d9b-9ca2-cdf2acbbea20&FileName=Shiveh+Nameh+Grant+Editted+Bahman+1403.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`procedure/guideline` / `grants/funding`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [د فترچه طرح استاد محوری در نظام ا ی ده ها یو ن ازها )نان( یو ژه](https://res.maragheh.ac.ir/_Pages/FileDownloadHandler.aspx?Code=1b629e9f-9d0d-493b-ba66-6818895c9b00&FileName=668267ab81628-nan-no-exam-1403-04-11.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۸. دانشگاه زابل (`zabol`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://uoz.ac.ir/prt/](https://uoz.ac.ir/prt/).
- Official base domain: `uoz.ac.ir`.
- [دانشگاه زابل](https://www.uoz.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ریاضیات و کاربردها](https://uoz.ac.ir/file/download/page/1682314536-1642510593-1-20220412-091138.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۳۹. دانشگاه یاسوج (`yasouj`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://yu.ac.ir/fa/res/](https://yu.ac.ir/fa/res/).
- Official base domain: `yu.ac.ir`.
- [شیمی](https://yu.ac.ir/sci/sites/sci/files/1405-04/%D8%B3%D8%B1%D9%81%D8%B5%D9%84%20%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C%20%D8%A7%D8%B1%D8%B4%D8%AF%20%D8%B4%DB%8C%D9%85%DB%8C%20%D9%81%DB%8C%D8%B2%DB%8C%DA%A9%20400.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۴۰. دانشگاه دامغان (`damghan`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `du.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۴۱. دانشگاه بناب (`bonab`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.ubonab.ac.ir/](https://research.ubonab.ac.ir/).
- Official base domain: `ubonab.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۴۲. دانشگاه گلستان (`golestan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://gu.ac.ir/research/](https://gu.ac.ir/research/).
- Official base domain: `gu.ac.ir`.
- [آیین‌نامه‌ها و شیوه‌نامه‌های وزارت علوم، تحقیقات و فناوری](https://gu.ac.ir/research/ContextPage?id=4081) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ارتباط جامعه با صنعت](https://gu.ac.ir/tec/ContextPage?id=12299) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت آموزشی و تحصیلات تکمیلی](https://gu.ac.ir/education/ContextPage?id=25206) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه گلستان](https://gu.ac.ir/) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۴۳. دانشگاه هرمزگان (`hormozgan`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.hormozgan.ac.ir/home/index/10/28/373](https://www.hormozgan.ac.ir/home/index/10/28/373).
- Official base domain: `hormozgan.ac.ir`.
- [د ر آ جا ی](https://hormozgan.ac.ir/fileupload/13_32/tempfile/N3093772078197186_5472057414549485.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۴۴. دانشگاه تفرش (`tafresh`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۴۵. دانشگاه اردکان (`ardakan`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۴۶. دانشگاه فسا (`fasa`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۴۷. دانشگاه آیت الله العظمی بروجردی (ره) (`ayatollah-borujerdi`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۴۸. دانشگاه بجنورد (`bojnord`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://vr.ub.ac.ir/](https://vr.ub.ac.ir/).
- Official base domain: `ub.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۴۹. دانشگاه علوم و فنون دریایی خرمشهر (`khorramshahr-marine`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۵۰. دانشگاه میبد (`meybod`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://new.meybod.ac.ir/research/forms](https://new.meybod.ac.ir/research/forms).
- Official base domain: `meybod.ac.ir`.
- [آیین‌نامه‌ها و فرم‌ها](https://new.meybod.ac.ir/research/forms) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه میبد](https://meybod.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [امور آموزش کارشناسی](https://meybod.ac.ir/academic-research/bachelors-education) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرمهای دکتری](https://meybod.ac.ir/academic-research/graduate-studies/PhD) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرمهای کارشناسی ارشد](https://meybod.ac.ir/academic-research/graduate-studies/master) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اخبار](https://meybod.ac.ir/news/page/60-14-15-1-3-2/lang/Fa.aspx) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه میبد: صفحه نخست](https://new.meybod.ac.ir/) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آرشیو اطلاعیه ها](https://new.meybod.ac.ir/ar/%D8%A2%D8%B1%D8%B4%DB%8C%D9%88-%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D9%87%D8%A7?category=136110&category=144504&category=144513&category=144516&category=42246&category=42246&delta=40) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جدیدترین اخبار](https://meybod.ac.ir/public-relations/news-sort/lang/Fa) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جزئیات اخبار افتتاح 3 پروژه عمرانی و فرهنگی ...](https://meybod.ac.ir/news-detail/Fa/2-18-3-1-1393-0/%D8%A7%D9%81%D8%AA%D8%AA%D8%A7%D8%AD-3-%D9%BE%D8%B1%D9%88%DA%98%D9%87-%D8%B9%D9%85%D8%B1%D8%A7%D9%86%DB%8C-%D9%88-%D9%81%D8%B1%D9%87%D9%86%DA%AF%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%DB%8C%D8%A8%D8%AF-%D8%AA%D9%88%D8%B3%D8%B7-%D8%A7%D8%B3%D8%AA%D8%A7%D9%86%D8%AF%D8%A7%D8%B1-%DB%8C%D8%B2%D8%AF.aspx) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۵۱. دانشگاه بزرگمهر قائنات (`bozorgmehr-qaenat`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://www.buqaen.ac.ir/%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C](https://www.buqaen.ac.ir/%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C).
- Official base domain: `buqaen.ac.ir`.
- [شبکه آزمایشگاه ها و کارگاه ها](https://www.buqaen.ac.ir/%D8%B4%D8%A8%DA%A9%D9%87-%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D8%A7-%D9%88-%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=آزمایشگاه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم ها و دستورالعمل های مدیریت فرهنگی - دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D9%81%D8%B1%D9%85-%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7%DB%8C-%D9%85%D8%AF%DB%8C%D8%B1%DB%8C%D8%AA-%D9%81%D8%B1%D9%87%D9%86%DA%AF%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، اسناد/فرم‌ها; document=`procedure/guideline` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دستور العمل ها، شیوه نامه ها و آیین نامه های انتشارات](https://www.buqaen.ac.ir/%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D8%AF%D8%B3%D8%AA%D9%88%D8%B1-%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7-%D8%B4%DB%8C%D9%88%D9%87-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7%DB%8C-%D8%A7%D9%86%D8%AA%D8%B4%D8%A7%D8%B1%D8%A7%D8%AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=کتابخانه/اسناد، اسناد/فرم‌ها; document=`regulation/bylaw` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [امور پژوهشی - دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دکتر مرتضی نوفرستی - دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/%D9%87%DB%8C%D8%A7%D8%AA-%D8%B9%D9%84%D9%85%DB%8C/%D8%AF%DA%A9%D8%AA%D8%B1-%D9%85%D8%B1%D8%AA%D8%B6%DB%8C-%D9%86%D9%88%D9%81%D8%B1%D8%B3%D8%AA%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم های دفتر ارتباط با صنعت ( ویژه اساتید )](https://www.buqaen.ac.ir/%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D9%81%D8%B1%D9%85-%D9%87%D8%A7%DB%8C-%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA-%D9%88%DB%8C%DA%98%D9%87-%D8%A7%D8%B3%D8%A7%D8%AA%DB%8C%D8%AF) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`form/template` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه های پژوهشی - دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D9%87%D8%A7/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7%DB%8C-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تقویم آموزشی اصلاح شده نیمسال دوم سال تحصیلی 1404 - 1405](https://www.buqaen.ac.ir/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D9%87%D8%A7/%D8%AA%D9%82%D9%88%DB%8C%D9%85-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D8%A7%D8%B5%D9%84%D8%A7%D8%AD-%D8%B4%D8%AF%D9%87-%D9%86%DB%8C%D9%85%D8%B3%D8%A7%D9%84-%D8%AF%D9%88%D9%85-%D8%B3%D8%A7%D9%84-%D8%AA%D8%AD%D8%B5%DB%8C%D9%84%DB%8C-1404-1405) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برگزاری آزمون کارشناسی ارشد سال ۱۴۰۵ در دانشگاه بزرگمهر قائنات](https://www.buqaen.ac.ir/%D8%A7%D8%AE%D8%A8%D8%A7%D8%B1/%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1%DB%8C-%D8%A2%D8%B2%D9%85%D9%88%D9%86-%D8%B3%D8%B1%D8%A7%D8%B3%D8%B1%DB%8C-%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C-%D8%A7%D8%B1%D8%B4%D8%AF-%D8%B3%D8%A7%D9%84-%DB%B1%DB%B4%DB%B0%DB%B5-%D8%AF%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%A8%D8%B2%D8%B1%DA%AF%D9%85%D9%87%D8%B1-%D9%82%D8%A7%D8%A6%D9%86%D8%A7%D8%AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۵۲. دانشگاه دریانوردی و علوم دریایی چابهار (`chabahar-maritime`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۵۳. دانشگاه ولایت (`velayat`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۵۴. دانشگاه تخصصی فناوری های نوین آمل (`amol-special-tech`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://ausmt.ac.ir/forms](https://ausmt.ac.ir/forms).
- Official base domain: `ausmt.ac.ir`.
- [آیین نامه طرح های تحقیقاتی برون دانشگاهی](https://ausmt.ac.ir/p/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D8%B7%D8%B1%D8%AD-%D9%87%D8%A7%DB%8C-%D8%AA%D8%AD%D9%82%DB%8C%D9%82%D8%A7%D8%AA%DB%8C-%D8%A8%D8%B1%D9%88%D9%86-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87%DB%8C?sub=industry) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آشنایی با نحوه اخذ پروژه های فناورانه و پژوهشی در ارتباط با ...](https://www.ausmt.ac.ir/event/%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C-%D8%A8%D8%A7-%D9%86%D8%AD%D9%88%D9%87-%D8%A7%D8%AE%D8%B0-%D9%BE%D8%B1%D9%88%DA%98%D9%87-%D9%87%D8%A7%DB%8C-%D9%81%D9%86%D8%A7%D9%88%D8%B1%D8%A7%D9%86%D9%87-%D9%88-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D8%AF%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%AC%D8%A7%D9%85%D8%B9%D9%87-%D9%88-%D8%B5%D9%86%D8%B9%D8%AA) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه‌های حمایتی از شرکت‌های دانش‌بنیان](https://ausmt.ac.ir/p/%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%AD%D9%85%D8%A7%DB%8C%D8%AA%DB%8C-%D8%A7%D8%B2-%D8%B4%D8%B1%DA%A9%D8%AA%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%E2%80%8C%D8%A8%D9%86%DB%8C%D8%A7%D9%86?sub=industry) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بازدید دانش آموزان دختر مدرسه شاهد از آزمایشگاه های دانشگاه ...](https://it.ausmt.ac.ir/article/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D8%AF%D8%A7%D9%86%D8%B4-%D8%A2%D9%85%D9%88%D8%B2%D8%A7%D9%86-%D8%AF%D8%AE%D8%AA%D8%B1-%D9%85%D8%AF%D8%B1%D8%B3%D9%87-%D8%B4%D8%A7%D9%87%D8%AF-%D8%A7%D8%B2-%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%AA%D8%AE%D8%B5%D8%B5%DB%8C-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C%D9%87%D8%A7%DB%8C-%D9%86%D9%88%DB%8C%D9%86-%D8%A2%D9%85%D9%84) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=آزمایشگاه، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بازدید علمی دانشجویان](https://www.vet.ausmt.ac.ir/article/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D8%B9%D9%84%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%D8%AC%D9%88%DB%8C%D8%A7%D9%86-) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بازدید دفتر ارتباط با صنعت به همراه اعضای هیات علمی، از شرکت ...](https://ausmt.ac.ir/article/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA-%D8%A8%D9%87-%D9%87%D9%85%D8%B1%D8%A7%D9%87-%D8%A7%D8%B9%D8%B6%D8%A7%DB%8C-%D9%87%DB%8C%D8%A7%D8%AA-%D8%B9%D9%84%D9%85%DB%8C%D8%8C-%D8%A7%D8%B2-%D8%B4%D8%B1%DA%A9%D8%AA-%D9%81%D8%B1%D8%A7%D9%88%D8%B1%D8%AF%D9%87%20%D9%87%D8%A7%DB%8C-%DA%AF%D9%88%D8%B4%D8%AA%DB%8C-%DA%A9%D8%A7%D9%84%D9%87-%D8%A2%D9%85%D9%84?sub=industry) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [بازدید معاون آموزشی وزیر علوم از دانشگاه تخصصی فناوری ...](https://industry.ausmt.ac.ir/article/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D9%85%D8%B9%D8%A7%D9%88%D9%86-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D9%88%D8%B2%DB%8C%D8%B1-%D8%B9%D9%84%D9%88%D9%85-%D8%A7%D8%B2-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%AA%D8%AE%D8%B5%D8%B5%DB%8C-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D9%88%DB%8C%D9%86-%D8%A2%D9%85%D9%84) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [شیوه‌نامه بکارگیری امریه سربازی در شرکت‌های دانش‌بنیان](https://ausmt.ac.ir/p/%D8%B4%DB%8C%D9%88%D9%87%E2%80%8C%D9%86%D8%A7%D9%85%D9%87-%D8%A8%DA%A9%D8%A7%D8%B1%DA%AF%DB%8C%D8%B1%DB%8C-%D8%A7%D9%85%D8%B1%DB%8C%D9%87-%D8%B3%D8%B1%D8%A8%D8%A7%D8%B2%DB%8C-%D8%AF%D8%B1-%D8%B4%D8%B1%DA%A9%D8%AA%C2%AD%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%E2%80%8C%D8%A8%D9%86%DB%8C%D8%A7%D9%86?sub=industry) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`procedure/guideline` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [درخشش روابط عمومی دانشگاه تخصصی فناوری های نوین آمل در ...](https://mpl.ausmt.ac.ir/article/%D8%AF%D8%B1%D8%AE%D8%B4%D8%B4-%D8%B1%D9%88%D8%A7%D8%A8%D8%B7-%D8%B9%D9%85%D9%88%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%AA%D8%AE%D8%B5%D8%B5%DB%8C-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%87%D8%A7%DB%8C-%D9%86%D9%88%DB%8C%D9%86-%D8%A2%D9%85%D9%84-%D8%AF%D8%B1-%D8%A8%D8%AE%D8%B4-%D8%A7%D8%B7%D9%84%D8%A7%D8%B9-%D8%B1%D8%B3%D8%A7%D9%86%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۵۵. دانشگاه ملایر (`malayer`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `malayeru.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۵۶. دانشگاه گنبد کاووس (`gonbad-kavous`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `gonbad.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۵۷. دانشگاه تربت حیدریه (`torbat-heydarieh`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۵۸. دانشگاه حضرت معصومه (س) (`hazrat-masoumeh`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۵۹. دانشگاه جهرم (`jahrom`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۰. دانشگاه کوثر (`kosar`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۱. دانشگاه جیرفت (`jiroft`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `ujiroft.ac.ir`.
- [( 1390 ـ 1394 ) ﻣﺘﻦ ﮐﺎﻣﻞ ﻗﺎﻧﻮن ﺑﺮﻧﺎﻣﻪ ﭘﻨﺠﺴﺎﻟﻪ ﭘﻨﺠﻢ ﺗﻮﺳﻌﻪ ﺟ](https://ujiroft.ac.ir/support/fa/regulation/download?id=19) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۶۲. دانشگاه سلمان فارسی کازرون (`salman-farsi-kazerun`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `kazerunsfu.ac.ir`.
- [لیست کارمندان](https://kazerunsfu.ac.ir/fa/grid/9/%D9%84%DB%8C%D8%B3%D8%AA-%DA%A9%D8%A7%D8%B1%D9%85%D9%86%D8%AF%D8%A7%D9%86) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Newsletter Salman Farsi No.015](https://kazerunsfu.ac.ir/NS15.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۶۳. مرکز آموزش عالی لار (`lar-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۴. مجتمع آموزش عالی گناباد (`gonabad-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `gonabad.ac.ir`.
- [بازدید علمی دانشجویان رشته شیمی کاربردی و مهندسی ...](https://gonabad.ac.ir/ednews/%D8%A8%D8%A7%D8%B2%D8%AF%DB%8C%D8%AF-%D8%B9%D9%84%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%D8%AC%D9%88%DB%8C%D8%A7%D9%86-%D8%B1%D8%B4%D8%AA%D9%87-%D8%B4%DB%8C%D9%85%DB%8C-%DA%A9%D8%A7%D8%B1%D8%A8%D8%B1%D8%AF%DB%8C-%D9%88-%D9%85%D9%87%D9%86%D8%AF%D8%B3%DB%8C-%D9%85%D8%AA%D8%A7%D9%84%D9%88%D8%B1%DA%98%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%86%D8%A7%D8%A8%D8%A7%D8%AF-%D8%A7%D8%B2-%D8%B5%D9%86%D8%A7%DB%8C%D8%B9-%D9%81%D9%88%D9%84%D8%A7%D8%AF-%D9%88-%D8%B3%DB%8C%D9%85%D8%A7%D9%86-%D9%82%D8%A7%DB%8C%D9%86-) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [از سرآمدان آموزشی دانشگاه گــناباد تقدیر شد.](https://gonabad.ac.ir/ednews/%D8%A7%D8%B2-%D8%B3%D8%B1%D8%A2%D9%85%D8%AF%D8%A7%D9%86-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%80%D9%80%D9%86%D8%A7%D8%A8%D8%A7%D8%AF--%D8%AA%D9%82%D8%AF%DB%8C%D8%B1-%D8%B4%D8%AF%C2%B7-) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آزمون های پایان ترم دوره کارشناسی ارشد ...](https://gonabad.ac.ir/EdNews/%D8%A2%D8%B2%D9%85%D9%88%D9%86-%D9%87%D8%A7%DB%8C-%D9%BE%D8%A7%DB%8C%D8%A7%D9%86-%D8%AA%D8%B1%D9%85-%D8%AF%D9%88%D8%B1%D9%87-%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C-%D8%A7%D8%B1%D8%B4%D8%AF-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%86%D8%A7%D8%A8%D8%A7%D8%AF-%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1-%D8%B4%D8%AF%C2%B7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [انجمن علمی مهندسی مکانیک دانشگاه گناباد برگزار کرد](https://gonabad.ac.ir/ednews/%D8%A7%D9%86%D8%AC%D9%85%D9%86-%D8%B9%D9%84%D9%85%DB%8C-%D9%85%D9%87%D9%86%D8%AF%D8%B3%DB%8C-%D9%85%DA%A9%D8%A7%D9%86%DB%8C%DA%A9-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%86%D8%A7%D8%A8%D8%A7%D8%AF-%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1-%DA%A9%D8%B1%D8%AF) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اتصال چهار ساختمان اصلی به شبکه فیبرنوری](https://gonabad.ac.ir/ResNews/%D8%A7%D8%AA%D8%B5%D8%A7%D9%84-%DA%86%D9%87%D8%A7%D8%B1-%D8%B3%D8%A7%D8%AE%D8%AA%D9%85%D8%A7%D9%86-%D8%A7%D8%B5%D9%84%DB%8C-%D8%A8%D9%87-%D8%B4%D8%A8%DA%A9%D9%87-%D9%81%DB%8C%D8%A8%D8%B1%D9%86%D9%88%D8%B1%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [همزمان با روز ملی روانشناس و مشاور، نشستی در ...](https://gonabad.ac.ir/EdNews/%D9%87%D9%85%D8%B2%D9%85%D8%A7%D9%86-%D8%A8%D8%A7-%D8%B1%D9%88%D8%B2-%D9%85%D9%84%DB%8C-%D8%B1%D9%88%D8%A7%D9%86%D8%B4%D9%86%D8%A7%D8%B3-%D9%88-%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D8%8C-%D9%86%D8%B4%D8%B3%D8%AA%DB%8C-%D8%AF%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%86%D8%A7%D8%A8%D8%A7%D8%AF-%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1-%D8%B4%D8%AF%C2%B7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارگاه آموزشی فشار خون و نقش تغذیه در پیشگیری از آن](https://gonabad.ac.ir/ednews/-%DA%A9%D8%A7%D8%B1%DA%AF%D8%A7%D9%87-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C-%D9%81%D8%B4%D8%A7%D8%B1-%D8%AE%D9%88%D9%86-%D9%88-%D9%86%D9%82%D8%B4-%D8%AA%D8%BA%D8%B0%DB%8C%D9%87-%D8%AF%D8%B1-%D9%BE%DB%8C%D8%B4%DA%AF%DB%8C%D8%B1%DB%8C-%D8%A7%D8%B2-%D8%A2%D9%86%D8%8C-%D8%AF%D8%B1-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%DA%AF%D9%86%D9%80%D9%80%D8%A7%D8%A8%D8%A7%D8%AF-%D8%A8%D8%B1%DA%AF%D8%B2%D8%A7%D8%B1-%D8%B4%D8%AF%C2%B7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مشاوره رایگان انتخاب رشته کنکور سراسری ۱۴۰۳](https://gonabad.ac.ir/ednews/%D9%85%D8%B4%D8%A7%D9%88%D8%B1%D9%87-%D8%B1%D8%A7%DB%8C%DA%AF%D8%A7%D9%86-%D8%A7%D9%86%D8%AA%D8%AE%D8%A7%D8%A8-%D8%B1%D8%B4%D8%AA%D9%87-%DA%A9%D9%86%DA%A9%D9%88%D8%B1-%D8%B3%D8%B1%D8%A7%D8%B3%D8%B1%DB%8C-%DB%B1%DB%B4%DB%B0%DB%B3) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۶۵. مجتمع آموزش عالی بم (`bam-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۶. دانشگاه نیشابور (`neyshabur`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۷. مرکز آموزش عالی اقلید (`eghlid-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۸. مرکز آموزش عالی کاشمر (`kashmar-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۶۹. دانشگاه سید جمال الدین اسدآبادی (`seyed-jamaleddin-asadabadi`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۷۰. دانشگاه علم و صنعت ایران (`iust`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.iust.ac.ir/](https://research.iust.ac.ir/).
- Official base domain: `iust.ac.ir`.
- [شیوه نامه تشکیل و فعالیت واحدهای پژوهش و فناوری در دانشگاه ...](https://technology.iust.ac.ir/portfolio/a/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`procedure/guideline` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پویان ایار](https://www.iust.ac.ir/page/18987/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [كارانمه ژپوهش و فناوري لاس 98](https://www.iust.ac.ir/files/res_office/files/%DA%A9%D8%A7%D8%B1%D9%86%D8%A7%D9%85%D9%87_%D9%BE%DA%98%D9%88%D9%87%D8%B4_%D9%88_%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C_98_%281%29.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ها و فرمها](https://www.iust.ac.ir/page/12807/%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D9%81%D8%B1%D9%85%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دکتر ندا کامبوزیا](https://www.iust.ac.ir/find-32.18346.54822.fa.html) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دکتر پرویز قدوسی](https://www.iust.ac.ir/page/6038/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Iran University of Science & Technology](https://www.iust.ac.ir/page_arch.php?ipp=50&list=&sid=32&slc_lang=fa&slc_pg_id=0&start=550) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Research Vc - معاونت پژوهش و فناوری](https://www.iust.ac.ir/printme-7.14155.34574.fa.html) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۱. دانشگاه صنعتی شریف (`sharif`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.sharif.ir/](https://research.sharif.ir/).
- Official base domain: `sharif.ir`.
- [جستجو - دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/tr/search?delta=60&start=5) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جستجو - دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/ar/search?delta=4&p_p_id=com_liferay_login_web_portlet_LoginPortlet&p_p_lifecycle=0&p_p_state=normal&p_p_state_rcv=1&start=109) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه صنعتی شریف: صفحه اصلی](https://www.sharif.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جستجو - دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/tr/search?delta=60&start=4) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [صنعت بانکداری ایران شناسایی پنجره های فرصت فناوری بالکچین در](https://stpl.ristip.sharif.ir/article_22210_4f17f501f060b42178329537332a16f2.pdf) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [[PDF] كتابچه راهنماي تحصيالت تكميلي دانشكده مهندسي برق](https://www.sharif.ir/documents/1230688/0/Catalog000801.pdf/f84b9a94-53f1-13f0-3882-f03c768a1f9e?t=1640769589342) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`procedure/guideline` / `publications/journals`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جستجو - دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/tr/search?delta=8&p_p_id=com_liferay_login_web_portlet_LoginPortlet&p_p_lifecycle=0&p_p_state=normal&p_p_state_rcv=1&start=32) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [[PDF] جهش تولید - پارک علم و فناوری - دانشگاه صنعتی شریف](https://techpark.sharif.ir/wp-content/uploads/2021/01/%D9%88%DB%8C%DA%98%D9%87%E2%80%8C%D9%86%D8%A7%D9%85%D9%87-%D9%87%D9%81%D8%AA%D9%87-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [جستجو - دانشکده مهندسی انرژی - دانشگاه صنعتی شریف](https://www.energy.sharif.ir/tr/search?delta=60&start=8) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۲. دانشگاه صنعتی امیرکبیر (`amirkabir`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.aut.ac.ir/](https://research.aut.ac.ir/).
- Official base domain: `aut.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۷۳. دانشگاه صنعتی خواجه نصیرالدین طوسی (`kntu`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.kntu.ac.ir/](https://research.kntu.ac.ir/).
- Official base domain: `kntu.ac.ir`.
- [گزارش مهمترین برنامه ها واقدامات دانشگاه در نشست رئیس ...](https://www.kntu.ac.ir/fa/web/pr/w/%DA%AF%D8%B2%D8%A7%D8%B1%D8%B4-%D9%85%D9%87%D9%85%D8%AA%D8%B1%DB%8C%D9%86-%D8%A8%D8%B1%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88%D8%A7%D9%82%D8%AF%D8%A7%D9%85%D8%A7%D8%AA-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D8%AF%D8%B1-%D9%86%D8%B4%D8%B3%D8%AA-) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [شيوه تدوين پايان نامه](https://en.chem.kntu.ac.ir/page-grad96/fa/12/form/pId697) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=اسناد/فرم‌ها; document=`document-index/page` / `research/postgraduate`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هیات امنا دانشگاه - دانشگاه صنعتی خواجه نصیرالدین ...](https://www.kntu.ac.ir/ubt) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه صنعتی خواجه نصیرالدین طوسی - آزمایشگاه سیستم های کنترل ...](https://acsl2.ece.kntu.ac.ir/page-ShowPages/fa/0/printskin-form/25789) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=آزمایشگاه، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشكده مهندسی کامپیوتر - دانشگاه صنعتی خواجه نصیرالدین ...](https://ce.kntu.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارنامه پژوهشی دانشگاه صنعتی خواجه نصیرالدین طوسی سال ...](https://kntu.ac.ir/dorsapax/userfiles/file/Pajohesh/karnameh1392.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشكده فيزيك: صفحه اصلی](https://physics.kntu.ac.ir/) — محتوای صفحه بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معیارهای ارزیابی - خوابگاه - دانشگاه صنعتی خواجه نصیرالدین طوسی](https://dorm.kntu.ac.ir/page-EEKNTU9911/fa/8/form/pId21816) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۴. دانشگاه صنعتی اصفهان (`isfahan-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.iut.ac.ir/](https://research.iut.ac.ir/).
- Official base domain: `iut.ac.ir`.
- [آیین نامه ها و مصوبات — معاونت پژوهش و فناوری](https://research.iut.ac.ir/fa/dgr/1770) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مقررات و آيين نامه های پژوهشی - معاونت پژوهش و فناوری](https://research.iut.ac.ir/fa/node/1577) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آیین نامه ها — معاونت پژوهش و فناوری - دانشگاه صنعتی اصفهان](https://research.iut.ac.ir/fa/tico/2384) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کمیته اخلاق در پژوهش](https://research.iut.ac.ir/fa/dgr/3043) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرایند ثبت کتاب ها و مجلات در سامانه گلستان](https://research.iut.ac.ir/fa/dgr/2922) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=سامانه; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اخلاق در پژوهش - معاونت پژوهش و فناوری - دانشگاه صنعتی اصفهان](https://research.iut.ac.ir/fa/dgr/2305) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [راهنماها و دستورالعمل ها - معاونت پژوهش و فناوری](https://research.iut.ac.ir/fa/scientometrics/1749) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`procedure/guideline` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم ها — معاونت پژوهش و فناوری - دانشگاه صنعتی اصفهان](https://research.iut.ac.ir/fa/dgr/2920) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`form/template` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۵. دانشگاه صنعتی شاهرود (`shahrood-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.shahroodut.ac.ir/fa/sec/index.php?id=11](https://www.shahroodut.ac.ir/fa/sec/index.php?id=11).
- Official base domain: `shahroodut.ac.ir`.
- [راهنماها و دستورالعمل ها: مدیریت امور آموزشی (مقطع کارشناسی) ...](https://shahroodut.ac.ir/fa/sec/index.php?id=1&index=951) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، اسناد/فرم‌ها; document=`procedure/guideline` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آزمایشگاه تخصصی انرژی (سولارکار): مرکز رشد فناوری های ...](https://shahroodut.ac.ir/fa/sec/index.php?id=33&page=263) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=آزمایشگاه، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [وظایف: مدیریت امور آموزشی (مقطع کارشناسی) ...](https://shahroodut.ac.ir/fa/sec/index.php?id=1&index=2) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آشنایی با شرکت های دانش بنیان و قوانین مربوطه](https://shahroodut.ac.ir/fa/sec/index.php?id=33&page=312) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [هیات اجرایی جذب دانشگاه صنعتی شاهرود](https://www.shahroodut.ac.ir/fa/sec/index.php?id=19) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ریاست دانشگاه دانشگاه صنعتی شاهرود](https://www.shahroodut.ac.ir/fa/sec/index.php?id=25) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت فرهنگی و اجتماعی دانشگاه صنعتی شاهرود](https://www.shahroodut.ac.ir/fa/sec/index.php?id=14) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سایت های کامپیوتر: مدیریت توسعه فناوری اطلاعات](https://shahroodut.ac.ir/fa/sec/index.php?id=5&index=39) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری، IT نامزد; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ارتباط با دفتر و دبیرخانه تحصیلات تکمیلی](https://www.shahroodut.ac.ir/fa/sec/index.php?id=6&index=52) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پیشنهادات و انتقادات به ریاست دانشگاه دانشگاه صنعتی شاهرود](https://shahroodut.ac.ir/fa/sec/?id=40) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۶. دانشگاه صنعتی نوشیروانی بابل (`babol-noshirvani`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.nit.ac.ir/](https://research.nit.ac.ir/).
- Official base domain: `nit.ac.ir`.
- [دانشگاه صنعتي نوشيرواني بابل](https://rw1403.nit.ac.ir/fa/page/1766) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=صنعت/فناوری; document=`document-index/page` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [final karnameh2.docx](https://nit.ac.ir/file/download/download/1676283537-finalkarnameh96.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [1404 گزارش عملکرد سال حوزه ارتباط با جامعه و صنعت - حوزه معاونت ...](https://research.nit.ac.ir/file/download/news/1773736077-69b9108de4276-1404-1.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=ساختار، صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [1404 گزارش عملکرد سال حوزه ارتباط با جامعه و صنعت](https://research.nit.ac.ir/file/download/news/1773736142-69b910cee06b3-1404-2.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [Untitled - مدیریت همکاری‌های علمی و بین المللی](https://int.nit.ac.ir/file/download/news/1632304334-osciareport99.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مهندسی پلیمر](https://edu.nit.ac.ir/file/download/regulation/6745a94bec847-polymer-enineering-.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پایان‌نامه‌ها‌و‌رساله‌های برگزیده‌تقاضامحور](https://news.nit.ac.ir/file/download/news/1777966690-69f99e62cb349-1404.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `research/postgraduate`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [خبـرنامـه الکتـرونیکی](https://lib.nit.ac.ir/file/download/news/1630904598-winter-newsletter-1400-02-13-3.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۷. دانشگاه صنعتی سهند (`sahand`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://sut.ac.ir/research/fa/](https://sut.ac.ir/research/fa/).
- Official base domain: `sut.ac.ir`.
- [قوانین حمایت های مالیاتی دانش بنیان](https://sut.ac.ir/tme/fa/regulation/download?id=926) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-index/page` / `grants/funding`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه صنعتی سهند](https://www.sut.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده مهندسی پزشکی](https://www.sut.ac.ir/bme/fa) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [برنامه درسی ارشد و دکتری مهندسی برق 1402 به بعد](https://sut.ac.ir/file/download/regulation/670e1b3e61b70-.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۷۸. دانشگاه صنعتی شیراز (`shiraz-technology`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `sutech.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۷۹. دانشگاه تحصیلات تکمیلی صنعتی و فناوری پیشرفته کرمان (`kgut`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۰. دانشگاه صنعتی ارومیه (`urmia-technology`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۱. دانشگاه صنعتی قوچان (`qochan-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.qiet.ac.ir/](https://research.qiet.ac.ir/).
- Official base domain: `qiet.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۸۲. دانشگاه صنعتی اراک (`arak-technology`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۳. دانشگاه صنعتی کرمانشاه (`kermanshah-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.kut.ac.ir/](https://research.kut.ac.ir/).
- Official base domain: `kut.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۸۴. دانشگاه صنعتی قم (`qom-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://qut.ac.ir/fa/researches/index](https://qut.ac.ir/fa/researches/index).
- Official base domain: `qut.ac.ir`.
- [آیین گرامیداشت روز استاد و تجلیل از سرآمدان آموزشی دانشگاه ...](https://qut.ac.ir/fa/university-news/index/140502221) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=اسناد/فرم‌ها; document=`document-index/page` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۸۵. دانشگاه صنعتی جندی شاپور دزفول (`jundi-shapur-dezful`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۶. دانشگاه صنعتی همدان (`hamedan-technology`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۷. دانشگاه صنعتی خاتم الانبیاء بهبهان (`khatam-behbahan`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۸. دانشگاه صنعتی سیرجان (`sirjan-technology`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۸۹. دانشگاه علم و فناوری مازندران (بهشهر) (`mazandaran-science-tech`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۰. مجتمع آموزش عالی فنی و مهندسی اسفراین (`esfarayen-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۱. دانشگاه صنعتی بیرجند (`birjand-technology`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.birjandut.ac.ir/](https://research.birjandut.ac.ir/).
- Official base domain: `birjandut.ac.ir`.
- Inspected page inventory: unresolved. No first-party page was recovered.

### ۹۲. مرکز آموزش عالی فنی و مهندسی بوئین زهرا (`buin-zahra-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۳. مرکز آموزش عالی محلات (`mahallat-higher-ed`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۴. دانشگاه علوم کشاورزی و منابع طبیعی گرگان (`gorgan-agri`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۵. دانشگاه علوم کشاورزی و منابع طبیعی ساری (`sari-agri`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۶. دانشگاه علوم کشاورزی و منابع طبیعی خوزستان (`khuzestan-agri`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://asnrukh.ac.ir/research/fa/regulation?sort=-categoryId](https://asnrukh.ac.ir/research/fa/regulation?sort=-categoryId).
- Official base domain: `asnrukh.ac.ir`.
- [آیین‌نامه‌ها و فرم‌ها](https://asnrukh.ac.ir/research/fa/regulation?sort=-categoryId) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [اﻋﻀﺎي ﻫﯿﺎت ﻋﻠﻤﯽ ﺑﺮﺗﺮ در ﻫﻤﮑﺎري ﺑﺎ ﺟﺎﻣﻌﻪ و ﺻﻨﻌﺖ](https://asnrukh.ac.ir/file/download/news/1608960317-.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۹۷. دانشکده کشاورزی و دامپروری تربت جام (`torbat-jam-agri`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۹۸. دانشگاه هنر ایران (`iran-art`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://research.art.ac.ir/fa](https://research.art.ac.ir/fa).
- Official base domain: `art.ac.ir`.
- [トهدف از این گزارش - معاونت پژوهشی و فناوری - دانشگاه هنر](https://research.art.ac.ir/file/download/page/1624170004-99-min.pdf) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری; document=`document-file` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۹۹. دانشگاه هنر اسلامی تبریز (`tabriz-islamic-art`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://research.tabriziau.ac.ir/News/159/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D8%AA%DA%A9%D9%85%DB%8C%D9%84%DB%8C-%D9%81%D8%B1%D8%A7%D8%AE%D9%88%D8%A7%D9%86-%D8%B7%D8%B1%D8%A7%D8%AD%DB%8C-%C2%AB%D8%B2%D8%A8%D8%A7%D9%86-%D9%85%D9%84%DB%8C-%D8%A7%D9%84%D9%85%D8%A7%D9%86%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B3%D8%AA%E2%80%8C%D8%A8%D9%88%D9%85-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%88-%D9%86%D9%88%D8%A2%D9%88%D8%B1%DB%8C-%D8%A7%DB%8C%D8%B1%D8%A7%D9%86%C2%BB.html](https://research.tabriziau.ac.ir/News/159/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D8%AA%DA%A9%D9%85%DB%8C%D9%84%DB%8C-%D9%81%D8%B1%D8%A7%D8%AE%D9%88%D8%A7%D9%86-%D8%B7%D8%B1%D8%A7%D8%AD%DB%8C-%C2%AB%D8%B2%D8%A8%D8%A7%D9%86-%D9%85%D9%84%DB%8C-%D8%A7%D9%84%D9%85%D8%A7%D9%86%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B3%D8%AA%E2%80%8C%D8%A8%D9%88%D9%85-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%88-%D9%86%D9%88%D8%A2%D9%88%D8%B1%DB%8C-%D8%A7%DB%8C%D8%B1%D8%A7%D9%86%C2%BB.html).
- Official base domain: `tabriziau.ac.ir`.
- [زبان ملی المان‌های زیست‌بوم فناوری و نوآوری ایران» - معاونت پژوهش](https://research.tabriziau.ac.ir/News/159/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%DB%8C%D9%87-%D8%AA%DA%A9%D9%85%DB%8C%D9%84%DB%8C-%D9%81%D8%B1%D8%A7%D8%AE%D9%88%D8%A7%D9%86-%D8%B7%D8%B1%D8%A7%D8%AD%DB%8C-%C2%AB%D8%B2%D8%A8%D8%A7%D9%86-%D9%85%D9%84%DB%8C-%D8%A7%D9%84%D9%85%D8%A7%D9%86%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B3%D8%AA%E2%80%8C%D8%A8%D9%88%D9%85-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C-%D9%88-%D9%86%D9%88%D8%A2%D9%88%D8%B1%DB%8C-%D8%A7%DB%8C%D8%B1%D8%A7%D9%86%C2%BB.html) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار، صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم ها و آیین نامه ها](https://tabriziau.ac.ir/Page/10/%D9%81%D8%B1%D9%85-%D9%87%D8%A7-%D9%88-%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7.html) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=اسناد/فرم‌ها; document=`regulation/bylaw` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مصوبات هیئت امنا](https://tabriziau.ac.ir/Page/96/%D9%85%D8%B5%D9%88%D8%A8%D8%A7%D8%AA-%D9%87%DB%8C%D8%A6%D8%AA-%D8%A7%D9%85%D9%86%D8%A7.html) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [کارگروه شهرسازی](https://edu.tabriziau.ac.ir/uploads/user/6/1404.09.17/-1404.09.17%D8%B3%D8%B1%D9%81%D8%B5%D9%84%20%D8%AF%D8%B1%D9%88%D8%B3/%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C/%D9%85%D9%87%D9%86%D8%AF%D8%B3%DB%8C%20%D8%B4%D9%87%D8%B1%D8%B3%D8%A7%D8%B2%DB%8C-%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۰. دانشگاه هنر اصفهان (`isfahan-art`)

- Seed outcome: سطح پژوهشی رسمی؛ نه لزوماً صفحهٔ اصلی.
- Seed: [https://entrepreneurship.aui.ac.ir/Index.aspx?BlockName=tool_link_sample_moavenatpajooheshi_block276&codel=231&lang=1&page_=form&referrer=link&sub=7&tempname=Moavenatshow](https://entrepreneurship.aui.ac.ir/Index.aspx?BlockName=tool_link_sample_moavenatpajooheshi_block276&codel=231&lang=1&page_=form&referrer=link&sub=7&tempname=Moavenatshow).
- Official base domain: `aui.ac.ir`.
- [معاونت پژوهشي دانشگاه هنر اصفهان](https://entrepreneurship.aui.ac.ir/Index.aspx?BlockName=tool_link_sample_moavenatpajooheshi_block276&codel=231&lang=1&page_=form&referrer=link&sub=7&tempname=Moavenatshow) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آغاز سال تحصیلی جدید و فرارسیدن بهار دانش و تعلیم و ...](https://aui.ac.ir/Dorsapax/userfiles/Sub4/667064.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دستاورد ارزشمند هیئت علمی دانشگاه هنر اصفهان در سطح ملی](https://www.aui.ac.ir/page-moavenatshow/FA/7/dorsaetoolsenews/15166-G0/tool_dorsaetoolsenews_sample_moavenatpajooheshi_block297/%D8%AF%D8%B3%D8%AA%D8%A7%D9%88%D8%B1%D8%AF-%D8%A7%D8%B1%D8%B2%D8%B4%D9%85%D9%86%D8%AF-%D9%87%DB%8C%D8%A6%D8%AA-%D8%B9%D9%84%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D9%86%D8%B1-%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86-%D8%AF%D8%B1-%D8%B3%D8%B7) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [تربیت نیروی انسانی باید متناسب با نیازهای واقعی کشور ...](https://aui.ac.ir/Dorsapax/userfiles/Sub7/125478.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دستاورد ارزشمند هیئت علمی دانشگاه هنر اصفهان در سطح ملی](https://oisc.aui.ac.ir/page-moavenatshow/FA/7/dorsaetoolsenews/15166-G0/tool_dorsaetoolsenews_sample_moavenatpajooheshi_block297/%D8%AF%D8%B3%D8%AA%D8%A7%D9%88%D8%B1%D8%AF-%D8%A7%D8%B1%D8%B2%D8%B4%D9%85%D9%86%D8%AF-%D9%87%DB%8C%D8%A6%D8%AA-%D8%B9%D9%84%D9%85%DB%8C-%D8%AF%D8%A7%D9%86%D8%B4%DA%AF%D8%A7%D9%87-%D9%87%D9%86%D8%B1-%D8%A7%D8%B5%D9%81%D9%87%D8%A7%D9%86-%D8%AF%D8%B1-%D8%B3%D8%B7) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پژوهشي»مرمت آثار و بافت های تاریخی، فرهنگی](https://mmi.aui.ac.ir/files/site1/image/maremat%20I.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۱. دانشگاه هنر شیراز (`shiraz-art`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `shirazartu.ac.ir`.
- [اهداف و راهبردهای کلان توسعه](https://shirazartu.ac.ir/?page_id=47) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ساختار سازمانی](https://shirazartu.ac.ir/?page_id=71) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آموزش‌های آزاد و مجازی](https://shirazartu.ac.ir/?page_id=12425) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [امور مالی](https://shirazartu.ac.ir/?page_id=773) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [امور بین الملل](https://shirazartu.ac.ir/?page_id=173) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [انتصاب دکتر مریم دشتی‌زاده به عنوان مدیر امور پژوهش و ...](https://shirazartu.ac.ir/?p=18525) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دفتر نظارت و ارزیابی](https://shirazartu.ac.ir/?page_id=177) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [نقشه سایت](https://shirazartu.ac.ir/?page_id=236) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [سفیر رحمت و مهربانی» در گردهمایی معاونان فرهنگی منطقه ۷ ...](https://shirazartu.ac.ir/?p=21031) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [معاونت ها](https://shirazartu.ac.ir/?page_id=67) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۲. دانشگاه پیام نور (`payame-noor`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `pnu.ac.ir`.
- [Public Organizations Management](https://ipom.journals.pnu.ac.ir/article_6481_b79e359ca59c8811ab8d42036306dc09.pdf?lang=en) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۳. دانشگاه ملی مهارت (`national-skills`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `nus.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۱۰۴. دانشگاه فرهنگیان (`farhangian`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://cfu.ac.ir/fa/grid/11/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C](https://cfu.ac.ir/fa/grid/11/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C).
- Official base domain: `cfu.ac.ir`.
- [جستجوی مطالب](https://cfu.ac.ir/cq/?adv=1&lang=fa&limit=36&node_id=%E2%80%AD31438%E2%80%AC&of=37) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشگاه فرهنگیان — جستجوی مطالب](https://cfu.ac.ir/cq/fa/?tags=LMS) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۵. دانشگاه جامع علمی کاربردی (`applied-science`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۱۰۶. دانشگاه جامع امام حسین (ع) (`imam-hossein`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `ihu.ac.ir`.
- [معاونت پژوهش](https://journals.ihu.ac.ir/article_202002_60a2da5b996d804caaac5d6fb52071d8.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=ساختار; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۷. دانشگاه شاهد (`shahed`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://res.shahed.ac.ir](https://res.shahed.ac.ir).
- Official base domain: `shahed.ac.ir`.
- [گروه باغبانی - دانشکده علوم کشاورزی - دانشگاه شاهد](https://agri.shahed.ac.ir/educational-groups/department-of-gardening/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [دانشکده علوم کشاورزی – شعار سایت اینجا می آید - دانشگاه شاهد](https://agri.shahed.ac.ir/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [ورکشاپ نقاشی روی پارچه - دانشکده هنر - دانشگاه شاهد](https://art.shahed.ac.ir/%D9%88%D8%B1%DA%A9%D8%B4%D8%A7%D9%BE-%D9%86%D9%82%D8%A7%D8%B4%DB%8C-%D8%B1%D9%88%DB%8C-%D9%BE%D8%A7%D8%B1%DA%86%D9%87/) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [A Comparative Study of Research Evaluation Pattern in ...](https://rsci.shahed.ac.ir/article_5042_ba6d843eb4251a4526ce65d1807a9309.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [زیست شناسی سلولی و مولکولی - سایت - دانشگاه آزاد](https://sci.shahed.ac.ir/storage/sites/18/2023/11/%DA%A9%D8%A7%D8%B1%D8%B4%D9%86%D8%A7%D8%B3%DB%8C-%D8%B3%D9%84%D9%88%D9%84%DB%8C-%D9%88-%D9%85%D9%88%D9%84%DA%A9%D9%88%D9%84%DB%8C.pdf) — فقط سطح حداقلی URL/عنوان بازیابی شد; سطح رسمی وابسته دانشگاه; evidence=`supporting-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۰۸. دانشگاه صنعتی مالک اشتر (`malek-ashtar`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `mut.ac.ir`.
- Inspected page inventory: unresolved. No first-party page unambiguously identified as the institution's public R&T portal or research-office surface.

### ۱۰۹. دانشگاه تربیت دبیر شهید رجایی (`shahid-rajaee`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.sru.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/](https://www.sru.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/).
- Official base domain: `sru.ac.ir`.
- [مدیریت امور پژوهشی > آیین نامه ها](https://www.sru.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%AF%DB%8C%D8%B1%DB%8C%D8%AA-%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D8%A2%DB%8C%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7/) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [امور پایان نامه ها > آئین نامه ها](https://www.sru.ac.ir/%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%D8%A7%DB%8C%D8%A7%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D8%A2%D8%A6%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7/) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only`; dimensions=portal-related; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [آئین نامه ها و دستورالعمل ها](https://www.sru.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%DA%A9%D9%85%DB%8C%D8%AA%D9%87-%D8%A7%D8%AE%D9%84%D8%A7%D9%82-%D8%AF%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%87%D8%A7%DB%8C-%D8%B2%DB%8C%D8%B3%D8%AA-%D9%BE%D8%B2%D8%B4%DA%A9%DB%8C/%D8%A2%D8%A6%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7/) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، صنعت/فناوری، اسناد/فرم‌ها; document=`procedure/guideline` / `research ethics`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [مدیریت امور پژوهشی > فرم ها](https://www.sru.ac.ir/%D9%85%D8%AF%DB%8C%D8%B1%DB%8C%D8%AA-%D8%A7%D9%85%D9%88%D8%B1-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%81%D8%B1%D9%85-%D9%87%D8%A7/) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=ساختار، اسناد/فرم‌ها; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۱۰. دانشگاه فرماندهی و ستاد آجا (دافوس) (`aja-command`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۱۱۱. دانشگاه عالی دفاع ملی (`national-defense`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `sndu.ac.ir`.
- [[PDF] الگوی نظام حقوق دارائی های فکری جمهوری اسالمی ایران بارویکرد مدلسازی](https://smsnds.sndu.ac.ir/article_377_aad432bf816847768f6dc424d91a338c.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`form/template` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [[PDF] Research Article: Designing a Model for the Employment of ...](https://journals.sndu.ac.ir/article_3994_eceec3bbb392c45822e4ee9d02882820.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=portal-related; document=`document-file` / `general research governance`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [[PDF] توقیف داده و سامانه در جرایم امنیتی ؛ چالش ها و معیارها - امنیت ملی](https://ns.sndu.ac.ir/article_2612_21046f60b9fb3e2f9ee77d1a38c37eea.pdf) — محتوای صفحه بازیابی شد; دامنه رسمی؛ ریشه پژوهشی حل‌نشده; evidence=`discovery-only`; dimensions=IT نامزد، سامانه; document=`document-file` / `systems/data`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۱۲. دانشگاه علوم انتظامی امین (`amin-police`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۱۱۳. دانشگاه صنعت نفت (`petroleum`)

- Seed outcome: پرتال مستقیم تأییدشده.
- Seed: [https://www.put.ac.ir/fa-IR/put/4793/page/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%D9%8A](https://www.put.ac.ir/fa-IR/put/4793/page/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%D9%8A).
- Official base domain: `put.ac.ir`.
- [فرم‌ها و آیین‌نامه‌های اداره کل امور آموزشی - دانشگاه صنعت نفت](https://www.put.ac.ir/fa-IR/put/6709/page/%D9%81%D8%B1%D9%85%E2%80%8C%D9%87%D8%A7-%D9%88-%D8%A2%DB%8C%DB%8C%D9%86%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%A7%D8%AF%D8%A7%D8%B1%D9%87-%DA%A9%D9%84-%D8%A7%D9%85%D9%88%D8%B1-%D8%A2%D9%85%D9%88%D8%B2%D8%B4%DB%8C) — محتوای صفحه بازیابی شد; محدوده پرتال مرکزی; evidence=`dimension-candidate`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [فرم‌ها و آیین‌نامه‌های واحد تحصیلات تکمیلی - دانشگاه صنعت نفت](https://www.put.ac.ir/fa-IR/put/5709/page/%D9%81%D8%B1%D9%85%E2%80%8C%D9%87%D8%A7-%D9%88-%D8%A2%DB%8C%DB%8C%D9%86%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C-%D9%88%D8%A7%D8%AD%D8%AF-%D8%AA%D8%AD%D8%B5%DB%8C%D9%84%D8%A7%D8%AA-%D8%AA%DA%A9%D9%85%DB%8C%D9%84%DB%8C) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری، اسناد/فرم‌ها; document=`regulation/bylaw` / `industry/technology/IP`; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.
- [پایان‌نامه‌ها - دانشگاه صنعت نفت](https://www.put.ac.ir/fa-IR/put/6275/page/%D9%BE%D8%A7%DB%8C%D8%A7%D9%86%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7) — فقط سطح حداقلی URL/عنوان بازیابی شد; محدوده پرتال مرکزی; evidence=`discovery-only-minimal-retrieval`; dimensions=صنعت/فناوری; HTTP=`unknown`; observed=`2026-08-11T00:00:00Z`.

### ۱۱۴. دانشگاه صدا و سیمای جمهوری اسلامی ایران (`irib`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

### ۱۱۵. مرکز آموزش عالی هوانوردی و فرودگاهی کشور (`civil-aviation`)

- Seed outcome: seed تأییدشده ندارد.
- Seed: —.
- Official base domain: `—`.
- Inspected page inventory: unresolved. No official university domain and no first-party R&T seed were confirmed in this pass.

## Genuine blockers and unresolved scope

- **۵۴ institutions have no confirmed first-party R&T seed.** A crawler cannot honestly claim full portal coverage for them. Their search attempts and candidate URLs are preserved in `data/evidence/research-portal-seeds-115.json`.
- Direct `curl`/HTTP checks in this environment reached an intermediary proxy and returned 502 for tested Iranian university hosts. Consequently HTTP 200/3xx/4xx/5xx, TLS, robots, and timeout causes cannot be reliably separated here.
- Of the ۳۲۸ submitted URLs, ۲۱۱ exposed only a one-line retrieval surface. They remain discovery-grade and do not verify dimensions.
- Search indexing is incomplete and biased. The URL inventory is a bounded inspected set, not a complete traversal of every internal link.
- Several universities publish research material on the main institutional site without a distinct R&T subdomain. These are marked as research-surface seeds rather than portal-home seeds.
- Documents behind JavaScript, authentication, CAPTCHA, non-indexed download handlers, or broken legacy CMS links can remain unresolved.

## Machine-readable files

- `data/evidence/research-portal-seeds-115.json` — 115 seed outcomes plus discovery sources.
- `data/evidence/deep-portal-discovery-115.json` — exact inspected URLs, access semantics, scope, dimensions, and document taxonomy.
- `data/evidence/deep-portal-root-candidates.json` — raw root-discovery candidates; third-party entries are discovery-only and must never be scored.

