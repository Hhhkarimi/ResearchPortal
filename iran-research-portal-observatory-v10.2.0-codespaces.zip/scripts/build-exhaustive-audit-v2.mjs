import fs from "node:fs/promises";

const DIMENSIONS = [
  "portalIdentity",
  "organization",
  "libraryDocuments",
  "laboratories",
  "industryTechnology",
  "informationTechnology",
  "systemsServices",
  "documentsRegulations",
];

const LABELS = {
  portalIdentity: "پرتال پژوهش و فناوری",
  organization: "ساختار سازمانی معاونت",
  libraryDocuments: "کتابخانه/مرکز اسناد دانشگاهی",
  laboratories: "آزمایشگاه‌ها",
  industryTechnology: "ارتباط با صنعت و فناوری",
  informationTechnology: "فناوری اطلاعاتِ دارای رابطه سازمانی",
  systemsServices: "سامانه‌ها و خدمات",
  documentsRegulations: "فرم‌ها، آیین‌نامه‌ها و دستورالعمل‌ها",
};

const SPECIFIC = {
  organization: /نمودار\s*سازمانی|چارت\s*سازمانی|ساختار\s*سازمانی|معرفی\s*معاونت|درباره\s*معاونت|معاون\s*پژوهش|کارکنان\s*معاونت|واحدهای\s*تابعه|organizational\s*(?:chart|structure)|about\s*(?:the\s*)?(?:vice|research)/i,
  libraryDocuments: /کتابخانه\s*مرکزی|مرکز\s*اسناد|کتابخانه\s*و\s*نشر|انتشارات\s*دانشگاه|مدیریت\s*اطلاعات\s*علمی|central\s*library|documentation\s*cent(?:er|re)|university\s*press/i,
  laboratories: /آزمایشگاه\s*مرکزی|شبکه\s*آزمایشگاهی|آزمایشگاه\s*تخصصی|مرکز\s*آزمایشگاه|تجهیزات\s*آزمایشگاهی|central\s*lab|laboratory\s*network/i,
  industryTechnology: /ارتباط\s*(?:با\s*)?(?:جامعه\s*و\s*)?صنعت|صنعت\s*و\s*جامعه|مدیریت\s*فناوری|مرکز\s*رشد|پارک\s*علم\s*و\s*فناوری|مالکیت\s*فکری|ثبت\s*اختراع|واحدهای\s*پژوهش\s*و\s*فناوری|هسته\s*های\s*فناور|شرکت\s*های\s*دانش.?بنیان|industry\s*relations?|technology\s*transfer|innovation\s*cent(?:er|re)|incubat|intellectual\s*property/i,
  informationTechnology: /مدیریت\s*توسعه\s*فناوری\s*اطلاعات|مرکز\s*فناوری\s*اطلاعات|مرکز\s*فاوا|مرکز\s*آمار\s*و\s*فناوری|information\s*technology|\bICT\b/i,
  systemsServices: /سامانه.{0,40}(?:پژوهش|تحقیق|اخلاق|نشریات|پروژه)|پژوهشیار|سامانه\s*مدیریت\s*امور\s*پژوهشی|سامانه\s*پروژه\s*های\s*تحقیق|سامانه\s*گلستان|research\s*(?:management\s*)?system/i,
  documentsRegulations: /فرم|آیین.?نامه|شیوه.?نامه|دستورالعمل|بخشنامه|مقررات|قوانین|راهنما|مصوبات|فرآیند|form|regulation|bylaw|guideline|procedure|circular/i,
};

const RESEARCH_RELATION = /معاونت.{0,25}(?:پژوهش|تحقیق|فناور)|امور\s*پژوهش|پژوهش\s*و\s*فناوری|ارتباط\s*(?:با\s*)?(?:جامعه\s*و\s*)?صنعت|research|technology|innovation|industry|\/res(?:earch)?(?:\/|\.|$)|\/vpr(?:\/|\.|$)|\/vr(?:\/|\.|$)|\/mrt(?:\/|\.|$)/i;
const IT_RELATION = /معاونت.{0,40}(?:پژوهش|تحقیق|فناور)|زیر\s*نظر.{0,40}معاونت|وابسته\s*به.{0,40}معاونت|واحدهای\s*تابعه|under.{0,40}research|managed\s*by.{0,40}research/i;

// Primary-source URLs found in the V2 follow-up pass. They remain observed
// until a contentful crawler run records response metadata and a content hash.
const SUPPLEMENTAL = {
  ardakan: {
    officialBaseDomain: "ardakan.ac.ir",
    portalIdentity: [{title: "پرتال پژوهش دانشگاه اردکان", url: "https://research.ardakan.ac.ir/en/"}],
    organization: [{title: "سطح آموزش و پژوهش دانشگاه اردکان", url: "https://edures.ardakan.ac.ir/en/"}],
    documentsRegulations: [{title: "آیین‌نامه‌های داخلی پژوهش دانشگاه اردکان", url: "https://research.ardakan.ac.ir/en/%D8%A2%DB%8C%DB%8C%D9%86%E2%80%8C%D9%86%D8%A7%D9%85%D9%87%E2%80%8C%D9%87%D8%A7%DB%8C-%D8%AF%D8%A7%D8%AE%D9%84%DB%8C"}],
  },
  "ayatollah-borujerdi": {
    officialBaseDomain: "abru.ac.ir",
    organization: [{title: "مدیران پژوهش و فناوری دانشگاه آیت‌الله بروجردی", url: "https://abru.ac.ir/%D9%85%D8%AF%DB%8C%D8%B1%D8%A7%D9%86-%D9%BE%DA%98%D9%88%D9%87%D8%B4-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/"}],
    industryTechnology: [{title: "ارتباط با صنعت دانشگاه آیت‌الله بروجردی", url: "https://abru.ac.ir/industry/"}],
  },
  kurdistan: {organization: [{title: "نمودار سازمانی معاونت پژوهش و نوآوری دانشگاه کردستان", url: "https://uok.ac.ir/web/research-and-innovation/organizational-chart"}]},
  sharif: {organization: [{title: "چارت سازمانی معاونت پژوهش و فناوری دانشگاه صنعتی شریف", url: "https://research.sharif.ir/%DA%86%D8%A7%D8%B1%D8%AA-%D8%B3%D8%A7%D8%B2%D9%85%D8%A7%D9%86"}]},
  "isfahan-technology": {organization: [{title: "ساختار معاونت پژوهش و فناوری دانشگاه صنعتی اصفهان", url: "https://research.iut.ac.ir/fa/tico/1735"}]},
  bojnord: {libraryDocuments: [{title: "تازه‌های نشر کتابخانه مرکزی دانشگاه بجنورد", url: "https://lib.ub.ac.ir/تازه-های-نشر"}]},
  "sistan-baluchestan": {
    organization: [{title: "معرفی معاونت پژوهشی و فناوری دانشگاه سیستان و بلوچستان", url: "https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C/%D9%85%D8%B9%D8%B1%D9%81%DB%8C-%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA"}],
    libraryDocuments: [{title: "معرفی مرکز اسناد و کتابخانه مرکزی دانشگاه سیستان و بلوچستان", url: "https://www.usb.ac.ir/%D9%85%D8%B1%DA%A9%D8%B2-%D8%A7%D8%B3%D9%86%D8%A7%D8%AF-%D9%88-%DA%A9%D8%AA%D8%A7%D8%A8%D8%AE%D8%A7%D9%86%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87-%DA%A9%D8%AA%D8%A7%D8%A8%D8%AE%D8%A7%D9%86%D9%87/%D9%85%D8%B9%D8%B1%D9%81%DB%8C"}],
    laboratories: [{title: "ثبت درخواست آنالیز آزمایشگاه مرکزی دانشگاه سیستان و بلوچستان", url: "https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D8%A2%D8%B2%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%A7%D9%87-%D9%85%D8%B1%DA%A9%D8%B2%DB%8C/%D8%AB%D8%A8%D8%AA-%D8%AF%D8%B1%D8%AE%D9%88%D8%A7%D8%B3%D8%AA-%D8%A2%D9%86%D8%A7%D9%84%DB%8C%D8%B2"}],
    documentsRegulations: [
      {title: "آیین‌نامه‌ها و دستورالعمل‌های ارتباط با صنعت دانشگاه سیستان و بلوچستان", url: "https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D8%AF%D9%81%D8%AA%D8%B1-%D8%A7%D8%B1%D8%AA%D8%A8%D8%A7%D8%B7-%D8%A8%D8%A7-%D8%B5%D9%86%D8%B9%D8%AA/-%D8%A2%D8%A6%DB%8C%D9%86-%D9%86%D8%A7%D9%85%D9%87-%D9%87%D8%A7-%D9%88-%D8%AF%D8%B3%D8%AA%D9%88%D8%B1%D8%A7%D9%84%D8%B9%D9%85%D9%84-%D9%87%D8%A7"},
      {title: "فرم‌های پسادکتری دانشگاه سیستان و بلوچستان", url: "https://www.usb.ac.ir/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%87%D8%A7/%D9%85%D8%B9%D8%A7%D9%88%D9%86%D8%AA-%D9%BE%DA%98%D9%88%D9%87%D8%B4%DB%8C-%D9%88-%D9%81%D9%86%D8%A7%D9%88%D8%B1%DB%8C/%D9%BE%D8%B3%D8%A7-%D8%AF%DA%A9%D8%AA%D8%B1%DB%8C/%D9%81%D8%B1%D9%85-%D9%87%D8%A7"},
    ],
  },
};

const compact = (value) => String(value || "").replace(/\s+/g, " ").trim();
const safeDecode = (value) => {
  try { return decodeURIComponent(value); } catch { return value; }
};
const hostOf = (value) => {
  try { return new URL(value).hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; }
};
const officialFor = (url, baseDomain) => {
  const host = hostOf(url);
  const base = String(baseDomain || "").toLowerCase().replace(/^www\./, "");
  return Boolean(base) && (host === base || host.endsWith(`.${base}`));
};
const isRoot = (url) => {
  try { return new URL(url).pathname.replace(/\/+$/, "") === ""; } catch { return false; }
};
const sourceKey = (source) => source.url;
const unique = (sources) => [...new Map(sources.map((source) => [sourceKey(source), source])).values()];

function portalEvidence(seed) {
  if (!seed?.seedUrl) return [];
  const verified = seed.outcome === "confirmed-direct-portal" && seed.access === "previously-verified-official";
  return [{
    title: "پرتال/سطح رسمی پژوهش و فناوری",
    url: seed.seedUrl,
    status: verified ? "verified" : "observed",
    observedAt: seed.observedAt,
    access: seed.access,
    scope: verified ? "official-research-portal" : "official-research-surface",
    sourceBasis: verified ? "previously-directly-verified-first-party" : "first-party-discovery",
    note: verified
      ? "هویت پرتال در ممیزی پیشین مستقیماً تأیید شده است؛ ریشه به‌تنهایی سایر ابعاد را تأیید نمی‌کند."
      : "سطح پژوهشی رسمی برای کشف مشاهده شد اما هویت پرتال مستقل ادعا نمی‌شود.",
  }];
}

function pageEvidence(page, dimension, institution) {
  const urlText = safeDecode(page.url);
  const text = compact(`${page.title} ${urlText}`);
  if (!SPECIFIC[dimension]?.test(text)) return null;
  if (!officialFor(page.url, institution.baseDomain)) return null;
  if (isRoot(page.url)) return null;

  const portalHost = hostOf(institution.portalRoot);
  const pageHost = hostOf(page.url);
  const central = pageHost === portalHost && page.scope === "central-portal";
  const baseHost = String(institution.baseDomain || "").toLowerCase().replace(/^www\./, "");
  const portalPath = (() => {
    try { return safeDecode(new URL(institution.portalRoot).pathname); } catch { return ""; }
  })();
  const pagePath = (() => {
    try { return safeDecode(new URL(page.url).pathname); } catch { return ""; }
  })();
  const portalMarker = portalPath.match(/^(.+?\/(?:research|res|vr|vpr|prt))(?:\/|$)/i)?.[1];
  const firstPortalSegment = `/${portalPath.split("/").filter(Boolean)[0] || ""}`;
  const localizedPortalPrefix = RESEARCH_RELATION.test(portalPath) ? firstPortalSegment : null;
  const insidePathPortal = central && (
    (portalMarker && pagePath.startsWith(portalMarker)) ||
    (localizedPortalPrefix && pagePath.startsWith(localizedPortalPrefix))
  );
  const dedicatedPortalHost = central && portalHost && portalHost !== baseHost;
  const subdomain = pageHost === baseHost ? "" : pageHost.slice(0, -(baseHost.length + 1));
  const specializedInstitutionalHost = /^(?:research|res|vpr|vr|research-affairs|relation|industry|technology|tech|tem|tto|innovation|roshd|library|lib|centrallab|lab)(?:\.|$)/i.test(subdomain);
  const relation = Boolean(dedicatedPortalHost || insidePathPortal || RESEARCH_RELATION.test(text));
  const itRelation = dimension !== "informationTechnology" || (relation && IT_RELATION.test(text));
  const directlyOpened = page.access === "web-opened-content";
  const institutionalAnchor = Boolean(dedicatedPortalHost || insidePathPortal || specializedInstitutionalHost);
  const verified = directlyOpened && relation && itRelation && institutionalAnchor;

  return {
    title: page.title,
    url: page.url,
    status: verified ? "verified" : "observed",
    observedAt: page.openedAt || page.observedAt,
    access: page.access,
    scope: central ? "central-research-portal" : "official-university-domain-or-subdomain",
    sourceBasis: verified ? "dimension-specific-first-party-content" : "dimension-specific-first-party-discovery",
    note: verified
      ? "صفحهٔ اختصاصی این بُعد با محتوای قابل‌بازیابی و رابطهٔ پژوهشی روشن مشاهده شد."
      : dimension === "informationTechnology" && !itRelation
        ? "صفحهٔ فناوری اطلاعات رسمی است، اما رابطهٔ سازمانی آن با معاونت پژوهش اثبات نشد."
        : "URL رسمی و اختصاصی مشاهده شد، اما محتوای کافی یا رابطهٔ مستقیم با حوزهٔ پژوهش برای تأیید کامل بازیابی نشد.",
  };
}

function manualEvidence(manual, dimension, observedAt) {
  return (manual?.evidence || []).filter((source) => source.dimension === dimension).map((source) => ({
    title: source.title,
    url: source.url,
    status: "observed",
    observedAt,
    access: manual.accessResult === "cloud-egress-502" ? "direct-http-restricted-by-audit-environment" : "manual-first-party-reference",
    scope: "official-university-domain-or-subdomain",
    sourceBasis: "project-owner-first-party-url",
    note: isRoot(source.url)
      ? "زیردامنهٔ رسمیِ اختصاصی مشاهده شد؛ طبق قاعدهٔ ممیزی، ریشهٔ دامنه به‌تنهایی verified نمی‌شود."
      : "مسیر رسمی اختصاصی ثبت شد؛ تا بازیابی محتوایی موفق توسط crawler، observed باقی می‌ماند.",
  }));
}

function supplementalEvidence(slug, dimension, observedAt) {
  return (SUPPLEMENTAL[slug]?.[dimension] || []).map((source) => ({
    ...source,
    status: "observed",
    observedAt,
    access: "primary-source-web-discovery",
    scope: "official-university-domain-or-subdomain",
    sourceBasis: "dimension-specific-first-party-discovery",
    note: "URL منبع‌اول اختصاصی در بازبینی تکمیلی کشف شد؛ تا بازیابی محتوایی مستقیم snapshot به‌صورت observed نگه داشته شده است.",
  }));
}

function dimensionOutcome(dimension, sources, seed) {
  const verified = sources.filter((source) => source.status === "verified");
  const observed = sources.filter((source) => source.status === "observed");
  if (verified.length) return {
    status: "verified",
    reason: dimension === "portalIdentity"
      ? "هویت پرتال مستقیم پژوهش و فناوری در ممیزی first-party پیشین تأیید شده است؛ این تأیید به سایر ابعاد تسری نمی‌یابد."
      : "حداقل یک صفحهٔ اختصاصی first-party با محتوای قابل‌بازیابی و رابطهٔ پژوهشی روشن ثبت شد.",
    evidence: unique([...verified, ...observed]),
  };
  if (observed.length) return {
    status: "observed",
    reason: "URL رسمی مرتبط مشاهده شد، اما شواهد برای تأیید محتوایی کامل کافی نبود.",
    evidence: unique(observed),
  };
  const noSeed = !seed?.seedUrl;
  return {
    status: "unresolved",
    reason: noSeed
      ? "seed قطعی پرتال/سطح پژوهشی برای آغاز ممیزی صفحه‌به‌صفحه حل نشد؛ نبود شاهد به معنی نبود خدمت نیست."
      : "در منابع عمومی بازیابی‌شده، صفحهٔ اختصاصی کافی برای این بُعد پیدا نشد؛ نبود شاهد به معنی نبود خدمت نیست.",
    evidence: [],
  };
}

function statusCell(outcome) {
  const marks = {verified: "تأیید", observed: "مشاهده", restricted: "محدود", unresolved: "حل‌نشده"};
  return marks[outcome.status];
}

function markdown(report) {
  const lines = [
    "# ممیزی فراگیر ۱۱۵ پرتال پژوهش و فناوری — نسخهٔ ۲",
    "",
    `زمان تولید: ${report.generatedAt}`,
    "",
    "این snapshot به‌صورت evidence-first ساخته شده است. واحد تحلیل، پرتال معاونت پژوهش و فناوری و صفحات رسمی مرتبط دانشگاه است؛ ریشهٔ یک سایت به‌تنهایی هیچ بُعدی جز هویت پرتال را تأیید نمی‌کند. زیردامنه‌های رسمی همان دانشگاه فقط وقتی پذیرفته می‌شوند که URL/عنوان اختصاصی بُعد و رابطهٔ دانشگاهی روشن باشد. وضعیت «حل‌نشده» به معنی نبود خدمت نیست.",
    "",
    "## وضعیت پوشش",
    "",
    `- دانشگاه‌ها: ${report.summary.institutions}`,
    `- outcomeهای بُعدی تأییدشده: ${report.summary.dimensionStatuses.verified}`,
    `- outcomeهای مشاهده‌شده: ${report.summary.dimensionStatuses.observed}`,
    `- outcomeهای محدود: ${report.summary.dimensionStatuses.restricted}`,
    `- outcomeهای حل‌نشده: ${report.summary.dimensionStatuses.unresolved}`,
    `- URLهای evidence یکتا: ${report.summary.uniqueEvidenceUrls}`,
    `- دانشگاه‌های آمادهٔ انتشار زیر گیت سخت V2: ${report.summary.rankingEligible} (این گیت پژوهشیِ سخت‌گیرانه مستقل از گیت production در RTPMI 4.1 است)`,
    "",
    "## قواعد روش",
    "",
    "1. فقط دامنهٔ رسمی دانشگاه و زیردامنه‌های first-party آن پذیرفته شده‌اند.",
    "2. صفحهٔ home/root به‌تنهایی برای ساختار، کتابخانه، آزمایشگاه، صنعت، IT، سامانه یا اسناد verified نمی‌شود.",
    "3. verified نیازمند صفحهٔ اختصاصی، محتوای قابل‌بازیابی و رابطهٔ پژوهشی روشن است؛ web-index یا URL بدون محتوای کافی observed است.",
    "4. IT فقط با شاهد رابطهٔ سازمانی با معاونت پژوهش قابل تأیید است.",
    "5. رتبه‌بندی تنها پس از عبور از گیت هویت مستقیم پرتال، حداقل ۷۵٪ پوشش و حداقل شش بُعد verified مجاز است؛ unresolved صفر علمی دانشگاه نیست.",
    "",
    "## ماتریس ۱۱۵ دانشگاه",
    "",
    "| ردیف | دانشگاه | پرتال | ساختار | کتابخانه | آزمایشگاه | صنعت/فناوری | IT | سامانه | اسناد | گیت رتبه‌بندی |",
    "|---:|---|---|---|---|---|---|---|---|---|---|",
  ];

  for (const row of report.outcomes) {
    const d = row.dimensions;
    lines.push(`| ${row.row} | ${row.nameFa} | ${statusCell(d.portalIdentity)} | ${statusCell(d.organization)} | ${statusCell(d.libraryDocuments)} | ${statusCell(d.laboratories)} | ${statusCell(d.industryTechnology)} | ${statusCell(d.informationTechnology)} | ${statusCell(d.systemsServices)} | ${statusCell(d.documentsRegulations)} | ${row.ranking.eligible ? "مجاز" : "غیرمجاز"} |`);
  }

  lines.push("", "## evidenceهای URLمحور", "");
  for (const row of report.outcomes) {
    lines.push(`### ${row.row}. ${row.nameFa}`, "");
    lines.push(`- دامنهٔ رسمی: ${row.officialBaseDomain || "حل‌نشده"}`);
    lines.push(`- نتیجهٔ ممیزی: ${row.auditStatus}`);
    lines.push(`- رتبه‌بندی: ${row.ranking.eligible ? `مجاز؛ امتیاز شفافیت ${row.ranking.evidenceScore}` : `غیرمجاز — ${row.ranking.reason}`}`);
    for (const dimension of DIMENSIONS) {
      const outcome = row.dimensions[dimension];
      if (!outcome.evidence.length) {
        lines.push(`- ${LABELS[dimension]} — ${statusCell(outcome)}: ${outcome.reason}`);
        continue;
      }
      lines.push(`- ${LABELS[dimension]} — ${statusCell(outcome)}:`);
      for (const source of outcome.evidence) lines.push(`  - [${source.title}](${source.url}) — ${source.status}؛ مشاهده: ${source.observedAt}`);
    }
    lines.push("");
  }
  return `${lines.join("\n")}\n`;
}

async function main() {
  const [institutions, discovery, seeds, manualRegistry] = await Promise.all([
    fs.readFile("data/isc/institutions.json", "utf8").then(JSON.parse),
    fs.readFile("data/evidence/deep-portal-discovery-115.json", "utf8").then(JSON.parse),
    fs.readFile("data/evidence/research-portal-seeds-115.json", "utf8").then(JSON.parse),
    fs.readFile("data/evidence/manual-evidence-overrides.json", "utf8").then(JSON.parse).catch(() => ({institutions: []})),
  ]);
  const discoveryBySlug = new Map(discovery.institutions.map((item) => [item.slug, item]));
  const seedBySlug = new Map(seeds.institutions.map((item) => [item.slug, item]));
  const manualBySlug = new Map((manualRegistry.institutions || []).map((item) => [item.slug, item]));
  const generatedAt = manualRegistry.observedAt || discovery.observedAt || new Date().toISOString();

  const outcomes = institutions.map((institution, index) => {
    const found = discoveryBySlug.get(institution.slug) || {};
    const seed = seedBySlug.get(institution.slug);
    const manual = manualBySlug.get(institution.slug);
    const baseDomain = found.baseDomain || seed?.officialBaseDomain || manual?.officialBaseDomain || SUPPLEMENTAL[institution.slug]?.officialBaseDomain || null;
    const supplementalPortal = SUPPLEMENTAL[institution.slug]?.portalIdentity?.[0]?.url || null;
    const portalRoot = found.portalRoot || seed?.seedUrl || supplementalPortal || null;
    const scope = {...found, baseDomain, portalRoot};
    const dimensions = {};

    for (const dimension of DIMENSIONS) {
      const sources = dimension === "portalIdentity" ? portalEvidence(seed) : [];
      if (dimension !== "portalIdentity") {
        for (const page of found.pages || []) {
          const source = pageEvidence(page, dimension, scope);
          if (source) sources.push(source);
        }
        sources.push(...manualEvidence(manual, dimension, generatedAt));
      }
      sources.push(...supplementalEvidence(institution.slug, dimension, generatedAt));
      dimensions[dimension] = dimensionOutcome(dimension, sources, seed);
    }

    const statuses = Object.values(dimensions).map((item) => item.status);
    const verifiedCount = statuses.filter((status) => status === "verified").length;
    const observedCount = statuses.filter((status) => status === "observed").length;
    const inspectedCount = verifiedCount + observedCount;
    const coverage = Math.round((inspectedCount / DIMENSIONS.length) * 100);
    const evidenceScore = Math.round((verifiedCount * 1 + observedCount * 0.35) / DIMENSIONS.length * 1000) / 10;
    const eligible = dimensions.portalIdentity.status === "verified" && coverage >= 75 && verifiedCount >= 6;
    const auditStatus = verifiedCount > 1 ? "verified" : inspectedCount ? "observed" : "unresolved";

    return {
      row: index + 1,
      slug: institution.slug,
      nameFa: institution.nameFa,
      iscCategory: institution.category,
      iscRank: institution.iscRank,
      officialBaseDomain: baseDomain,
      portalRoots: portalRoot ? [portalRoot] : [],
      observedAt: generatedAt,
      auditStatus,
      dimensions,
      ranking: {
        eligible,
        eligibilityProfile: "strict-exhaustive-v2-six-verified-dimensions",
        evidenceCoverage: coverage,
        verifiedDimensions: verifiedCount,
        observedDimensions: observedCount,
        evidenceScore,
        scoreMeaning: "امتیاز بلوغ و شفافیت evidenceهای پرتال؛ نه کیفیت علمی دانشگاه",
        reason: eligible
          ? "گیت سخت هویت مستقیم پرتال، پوشش و حداقل ابعاد verified عبور شد."
          : "گیت سخت رتبه‌بندی عبور نکرد؛ امتیاز evidence برای تشخیص شکاف نمایش داده می‌شود و رتبه عمومی نیست.",
      },
    };
  });

  if (outcomes.length !== 115) throw new Error(`Expected exactly 115 outcomes, received ${outcomes.length}`);
  const allDimensionOutcomes = outcomes.flatMap((item) => Object.values(item.dimensions));
  const dimensionStatuses = Object.fromEntries(["verified", "observed", "restricted", "unresolved"].map((status) => [status, allDimensionOutcomes.filter((item) => item.status === status).length]));
  const uniqueEvidenceUrls = new Set(allDimensionOutcomes.flatMap((item) => item.evidence.map((source) => source.url))).size;
  const report = {
    schemaVersion: "2.0.0",
    auditKind: "exhaustive-first-party-research-portal-audit-115-v2",
    methodologyVersion: "RTPMI-4.3-cross-subdomain-evidence-gate",
    generatedAt,
    sourceSnapshotObservedAt: discovery.observedAt,
    semantics: {
      scope: "Official university domain plus relevant first-party subdomains linked/discovered from official research surfaces.",
      verified: "A dimension-specific first-party page was contentfully retrieved and its research relationship was explicit.",
      observed: "A dimension-specific first-party URL was observed, but content or organizational relationship was insufficient for full verification.",
      restricted: "A relevant page was attempted but public access was blocked; this status is not inferred merely from no discovery.",
      unresolved: "No sufficient public evidence was retrieved; this is not proof of absence.",
      rootRule: "Home/root pages alone never verify a dimension other than previously confirmed portal identity.",
      itRule: "Information Technology is verified only when an organizational relationship to the Research & Technology vice-chancellery is explicit.",
      rankingInterpretation: "RTPMI measures portal maturity and transparency only, never scientific quality.",
      eligibilityProfile: "The V2 research-audit report uses an additional six-verified-dimension readiness gate. It is deliberately stricter than, and does not replace, the production RTPMI 4.1 publication gate.",
    },
    auditLimitations: [
      "Direct HTTP access to Iranian university hosts returned intermediary 502 responses in this audit environment.",
      "Search-indexed/minimal retrieval is retained as observed rather than promoted to verified.",
      "This snapshot records exact evidence URLs but does not assert that unresolved dimensions do not exist.",
    ],
    summary: {
      institutions: outcomes.length,
      dimensionOutcomes: allDimensionOutcomes.length,
      dimensionStatuses,
      uniqueEvidenceUrls,
      rankingEligible: outcomes.filter((item) => item.ranking.eligible).length,
    },
    outcomes,
  };

  await fs.mkdir("data/evidence", {recursive: true});
  await fs.mkdir("docs", {recursive: true});
  await fs.writeFile("data/evidence/exhaustive-portal-audit-115-v2.json", `${JSON.stringify(report, null, 2)}\n`);
  await fs.writeFile("docs/EXHAUSTIVE_PORTAL_AUDIT_115_V2.md", markdown(report));
  console.log(JSON.stringify(report.summary, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
