/** Import a completed deep-crawl snapshot into the versioned evidence sources. */
import fs from "node:fs/promises";

const CRAWL_PATH="data/crawl/deep-portal-crawl.json";
const read=async file=>JSON.parse(await fs.readFile(file,"utf8"));
const write=async(file,value)=>fs.writeFile(file,JSON.stringify(value,null,2)+"\n");
const validUrl=value=>{try{return ["http:","https:"].includes(new URL(value).protocol)}catch{return false}};
const canonical=value=>{const url=new URL(value);url.hash="";url.hostname=url.hostname.toLowerCase();if(url.pathname.length>1)url.pathname=url.pathname.replace(/\/+$/g,"");return url.toString()};
const uniqueByUrl=items=>[...items.reduce((map,item)=>{if(item?.url&&validUrl(item.url)&&!map.has(canonical(item.url)))map.set(canonical(item.url),item);return map},new Map()).values()];
const dimensionKeys={portalIdentity:"portalUrls",organization:"organizationUrls",libraryDocuments:"libraryUrls",laboratories:"laboratoryUrls",industryTechnology:"industryTechnologyUrls",informationTechnology:"informationTechnologyUrls",systemsServices:"systemsUrls",documentsRegulations:"documentIndexUrls"};
const unitTypes={organization:"research",libraryDocuments:"library",laboratories:"laboratory",industryTechnology:"technology",informationTechnology:"it"};
const systemCategories={"اخلاق پژوهش":"research","حمایت و گرنت":"research","انتشارات و نشریات":"journals","آزمایشگاه":"laboratory","صنعت، فناوری و مالکیت فکری":"innovation","تحصیلات تکمیلی و امور پژوهشی":"research","سایر":"research"};
const taxonomyOf=type=>type==="آیین‌نامه"?"regulation/bylaw":["شیوه‌نامه","دستورالعمل","راهنما","فرآیند"].includes(type)?"procedure/guideline":type==="فرم"?"form/template":type==="بخشنامه"?"policy/circular":"other";
const strength={unresolved:0,restricted:1,"observed-reference":2,verified:3};

const crawl=await fs.readFile(CRAWL_PATH,"utf8").then(JSON.parse).catch(()=>null);
if(!crawl){console.log("deep crawl import: no snapshot; legacy evidence retained");process.exit(0)}
if(crawl.schemaVersion!==1||!Array.isArray(crawl.universities))throw new Error("Unsupported deep crawl snapshot");
const [institutions,audits,reviews,reaudit,units,systems,documents]=await Promise.all([
  read("data/isc/institutions.json"),read("data/audit/portal-audit.json"),read("data/evidence/research-review.json"),read("data/evidence/portal-document-reaudit.json"),read("data/units/catalog.json"),read("data/systems/catalog.json"),read("data/documents/catalog.json")
]);
const validSlugs=new Set(institutions.map(item=>item.slug));const crawlBySlug=new Map();
for(const result of crawl.universities){if(!validSlugs.has(result.universitySlug))throw new Error(`Deep crawl outside ISC scope: ${result.universitySlug}`);if(crawlBySlug.has(result.universitySlug))throw new Error(`Duplicate deep crawl result: ${result.universitySlug}`);for(const dimension of Object.keys(dimensionKeys))if(!result.evidence?.[dimension])throw new Error(`Missing deep crawl dimension ${result.universitySlug}:${dimension}`);crawlBySlug.set(result.universitySlug,result)}
const audited=[...crawlBySlug.values()].filter(result=>result.pagesFetched>0&&result.seedUrls?.length);const auditedSlugs=new Set(audited.map(result=>result.universitySlug));const fullyRebuiltSlugs=new Set(audited.filter(result=>result.crawlStatus==="complete"&&result.scopeComplete).map(result=>result.universitySlug));
const snapshotDate=String(crawl.generatedAt||new Date().toISOString()).slice(0,10);

const nextReaudit=reaudit.map(row=>{
  const result=crawlBySlug.get(row.slug);if(!result||!result.pagesFetched)return row;const next={...row};
  for(const [dimension,key] of Object.entries(dimensionKeys)){const sources=result.evidence[dimension]?.sources||[];next[key]=[...new Set([...(dimension==="portalIdentity"?(result.seedUrls||[]):[]),...sources.map(source=>source.url)].filter(validUrl))]}
  next.directDocuments=(result.documents||[]).filter(item=>item.ok).map(item=>({title:item.title,url:item.finalUrl||item.url,taxonomy:taxonomyOf(item.type),type:item.type,topic:item.topic,parentUrl:item.parentUrl,status:item.status,lastVerified:item.lastVerified}));
  next.deepCrawl={status:result.crawlStatus,scopeComplete:result.scopeComplete,pagesFetched:result.pagesFetched,pagesDiscovered:result.pagesDiscovered,documentsFound:result.documentsFound,systemsFound:result.systemsFound,completedAt:result.completedAt};return next;
});

const nextAudits=audits.map(audit=>{
  const result=crawlBySlug.get(audit.universitySlug);if(!result||!result.pagesFetched)return audit;const portal=result.evidence.portalIdentity;const evidenceUrls=[...new Set(Object.values(result.evidence).flatMap(outcome=>outcome.sources||[]).map(source=>source.url).filter(validUrl))];
  return{...audit,auditDate:snapshotDate,portalAuditStatus:portal.status==="verified"?"direct-official":audit.portalAuditStatus,researchUrl:portal.status==="verified"?(result.seedUrls[0]||audit.researchUrl):audit.researchUrl,evidenceUrls,note:`خزیدن عمیق ${result.pagesFetched} صفحه در محدوده پرتال رسمی انجام شد (${result.crawlStatus}). هر بُعد فقط با صفحه یا فایل اختصاصی تأیید می‌شود.`,deepCrawlStatus:result.crawlStatus,deepCrawlCompletedAt:result.completedAt};
});

const nextReviews=reviews.map(review=>{
  const result=crawlBySlug.get(review.universitySlug);if(!result||!result.pagesFetched)return review;const previous=review.dimensions||{};const dimensions={};
  for(const dimension of Object.keys(dimensionKeys)){const crawled=result.evidence[dimension].status;dimensions[dimension]=result.scopeComplete?crawled:(strength[crawled]>=strength[previous[dimension]||"unresolved"]?crawled:previous[dimension])}
  const officialSources=uniqueByUrl(Object.entries(result.evidence).flatMap(([dimension,outcome])=>(outcome.sources||[]).map(source=>({label:`${dimension}: ${source.title||source.snippet||"منبع رسمی"}`,url:source.url,dimension,verificationStatus:source.status||outcome.status,lastVerified:source.fetchedAt||result.completedAt}))));
  const verified=Object.values(dimensions).filter(value=>value==="verified").length,observed=Object.values(dimensions).filter(value=>value==="observed-reference").length;
  return{...review,reviewedAt:result.completedAt,reviewOutcome:`خزیدن عمیق ${result.pagesFetched} صفحه و ${result.documentsFound} فایل در محدوده پرتال رسمی انجام شد.`,dimensions,reportedDimensions:dimensions,reviewEvidenceCoverage:Math.round(100*(verified+.5*observed)/8),reviewCompletion:100,officialSources,officialSourceUrls:officialSources.map(source=>source.url),reviewNote:`صف تا انتهای لینک‌های عمومی هم‌دامنه/هم‌مسیر پیمایش شد؛ وضعیت ${result.crawlStatus} و کامل‌بودن محدوده ${result.scopeComplete?"تأیید":"تأییدنشده"} است.`,deepCrawl:{status:result.crawlStatus,scopeComplete:result.scopeComplete,pagesFetched:result.pagesFetched,documentsFound:result.documentsFound,errors:result.errors?.length||0}};
});

const keepExisting=(collection)=>collection.filter(item=>!fullyRebuiltSlugs.has(item.universitySlug));
const nextUnits=keepExisting(units);const nextSystems=keepExisting(systems);const nextDocuments=keepExisting(documents);
for(const result of audited){
  const slug=result.universitySlug;const unitSeen=new Set(nextUnits.filter(item=>item.universitySlug===slug).map(item=>canonical(item.url||item.sourceUrl)));const systemSeen=new Set(nextSystems.filter(item=>item.universitySlug===slug).map(item=>canonical(item.url||item.sourceUrl)));const documentSeen=new Set(nextDocuments.filter(item=>item.universitySlug===slug).map(item=>canonical(item.url||item.sourceUrl)));
  for(const [dimension,type] of Object.entries(unitTypes))for(const source of result.evidence[dimension]?.sources||[]){if(source.status!=="verified"||!validUrl(source.url)||unitSeen.has(canonical(source.url)))continue;unitSeen.add(canonical(source.url));nextUnits.push({id:`${slug}-crawl-unit-${nextUnits.filter(item=>item.universitySlug===slug).length+1}`,universitySlug:slug,nameFa:source.title||`صفحه ${dimension}`,type,evidence:"verified",status:"active",url:source.url,sourceUrl:source.url,lastVerified:(source.fetchedAt||result.completedAt).slice(0,10),sourceMethod:"deep-crawl",relationStatus:dimension==="informationTechnology"&&source.organizationalRelation?"organizationally-attributed":"portal-attributed",relationshipEvidenceUrl:dimension==="informationTechnology"&&source.organizationalRelation?source.url:null})}
  for(const item of result.systems||[]){if(!validUrl(item.url)||systemSeen.has(canonical(item.url)))continue;systemSeen.add(canonical(item.url));nextSystems.push({id:`${slug}-crawl-system-${nextSystems.filter(entry=>entry.universitySlug===slug).length+1}`,universitySlug:slug,nameFa:item.nameFa,category:systemCategories[item.category]||"research",relation:"linked-from-portal",evidence:"verified",status:"active",url:item.url,sourceUrl:item.parentUrl,parentUrl:item.parentUrl,lastVerified:item.lastVerified.slice(0,10),sourceMethod:"deep-crawl"})}
  for(const item of result.documents||[]){const url=item.finalUrl||item.url;if(!item.ok||!validUrl(url)||documentSeen.has(canonical(url)))continue;documentSeen.add(canonical(url));nextDocuments.push({id:`${slug}-crawl-document-${nextDocuments.filter(entry=>entry.universitySlug===slug).length+1}`,universitySlug:slug,title:item.title,type:item.type,topic:item.topic,taxonomy:taxonomyOf(item.type),evidence:"verified",status:"active",lastVerified:item.lastVerified.slice(0,10),url,sourceUrl:url,parentUrl:item.parentUrl,sourceMethod:"deep-crawl",httpStatus:item.status,contentType:item.contentType})}
}

await Promise.all([write("data/evidence/portal-document-reaudit.json",nextReaudit),write("data/audit/portal-audit.json",nextAudits),write("data/evidence/research-review.json",nextReviews),write("data/units/catalog.json",nextUnits),write("data/systems/catalog.json",nextSystems),write("data/documents/catalog.json",nextDocuments)]);
console.log(`deep crawl import: ${auditedSlugs.size}/115 with fetched pages; ${fullyRebuiltSlugs.size} complete scopes rebuilt; units ${nextUnits.length}; systems ${nextSystems.length}; documents ${nextDocuments.length}`);
