/**
 * Exhaustive, evidence-first crawler for public Research & Technology portals.
 *
 * The crawler follows every reachable HTML page inside the confirmed portal
 * boundary, discovers sitemap pages and pagination, records files without
 * downloading their bodies, and keeps unresolved/restricted outcomes explicit.
 * It never treats a missing page as proof that a service does not exist.
 */
import fs from "node:fs/promises";
import path from "node:path";
import {createHash} from "node:crypto";
import {fileURLToPath} from "node:url";

const DIMENSIONS=["portalIdentity","organization","libraryDocuments","laboratories","industryTechnology","informationTechnology","systemsServices","documentsRegulations"];
const USER_AGENT="IranResearchPortalObservatory/10.1 (+https://github.com/Hhhkarimi/ResearchPortal; evidence audit)";
const HTML_TYPES=["text/html","application/xhtml+xml"];
const FILE_EXTENSIONS=new Set(["pdf","doc","docx","xls","xlsx","ppt","pptx","odt","ods","rtf","zip"]);
const ASSET_EXTENSIONS=new Set(["jpg","jpeg","png","gif","webp","svg","ico","css","js","mjs","map","woff","woff2","ttf","eot","mp3","mp4","webm","avi"]);
const RESEARCH=/معاونت\s*(پژوهش|تحقیقات)|پژوهش\s*و\s*فناوری|امور\s*پژوهشی|research(?:\s*(?:and|&)\s*technology)?|vice.?chancellor.{0,30}research|research\s*affairs/i;
const RELATION=/زیر\s*نظر\s*معاونت|وابسته\s*به\s*معاونت|از\s*مدیریت.{0,50}معاونت|در\s*ساختار.{0,50}معاونت|واحدهای\s*تابعه|managed\s*by.{0,50}research|under.{0,50}research/i;
const PATTERNS={
  portalIdentity:[RESEARCH,/پرتال\s*(پژوهش|معاونت)|دفتر\s*معاونت/i],
  organization:[/ساختار\s*سازمانی|چارت\s*سازمانی|معرفی\s*معاونت|مدیریت\s*امور\s*پژوهش|حوزه\s*معاونت|مدیران|کارکنان|organizational\s*(?:chart|structure)|about\s*(?:the\s*)?(?:vice|research)|managements?|people/i],
  libraryDocuments:[/کتابخانه|مرکز\s*اسناد|مدیریت\s*اطلاعات\s*علمی|نشر\s*دانشگاهی|انتشارات|نشریات|مجلات|library|documentation\s*cent(?:er|re)|publication|journal/i],
  laboratories:[/آزمایشگاه|آزمایشگاه\s*مرکزی|شبکه\s*آزمایشگاهی|تجهیزات\s*پژوهشی|laborator(?:y|ies)|lab\b|equipment/i],
  industryTechnology:[/ارتباط\s*با\s*صنعت|جامعه\s*و\s*صنعت|فناوری|نوآوری|مرکز\s*رشد|پارک\s*علم|مالکیت\s*فکری|ثبت\s*اختراع|شرکت.{0,20}دانش.?بنیان|industry|innovation|technology|incubat|intellectual\s*property|patent|\btto\b/i],
  informationTechnology:[/فناوری\s*اطلاعات|مرکز\s*فاوا|مرکز\s*آمار\s*و\s*فناوری|اطلاعات\s*و\s*ارتباطات|information\s*technology|\bict\b/i],
  systemsServices:[/سامانه|خدمات\s*الکترونیک|پیشخوان|ورود\s*به\s*سامانه|پژوهشیار|گلستان|نشریات|service|system|portal|login/i],
  documentsRegulations:[/فرم|آیین.?نامه|شیوه.?نامه|دستورالعمل|بخشنامه|ضابطه|مقررات|راهنما|فرآیند|دانلود|اسناد|form|regulation|bylaw|guideline|procedure|circular|download|document/i]
};
const TYPE_PATTERNS=[
  ["آیین‌نامه",/آیین.?نامه|regulation|bylaw/i],
  ["شیوه‌نامه",/شیوه.?نامه/i],
  ["دستورالعمل",/دستورالعمل|instruction|guideline/i],
  ["فرم",/فرم|form|template/i],
  ["بخشنامه",/بخشنامه|circular/i],
  ["راهنما",/راهنما|guide|manual/i],
  ["فرآیند",/فرآیند|process|procedure/i],
  ["ضابطه",/ضابطه|policy/i]
];
const TOPIC_PATTERNS=[
  ["اخلاق پژوهش",/اخلاق|کمیته\s*اخلاق|ethic/i],
  ["حمایت و گرنت",/گرنت|پژوهانه|حمایت|اعتبار\s*پژوهشی|grant|fund/i],
  ["انتشارات و نشریات",/نشریه|مجله|انتشار|چاپ|کتاب|journal|publication/i],
  ["آزمایشگاه",/آزمایشگاه|تجهیزات|laborator|equipment/i],
  ["صنعت، فناوری و مالکیت فکری",/صنعت|فناور|نوآور|مالکیت\s*فکری|اختراع|مرکز\s*رشد|industry|technology|innovation|patent/i],
  ["تحصیلات تکمیلی و امور پژوهشی",/پایان.?نامه|رساله|پروپوزال|طرح\s*پژوهشی|تحصیلات\s*تکمیلی|thesis|dissertation|proposal/i]
];

const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const hash=value=>createHash("sha256").update(value).digest("hex");
const compact=value=>String(value||"").replace(/\s+/g," ").trim();
const decode=value=>compact(String(value||"")
  .replace(/&nbsp;|&#160;/gi," ").replace(/&amp;/gi,"&").replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'")
  .replace(/&lt;/gi,"<").replace(/&gt;/gi,">").replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n)))
  .replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16))));
const stripHtml=html=>decode(String(html||"")
  .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi," ").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi," ")
  .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi," ").replace(/<!--([\s\S]*?)-->/g," ").replace(/<[^>]+>/g," "));
const titleFromHtml=html=>decode(html.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i)?.[1]||html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1]||"");
const extensionOf=url=>new URL(url).pathname.split("/").pop()?.split(".").pop()?.toLowerCase()||"";
const isFile=url=>FILE_EXTENSIONS.has(extensionOf(url));
const isAsset=url=>ASSET_EXTENSIONS.has(extensionOf(url));
const validHttp=value=>{try{return ["http:","https:"].includes(new URL(value).protocol)}catch{return false}};
const sameHost=(left,right)=>left.toLowerCase().replace(/^www\./,"")===right.toLowerCase().replace(/^www\./,"");
const canonicalUrl=value=>{
  const url=new URL(value);url.hash="";url.hostname=url.hostname.toLowerCase();
  for(const key of [...url.searchParams.keys()])if(/^utm_|^(fbclid|gclid|sid|session|phpsessid|ref)$/i.test(key))url.searchParams.delete(key);
  url.searchParams.sort();if(url.pathname.length>1)url.pathname=url.pathname.replace(/\/{2,}/g,"/").replace(/\/+$/g,"");
  return url.toString();
};
const safeUrl=(href,base)=>{try{const value=canonicalUrl(new URL(decode(href),base));return validHttp(value)?value:null}catch{return null}};
const sourceLabel=(anchor,url)=>compact(stripHtml(anchor))||decodeURIComponent(new URL(url).pathname.split("/").pop()||"")||"بدون عنوان";
const classifyType=text=>TYPE_PATTERNS.find(([,pattern])=>pattern.test(text))?.[0]||"سند";
const classifyTopic=text=>TOPIC_PATTERNS.find(([,pattern])=>pattern.test(text))?.[0]||"سایر";
const matchDimensions=text=>DIMENSIONS.filter(dimension=>PATTERNS[dimension].some(pattern=>pattern.test(text)));
const snippetFor=(text,patterns)=>{for(const pattern of patterns){const match=pattern.exec(text);if(match){const start=Math.max(0,match.index-90);return text.slice(start,start+260)}}return text.slice(0,260)};

export function extractLinks(html,base){
  const links=[];const seen=new Set();
  const add=(href,label,kind="anchor")=>{const url=safeUrl(href,base);if(!url||seen.has(`${kind}|${url}`))return;seen.add(`${kind}|${url}`);links.push({url,label:compact(stripHtml(label)),kind})};
  for(const match of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)){const href=match[1].match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);if(href)add(href[1]??href[2]??href[3],match[2],"anchor")}
  for(const match of html.matchAll(/<(?:iframe|embed|source)\b([^>]*)>/gi)){const src=match[1].match(/\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);if(src)add(src[1]??src[2]??src[3],"محتوای تعبیه‌شده","embedded")}
  for(const match of html.matchAll(/<object\b([^>]*)>/gi)){const data=match[1].match(/\bdata\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i);if(data)add(data[1]??data[2]??data[3],"فایل تعبیه‌شده","embedded")}
  return links;
}

function parseArgs(argv){
  const args={slug:null,seed:null,output:"data/crawl/deep-portal-crawl.json",maxPages:0,maxDepth:12,concurrency:4,timeout:22000,delay:180};
  for(let index=0;index<argv.length;index++){
    const key=argv[index],value=argv[index+1];
    if(key==="--slug"){args.slug=value;index++}else if(key==="--seed"){args.seed=value;index++}else if(key==="--output"){args.output=value;index++}
    else if(key==="--max-pages"){args.maxPages=Number(value);index++}else if(key==="--max-depth"){args.maxDepth=Number(value);index++}
    else if(key==="--concurrency"){args.concurrency=Math.max(1,Number(value));index++}else if(key==="--timeout"){args.timeout=Number(value);index++}
    else if(key==="--delay"){args.delay=Math.max(0,Number(value));index++}else if(key==="--help")args.help=true;else throw new Error(`Unknown argument: ${key}`);
  }
  return args;
}

function portalBoundary(seed){
  const url=new URL(seed);const hostname=url.hostname.toLowerCase();const dedicated=/^(research|res|vr|pajouhesh|researchportal|vcrt|rd)\./i.test(hostname);
  const segments=url.pathname.split("/").filter(Boolean);const marker=segments.findIndex(segment=>/^(research|res|vr|pajouhesh|rd|research-affairs)$/i.test(segment));
  const prefix=marker>=0?`/${segments.slice(0,marker+1).join("/")}`:null;
  return{origin:url.origin,hostname,dedicated,prefix};
}

function insideBoundary(value,boundary,depth,label=""){
  const url=new URL(value);if(!sameHost(url.hostname,boundary.hostname))return false;if(isAsset(value)||isFile(value))return false;
  if(boundary.prefix&&!url.pathname.startsWith(boundary.prefix))return false;
  if(boundary.dedicated||boundary.prefix)return true;
  if(depth<=1)return true;
  return RESEARCH.test(`${url.pathname} ${label}`)||matchDimensions(`${url.pathname} ${label}`).length>0||/[?&](page|p|pageno)=\d+/i.test(url.search);
}

function parseRobots(text,userAgent=USER_AGENT){
  const disallow=[];const sitemaps=[];let active=false;
  for(const raw of String(text||"").split(/\r?\n/)){const line=raw.replace(/#.*/,"").trim();if(!line)continue;const [rawKey,...tail]=line.split(":");const key=rawKey.toLowerCase(),value=tail.join(":").trim();
    if(key==="user-agent")active=value==="*"||userAgent.toLowerCase().includes(value.toLowerCase());else if(key==="disallow"&&active&&value)disallow.push(value);else if(key==="sitemap"&&value)sitemaps.push(value);
  }
  return{disallow,sitemaps};
}

function allowedByRobots(url,rules){const pathWithQuery=`${new URL(url).pathname}${new URL(url).search}`;return !rules.disallow.some(rule=>rule!=="/"&&pathWithQuery.startsWith(rule))&&!(rules.disallow.includes("/"))}

async function fetchWithMeta(url,{timeout,method="GET",headers={}}){
  const fetchedAt=new Date().toISOString();
  try{
    const response=await fetch(url,{method,redirect:"follow",headers:{"User-Agent":USER_AGENT,Accept:"text/html,application/xhtml+xml,application/pdf,application/xml;q=0.9,*/*;q=0.5",...headers},signal:AbortSignal.timeout(timeout)});
    return{response,fetchedAt,error:null};
  }catch(error){return{response:null,fetchedAt,error:error instanceof Error?error.message:String(error)}}
}

async function getRobots(boundary,args){
  const url=`${boundary.origin}/robots.txt`;const result=await fetchWithMeta(url,args);
  if(!result.response?.ok)return{url,status:result.response?.status??"network-error",disallow:[],sitemaps:[],error:result.error};
  const parsed=parseRobots(await result.response.text());return{url,status:result.response.status,...parsed,error:null};
}

async function sitemapUrls(url,boundary,args,seen=new Set(),level=0){
  if(level>2||seen.has(url))return[];seen.add(url);const result=await fetchWithMeta(url,args);if(!result.response?.ok)return[];
  const xml=await result.response.text();const locations=[...xml.matchAll(/<loc\b[^>]*>([\s\S]*?)<\/loc>/gi)].map(match=>safeUrl(stripHtml(match[1]),url)).filter(Boolean);const found=[];
  for(const location of locations){if(/\.xml(?:\.gz)?(?:$|\?)/i.test(location))found.push(...await sitemapUrls(location,boundary,args,seen,level+1));else if(insideBoundary(location,boundary,2,"sitemap"))found.push(location)}
  return found;
}

function pageEvidence({url,title,text,isRoot,status}){
  const searchable=compact(`${title} ${new URL(url).pathname} ${text.slice(0,18000)}`);const dimensions=[];
  for(const dimension of matchDimensions(searchable)){
    const titleHits=PATTERNS[dimension].filter(pattern=>pattern.test(`${title} ${new URL(url).pathname}`)).length;
    const bodyHits=PATTERNS[dimension].filter(pattern=>pattern.test(searchable)).length;
    let evidenceStatus=status===200&&!isRoot&&(titleHits>0||bodyHits>1)?"verified":"observed-reference";
    if(dimension==="portalIdentity"&&isRoot&&status===200&&RESEARCH.test(searchable))evidenceStatus="verified";
    if(dimension==="informationTechnology"&&evidenceStatus==="verified"&&!RELATION.test(searchable))evidenceStatus="observed-reference";
    dimensions.push({dimension,status:evidenceStatus,titleHits,bodyHits,snippet:snippetFor(searchable,PATTERNS[dimension]),organizationalRelation:dimension==="informationTechnology"?RELATION.test(searchable):undefined});
  }
  return dimensions;
}

async function inspectFile(link,parent,args,boundary){
  const head=await fetchWithMeta(link.url,{...args,method:"HEAD"});let response=head.response,error=head.error,fetchedAt=head.fetchedAt;
  if(!response||[403,405,501].includes(response.status)){const fallback=await fetchWithMeta(link.url,{...args,headers:{Range:"bytes=0-2047"}});response=fallback.response;error=fallback.error;fetchedAt=fallback.fetchedAt}
  const finalUrl=response?.url||link.url;const official=sameHost(new URL(finalUrl).hostname,boundary.hostname);
  const label=sourceLabel(link.label,link.url);const text=`${label} ${new URL(link.url).pathname}`;
  return{url:link.url,finalUrl,status:response?.status??"network-error",ok:Boolean(response?.ok),contentType:response?.headers.get("content-type")||null,contentLength:response?.headers.get("content-length")||null,extension:extensionOf(link.url)||null,title:label,type:classifyType(text),topic:classifyTopic(text),parentUrl:parent.url,parentTitle:parent.title,officialHost:official,lastVerified:fetchedAt,error};
}

function outcomeFor(dimension,pages,files,crawlStatus,seed){
  const hits=pages.flatMap(page=>page.dimensions.filter(item=>item.dimension===dimension).map(item=>({...item,url:page.finalUrl,title:page.title,fetchedAt:page.fetchedAt})));
  if(dimension==="documentsRegulations")for(const file of files)if(file.ok)hits.push({dimension,status:"verified",url:file.finalUrl,title:file.title,fetchedAt:file.lastVerified,snippet:`${file.type} · ${file.topic}`});
  const verified=hits.filter(hit=>hit.status==="verified");const observed=hits.filter(hit=>hit.status==="observed-reference");
  if(verified.length)return{status:"verified",reason:"صفحه یا فایل اختصاصی رسمی با سیگنال مستقیم این بُعد بازیابی شد.",sources:verified};
  if(observed.length)return{status:"observed-reference",reason:"نشانه رسمی مشاهده شد اما صفحه اختصاصی یا رابطه سازمانی کافی نبود.",sources:observed};
  if(crawlStatus==="restricted")return{status:"restricted",reason:"پرتال رسمی در زمان ممیزی پاسخ عمومی قابل بررسی نداد.",sources:[{url:seed,title:"تلاش دسترسی به پرتال رسمی"}]};
  return{status:"unresolved",reason:"در محدوده عمومی خزیده‌شده شاهد کافی بازیابی نشد؛ این نتیجه به معنی نبود قابلیت نیست.",sources:[]};
}

export async function crawlUniversity(institution,seeds,args,seedAssertion="confirmed-direct-portal"){
  const startedAt=new Date().toISOString();const seed=seeds[0];
  if(!seed)return{universitySlug:institution.slug,nameFa:institution.nameFa,startedAt,completedAt:new Date().toISOString(),crawlStatus:"no-confirmed-seed",scopeComplete:false,seedUrls:[],pagesDiscovered:0,pagesFetched:0,pages:[],documents:[],systems:[],errors:[{kind:"seed",message:"No confirmed direct official Research & Technology portal seed is registered."}],evidence:Object.fromEntries(DIMENSIONS.map(dimension=>[dimension,{status:"unresolved",reason:"پرتال مستقیم رسمی برای آغاز خزیدن حل نشده است.",sources:[]}]))};
  const boundary=portalBoundary(seed);const robots=await getRobots(boundary,args);const sitemapSeeds=[...new Set([`${boundary.origin}/sitemap.xml`,...robots.sitemaps])];
  const sitemapDiscovered=[];for(const sitemap of sitemapSeeds)sitemapDiscovered.push(...await sitemapUrls(sitemap,boundary,args));
  const queue=[];const queued=new Set();const enqueue=(url,depth,parentUrl=null,label="")=>{if(depth>args.maxDepth||!validHttp(url)||queued.has(url)||!insideBoundary(url,boundary,depth,label)||!allowedByRobots(url,robots))return;queued.add(url);queue.push({url,depth,parentUrl,label})};
  for(const value of seeds)enqueue(canonicalUrl(value),0,null,"seed");for(const value of sitemapDiscovered)enqueue(value,1,null,"sitemap");
  const pages=[];const filesByUrl=new Map();const systemsByUrl=new Map();const errors=[];let limitReached=false;
  while(queue.length){
    if(args.maxPages>0&&pages.length>=args.maxPages){limitReached=true;break}
    const batch=queue.splice(0,args.concurrency);const fetched=await Promise.all(batch.map(async item=>({item,result:await fetchWithMeta(item.url,args)})));
    for(const {item,result} of fetched){
      if(!result.response){errors.push({url:item.url,kind:"network",message:result.error,fetchedAt:result.fetchedAt});continue}
      const response=result.response,contentType=(response.headers.get("content-type")||"").toLowerCase();
      if(!sameHost(new URL(response.url).hostname,boundary.hostname)){errors.push({url:item.url,finalUrl:response.url,kind:"external-redirect",status:response.status,message:"Redirect left the confirmed portal host; content was not used as evidence.",fetchedAt:result.fetchedAt});continue}
      if(!HTML_TYPES.some(type=>contentType.includes(type))){if(isFile(item.url))filesByUrl.set(item.url,await inspectFile({url:item.url,label:item.label},{url:item.parentUrl||seed,title:""},args,boundary));continue}
      const html=await response.text();const title=titleFromHtml(html)||item.label||new URL(item.url).pathname;const text=stripHtml(html);const links=extractLinks(html,response.url);const page={url:item.url,finalUrl:canonicalUrl(response.url),parentUrl:item.parentUrl,depth:item.depth,status:response.status,ok:response.ok,contentType,title,fetchedAt:result.fetchedAt,textHash:hash(text),textLength:text.length,linkCount:links.length,dimensions:pageEvidence({url:response.url,title,text,isRoot:item.depth===0,status:response.status})};pages.push(page);
      if(!response.ok)errors.push({url:item.url,kind:"http",status:response.status,message:`HTTP ${response.status}`,fetchedAt:result.fetchedAt});
      for(const link of links){
        const label=sourceLabel(link.label,link.url);const combined=`${label} ${new URL(link.url).pathname}`;
        if(isFile(link.url)){if(!filesByUrl.has(link.url))filesByUrl.set(link.url,{pending:true,link,parent:{url:page.finalUrl,title:page.title}});continue}
        if(PATTERNS.systemsServices.some(pattern=>pattern.test(combined))&&!isAsset(link.url))systemsByUrl.set(link.url,{url:link.url,nameFa:label,category:classifyTopic(combined),parentUrl:page.finalUrl,parentTitle:page.title,officialHost:new URL(link.url).hostname.toLowerCase()===boundary.hostname,lastVerified:result.fetchedAt});
        enqueue(link.url,item.depth+1,page.finalUrl,label);
      }
    }
    if(args.delay)await sleep(args.delay);
  }
  const pendingFiles=[...filesByUrl.entries()].filter(([,value])=>value.pending);let fileCursor=0;
  const fileWorkers=Array.from({length:Math.min(args.concurrency,pendingFiles.length)},async()=>{while(fileCursor<pendingFiles.length){const [url,value]=pendingFiles[fileCursor++];filesByUrl.set(url,await inspectFile(value.link,value.parent,args,boundary));if(args.delay)await sleep(args.delay)}});await Promise.all(fileWorkers);
  const files=[...filesByUrl.values()].filter(value=>!value.pending);const seedPage=pages.find(page=>page.depth===0);const restricted=!seedPage||!seedPage.ok;const crawlStatus=restricted?"restricted":limitReached?"page-limit-reached":errors.length?"complete-with-errors":"complete";const scopeComplete=!restricted&&!limitReached&&queue.length===0;
  const evidence=Object.fromEntries(DIMENSIONS.map(dimension=>[dimension,outcomeFor(dimension,pages,files,crawlStatus,seed)]));
  if(seedAssertion==="confirmed-research-surface-seed"&&evidence.portalIdentity.status==="verified"){evidence.portalIdentity.status="observed-reference";evidence.portalIdentity.reason="این URL سطح رسمی پژوهشی و seed امن خزیدن است، اما صفحه اصلی پرتال معاونت ادعا نشده است.";for(const source of evidence.portalIdentity.sources)source.status="observed-reference"}
  return{universitySlug:institution.slug,nameFa:institution.nameFa,startedAt,completedAt:new Date().toISOString(),crawlStatus,scopeComplete,crawlMode:"exhaustive-within-confirmed-portal-boundary",seedAssertion,seedUrls:seeds,boundary,robots:{url:robots.url,status:robots.status,disallowCount:robots.disallow.length,sitemaps:sitemapSeeds},sitemapUrlsDiscovered:new Set(sitemapDiscovered).size,pagesDiscovered:queued.size,pagesFetched:pages.length,documentsFound:files.length,systemsFound:systemsByUrl.size,pages,documents:files,systems:[...systemsByUrl.values()],errors,evidence};
}

async function main(){
  const args=parseArgs(process.argv.slice(2));if(args.help){console.log("node scripts/crawl-portals-deep.mjs [--slug bojnord] [--seed URL] [--max-pages 0] [--max-depth 12] [--concurrency 4] [--timeout 22000] [--delay 180] [--output FILE]");return}
  const [institutions,audits,reaudit,seedRegistry]=await Promise.all([fs.readFile("data/isc/institutions.json","utf8").then(JSON.parse),fs.readFile("data/audit/portal-audit.json","utf8").then(JSON.parse),fs.readFile("data/evidence/portal-document-reaudit.json","utf8").then(JSON.parse),fs.readFile("data/evidence/research-portal-seeds-115.json","utf8").then(JSON.parse).catch(()=>({institutions:[]}))]);
  const selected=args.slug?institutions.filter(item=>item.slug===args.slug):institutions;if(!selected.length)throw new Error(`Unknown ISC slug: ${args.slug}`);
  const previous=await fs.readFile(args.output,"utf8").then(JSON.parse).catch(()=>({universities:[]}));const bySlug=new Map((previous.universities||[]).map(item=>[item.universitySlug,item]));
  for(const institution of selected){
    const audit=audits.find(item=>item.universitySlug===institution.slug);const row=reaudit.find(item=>item.slug===institution.slug);const registeredSeed=seedRegistry.institutions?.find(item=>item.slug===institution.slug);
    const seeds=[...new Set([args.seed,registeredSeed?.seedUrl,...(row?.portalUrls||[]),audit?.portalAuditStatus==="direct-official"?audit.researchUrl:null].filter(Boolean).map(canonicalUrl))];const seedAssertion=args.seed?"manual-override":registeredSeed?.outcome||"confirmed-direct-portal";
    console.log(`[${institution.slug}] crawl starting with ${seeds.length} confirmed seed(s)`);const result=await crawlUniversity(institution,seeds,args,seedAssertion);bySlug.set(institution.slug,result);console.log(`[${institution.slug}] ${result.crawlStatus}: ${result.pagesFetched} pages / ${result.documentsFound} documents / ${result.systemsFound} systems`);
    const snapshot={schemaVersion:1,methodologyVersion:"RTPMI-4.2-deep-crawl",generatedAt:new Date().toISOString(),crawler:{userAgent:USER_AGENT,maxPagesPerInstitution:args.maxPages||"unlimited",maxDepth:args.maxDepth,concurrency:args.concurrency,timeoutMs:args.timeout,delayMs:args.delay,scope:"confirmed official Research & Technology portal host/path; robots.txt respected; HTML pages exhausted until queue empty"},universities:institutions.map(item=>bySlug.get(item.slug)).filter(Boolean)};
    await fs.mkdir(path.dirname(args.output),{recursive:true});await fs.writeFile(args.output,JSON.stringify(snapshot,null,2)+"\n");
  }
  const final=JSON.parse(await fs.readFile(args.output,"utf8"));console.log(`deep crawl snapshot: ${final.universities.length}/115 institutions; ${final.universities.reduce((sum,item)=>sum+item.pagesFetched,0)} pages; output=${args.output}`);
}

const isMain=process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url);if(isMain)main().catch(error=>{console.error(error);process.exitCode=1});
