import assert from "node:assert/strict";
import fs from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {crawlUniversity,extractLinks} from "../crawl-portals-deep.mjs";

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.join(here,"fixtures/deep-crawl/site");
const contentType=file=>file.endsWith(".html")?"text/html; charset=utf-8":file.endsWith(".pdf")?"application/pdf":file.endsWith(".docx")?"application/vnd.openxmlformats-officedocument.wordprocessingml.document":"text/plain; charset=utf-8";
const server=http.createServer(async(request,response)=>{
  const requested=new URL(request.url,"http://localhost").pathname;
  const aliases={"/":"/index.html","/research-system/login":"/research-system-login.html"};
  const relative=aliases[requested]||requested;
  const file=path.join(root,relative.replace(/^\/+/,""));
  try{const body=await fs.readFile(file);response.writeHead(200,{"Content-Type":contentType(file),"Content-Length":body.length});if(request.method!=="HEAD")response.end(body);else response.end()}
  catch{response.writeHead(404,{"Content-Type":"text/plain"});response.end("not found")}
});

await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
try{
  const address=server.address();const seed=`http://127.0.0.1:${address.port}/`;
  const links=extractLinks('<a href="/forms.pdf">فرم پژوهشی</a>',seed);assert.equal(links[0].label,"فرم پژوهشی");
  const result=await crawlUniversity({slug:"fixture",nameFa:"دانشگاه نمونه"},[seed],{maxPages:0,maxDepth:12,concurrency:3,timeout:3000,delay:0});
  assert.equal(result.scopeComplete,true);assert.equal(result.crawlStatus,"complete");assert.ok(result.pagesFetched>=7,`expected at least 7 pages, got ${result.pagesFetched}`);
  assert.equal(result.documentsFound,2);assert.equal(result.evidence.portalIdentity.status,"verified");assert.equal(result.evidence.organization.status,"verified");assert.equal(result.evidence.laboratories.status,"verified");assert.equal(result.evidence.informationTechnology.status,"verified");assert.equal(result.evidence.systemsServices.status,"verified");assert.equal(result.evidence.documentsRegulations.status,"verified");
  assert.ok(result.documents.some(document=>document.type==="فرم"&&document.topic==="اخلاق پژوهش"));assert.ok(result.documents.some(document=>document.type==="آیین‌نامه"&&document.topic==="صنعت، فناوری و مالکیت فکری"));
  const surface=await crawlUniversity({slug:"fixture",nameFa:"دانشگاه نمونه"},[seed],{maxPages:1,maxDepth:1,concurrency:1,timeout:3000,delay:0},"confirmed-research-surface-seed");assert.equal(surface.evidence.portalIdentity.status,"observed-reference","a research surface must not be promoted to portal homepage identity");
  console.log(`deep-crawl fixture passed: ${result.pagesFetched} pages / ${result.documentsFound} documents`);
}finally{await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()))}
