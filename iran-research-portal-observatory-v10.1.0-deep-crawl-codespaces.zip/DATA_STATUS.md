# Data Status — v10.1.0

Snapshot: 2026-08-11

## Scope

- ISC public/government roster: **115/115**
- Categories locked: **69 comprehensive / 24 industrial / 4 agricultural sciences / 4 art / 4 subsystem / 10 executive-agency**
- Medical-sciences universities and non-governmental ISC institutions: excluded

## Evidence review

- Independent institution reviews: **115/115**
- Dimension-level outcomes: **920/920** (115 institutions × 8 dimensions)
- Verified with dimension-specific publication evidence: **124**
- Official reference observed: **194**
- Access restricted/blocked with an attempted URL: **29**
- Unresolved in this snapshot: **573**
- Portal-root reuse kept at reference level rather than promoted to direct evidence
- Restricted outcomes without an attempted URL downgraded to unresolved: **48**
- Unique URLs represented in the dimension evidence register: **476**

The merged review records 124 direct, 194 reference, 77 restricted and 525 unresolved outcomes. The publication gate makes 48 restricted-to-unresolved adjustments where no attempted official URL is publishable. The importer normalizes URL variants and prevents portal-root reuse and unproven IT dependency from becoming direct evidence. The registry is exhaustive as a review-outcome matrix, not as a claim that every university feature was publicly verifiable. `unresolved` means the audit did not resolve sufficient public evidence; it never means absent or zero. Restricted access counts as review completion, not as Evidence coverage.

## Portal and structured catalogs

- Portal-resolution outcomes: **115/115**
- Fresh two-pass portal/document re-audit: **115/115**
- Direct official portal/surface: **52**
- Confirmed research-surface crawl seeds (not asserted as portal homepages): **9**
- No confirmed crawl seed: **54**
- First-party URLs inspected: **328** across **57** institutions
- Contentful pages: **117**; minimal/discovery-only retrievals: **211**
- Deep-audited and RTPMI-ranked: **4**
- Units/subunits: **154**
- Systems/services: **92**
- Documents/forms/regulations/indexes: **198**
- Provenance rows: **920**
- Audit Packets: **115**
- Synthetic scores: **0**

## Publication & monitoring

- REST API v1 includes universities, profiles, 920 evidence outcomes, rankings, summary and health.
- OpenAPI 3.1, JSON/CSV Open Data and 115 machine-readable audit packets are published.
- Link monitoring covers every published portal/evidence/catalog URL twice weekly plus manual dispatch.
- Network failure and access restriction are review signals, never claims of non-existence.
