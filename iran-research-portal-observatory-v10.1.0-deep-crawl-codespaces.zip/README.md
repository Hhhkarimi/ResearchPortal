# رصدخانه ملی پرتال پژوهش و فناوری — ISC 115 / v10.1.0

**Iran Research & Technology Portal Observatory** یک پروژه متن‌باز، فارسی/RTL و Evidence-first برای رصد و مقایسه **پرتال عمومی معاونت پژوهش و فناوری** دانشگاه‌ها و مؤسسات دولتی حاضر در طبقه‌بندی ملی ISC است.

> **RTPMI رتبه عملکرد پژوهشی دانشگاه نیست.** این شاخص فقط بلوغ، شفافیت و قابلیت استفاده از سطح عمومی پرتال معاونت پژوهش و فناوری را با شواهد قابل ردیابی ارزیابی می‌کند.

## Source of Truth: دقیقاً ۱۱۵ عضو دولتی ISC

فهرست عضویت پروژه در `data/isc/institutions.json` قفل شده و بر مبنای طبقه‌بندی ملی ISC سال ۱۴۰۲–۱۴۰۱ است:

| طبقه ISC | تعداد |
|---|---:|
| جامع | 69 |
| صنعتی | 24 |
| علوم کشاورزی | 4 |
| هنر | 4 |
| زیرنظام | 4 |
| وابسته به دستگاه‌های اجرایی | 10 |
| **جمع** | **115** |

دانشگاه‌های غیردولتی ISC و دانشگاه‌های علوم پزشکی در Scope این پروژه نیستند. Validator در صورت کم/زیاد شدن حتی یک عضو یا تغییر تعداد طبقات Fail می‌شود.

## وضعیت ممیزی v10.1

- **115/115** نهاد ISC دارای Portal Resolution Outcome هستند؛ هیچ عضو بدون نتیجه ممیزی باقی نمانده است.
- **115/115** نهاد یک باز‌ممیزی تازهٔ دوگذر برای پرتال پژوهش و فناوری و مخازن اسناد دریافت کرده‌اند.
- **52** هویت پرتال/سطح مستقیم رسمی (`direct-official`).
- **9** سطح رسمی پژوهشی دیگر به‌عنوان seed امن خزیدن ثبت شده‌اند، بدون ادعای اینکه صفحه اصلی معاونت هستند.
- **54** نهاد هنوز seed رسمی قابل اتکا ندارند و blocker هر مورد ثبت است.
- **4** پرتال دارای Deep Audit کافی و واجد Gate فعلی RTPMI.
- **48** پرتال مستقیم رسمی هنوز Deep Evidence کافی برای رتبه عمومی ندارند.
- **6** نهاد با وضعیت دسترسی عمومی محدود/restricted بسته شده‌اند.
- **4** false-positive شناسایی و Block شده‌اند تا منبع اشتباه وارد Production نشود.
- **154** رکورد واحد/زیرمجموعه پژوهشی.
- **92** سامانه/خدمت.
- **198** سند/فرم/آیین‌نامه/شیوه‌نامه/صفحه شاخص سند ساختاریافته و طبقه‌بندی‌شده؛ رکوردهای discovery-only امتیاز مستقیم نمی‌گیرند.
- **920** رکورد Provenance.
- **115 Audit Packet مستقل**؛ یک فایل کامل برای هر عضو ISC.
- **920 Outcome مستقل Evidence**؛ هشت نتیجه بازبینی برای هر یک از ۱۱۵ دانشگاه.
- باز‌ممیزی جدید صفحهٔ اصلی پرتال را فقط برای «هویت پرتال» کافی می‌داند؛ استفادهٔ همان URL برای ابعاد دیگر در حد ارجاع می‌ماند و IT بدون شاهد رابطه سازمانی تأیید نمی‌شود. رجیستر قابل انتشار: **124** تأیید، **194** ارجاع رسمی، **29** محدود و **573** حل‌نشده.
- **328 URL رسمی** در کشف عمیق ثبت شده است؛ ۱۱۷ صفحه محتوای قابل‌بازیابی و ۲۱۱ URL بازیابی حداقلی داشته‌اند.
- **4** پرتال رتبه‌پذیر و **111 Unranked** پس از هم‌ترازشدن محاسبه RTPMI با رجیستر نهایی Evidence.
- **0** امتیاز ساختگی برای داده‌های حل‌نشده.

گزارش seed-first و تمام URLهای بررسی‌شده در `docs/DEEP_PORTAL_INSPECTION_115.md`، رجیستر seed در `data/evidence/research-portal-seeds-115.json` و دادهٔ ماشینی کشف در `data/evidence/deep-portal-discovery-115.json` نگهداری می‌شود. ۵۴ مورد بدون seed غایب فرض نمی‌شوند و ممکن است محدود، کم‌ایندکس یا هنوز حل‌نشده باشند.

## هشت بُعد Deep Audit

برای هر ۱۱۵ نهاد، این ماتریس در `data/audit/deep-audit-matrix.json` وجود دارد:

1. هویت پرتال پژوهش و فناوری
2. ساختار سازمانی معاونت
3. کتابخانه و مرکز اسناد
4. آزمایشگاه مرکزی/پژوهشی و زیرساخت‌ها
5. ارتباط با صنعت، فناوری، نوآوری، TTO و IP
6. فناوری اطلاعات — فقط با Evidence سازمانی
7. سامانه‌ها و خدمات دیجیتال
8. آیین‌نامه‌ها، فرم‌ها، شیوه‌نامه‌ها، دستورالعمل‌ها و سایر اسناد

وضعیت هر خانه یکی از این موارد است:

- `verified`
- `observed-reference`
- `restricted`
- `unresolved`

`unresolved` به معنی «وجود ندارد» نیست.

رجیستر انتشار یک gate دوم هم دارد: URL باید به همان بُعد قابل نگاشت باشد. تأیید IT علاوه بر URL، نیازمند رکورد رسمی رابطه سازمانی است. `restricted` تکمیل فرایند بازبینی را نشان می‌دهد، اما در Evidence Coverage امتیاز پوشش نمی‌گیرد.

## Audit Packet برای تک‌تک ۱۱۵ عضو

`data/audit/packets/<slug>.json` یک پرونده مستقل برای هر دانشگاه است و شامل این موارد می‌شود:

- هویت و رتبه/طبقه ISC
- نتیجه Portal Audit
- Evidence URLها
- ماتریس هشت‌بُعدی
- Audit Evidence Coverage
- واحدهای تابع/مرتبط ثبت‌شده
- سامانه‌ها و نوع رابطه آنها
- اسناد مستقیم و Parent Page
- RTPMI/Confidence در صورت واجد شرایط بودن
- توضیح صریح Missing/Unranked

## RTPMI 4.1 — مدل قابل بازتولید

وزن‌ها:

- اسناد و مقررات: 20%
- ساختار سازمانی: 12%
- کتابخانه/مدیریت دانش: 10%
- آزمایشگاه‌ها: 12%
- سامانه‌ها/بلوغ دیجیتال: 12%
- صنعت/فناوری: 12%
- کیفیت داده و Provenance: 12%
- یافت‌پذیری: 10%

Gate رتبه‌بندی:

- `portalAuditStatus = direct-official`
- Audit Evidence Coverage ≥ 75%
- Confidence ≥ 65%

**Missing rule:** بُعد `unresolved` از مخرج وزن حذف می‌شود و Confidence را پایین می‌آورد؛ به صفر تبدیل نمی‌شود.

تمام امتیازها با `scripts/finalize-rtpmi.mjs` از فایل‌های Versioned Data دوباره ساخته می‌شوند.

## ساختار داده

```text
data/
├── isc/
│   ├── institutions.json        # exact 115 ISC roster
│   ├── institutions.csv
│   └── source.json
├── audit/
│   ├── portal-audit.json        # 115/115 portal outcomes
│   ├── deep-audit-matrix.json   # 115 × 8
│   ├── packets/                 # 115 independent audit packets
│   └── packets-index.json
├── units/catalog.json
├── systems/catalog.json
├── documents/catalog.json
├── evidence/
│   ├── provenance-ledger.json
│   ├── research-review.json      # 115 independent reviews
│   ├── dimension-evidence.json   # 115 × 8 = 920 outcomes
│   └── portal-document-reaudit.json # fresh portal/document discovery for all 115
└── statistics/
    ├── portal-ranking.json
    ├── rtpmi-weights.json
    └── summary.json
```

CSV نسخه‌های اصلی نیز تولید می‌شوند.

## اجرا

```bash
npm install
cp .env.example .env.local
npm run release:check
npm run dev
```

برای ساخت یک Repository تازه، ZIP نسخه `repo-ready` را مستقیماً در ریشه Repository استخراج و مراحل [REPOSITORY_CHECKLIST.md](REPOSITORY_CHECKLIST.md) را اجرا کنید. بسته شامل `node_modules` و `.next` نیست؛ این دو خروجی محلی با `npm ci` و `npm run build` ساخته می‌شوند.

## GitHub Codespaces

پروژه دارای `.devcontainer` کامل است. بعد از Push به GitHub از مسیر **Code → Codespaces → Create codespace on main** محیط آماده می‌شود؛ Node 22، وابستگی‌ها، `.env.local` نمونه، اعتبارسنجی داده و Forward پورت ۳۰۰۰ به‌صورت خودکار تنظیم می‌شوند. راهنمای کامل در [docs/CODESPACES.md](docs/CODESPACES.md) است.

## Pipeline

```bash
npm run test:crawler    # تست قطعی خزنده روی پرتال چندصفحه‌ای fixture
npm run crawl:deep      # پیمایش عمیق صفحات عمومی پرتال‌های رسمی تا پایان صف
npm run crawl:apply     # اعمال Evidence، بازسازی RTPMI و اعتبارسنجی
npm run audit:all       # health check برای URLهای ثبت‌شده
npm run prepare:data    # rebuild matrix/ranking/provenance/open data/packets/CSV
npm run validate:data
npm run release:check
```

`crawl:deep` صرفاً لینک‌های از قبل ثبت‌شده را چک نمی‌کند: از seed رسمی وارد پرتال می‌شود، sitemap و صفحه‌بندی را می‌خواند، همه صفحه‌های HTML قابل‌کشف در مرز host/path پرتال را تا خالی‌شدن صف دنبال می‌کند و فایل‌های فرم/آیین‌نامه را همراه parent URL و metadata ثبت می‌کند. روش و محدودیت‌های صادقانه در [پروتکل خزیدن عمیق](docs/DEEP_CRAWL_PROTOCOL.md) آمده است.

`prepare:data` خروجی‌ها را از Source Data بازتولید می‌کند؛ Ranking فایل دستی نیست.

`audit:all` تمام URLهای منتشرشده در پرتال‌ها، واحدها، سامانه‌ها، اسناد و Provenance را بدون حدس‌زدن آدرس جدید بررسی می‌کند، تغییر سیگنال‌های HTTP را نسبت به اجرای قبل تشخیص می‌دهد و دو گزارش `site-health.json` و `change-report.json` می‌سازد. GitHub Actions این پایش را دو بار در هفته اجرا می‌کند.

## صفحات اصلی

- `/` داشبورد ملی
- `/isc-scope` Scope دقیق ISC
- `/universities` فهرست ۱۱۵ عضو
- `/universities/[slug]` پرونده Evidence هر دانشگاه
- `/audit` ماتریس 115×8
- `/rankings` RTPMI فقط برای Evidence-qualified portals
- `/compare` مقایسه چندبُعدی
- `/documents` Document Explorer
- `/evidence` رجیستر فیلترپذیر ۹۲۰ Outcome شواهد و پیوندهای Provenance
- `/datasets` Open Data
- `/api-docs` راهنمای API نسخه ۱
- `/methodology` روش‌شناسی

## API v1

- `GET /api/v1/universities` با فیلترهای `category`، `status`، `ranked`، `q`، `limit` و `offset`
- `GET /api/v1/universities/{slug}` برای پرونده کامل یک دانشگاه
- `GET /api/v1/evidence` با فیلترهای `university`، `dimension`، `status`، `limit` و `offset`
- `GET /api/v1/rankings`
- `GET /api/v1/summary`
- `GET /api/v1/health`
- قرارداد OpenAPI در `/openapi.json`

تمام پاسخ‌ها Snapshot و نسخه روش‌شناسی را همراه دارند و API فقط خواندنی است.

## امنیت و Data Governance

- هیچ HTML خزیده‌شده مستقیم Render نمی‌شود.
- URL خارجی در UI با `noopener noreferrer` باز می‌شود.
- CSP و هدرهای امنیتی اعمال شده‌اند.
- GitHub CodeQL و Dependabot فعال‌اند.
- Crawler/health check آدرس حدسی برای نهاد بدون پرتال رسمی تولید نمی‌کند.
- false-positiveها به جای حذف شدن از تاریخچه، به صورت Blocked حفظ می‌شوند.
- Git history منبع Audit Trail تغییرات داده است.

## Deploy

Repository را در Vercel Import کنید و `NEXT_PUBLIC_SITE_URL` را تنظیم کنید. CI روی GitHub شامل validation، rebuild داده، typecheck، lint، Next build و dependency audit است. هیچ secret یا دیتابیس خارجی برای اجرای نسخه عمومی لازم نیست.
